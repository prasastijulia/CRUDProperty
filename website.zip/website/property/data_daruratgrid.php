<?php include_once "admininfo.php" ?>
<?php

// Create page object
if (!isset($data_darurat_grid)) $data_darurat_grid = new cdata_darurat_grid();

// Page init
$data_darurat_grid->Page_Init();

// Page main
$data_darurat_grid->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$data_darurat_grid->Page_Render();
?>
<?php if ($data_darurat->Export == "") { ?>
<script type="text/javascript">

// Form object
var fdata_daruratgrid = new ew_Form("fdata_daruratgrid", "grid");
fdata_daruratgrid.FormKeyCountName = '<?php echo $data_darurat_grid->FormKeyCountName ?>';

// Validate form
fdata_daruratgrid.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		var checkrow = (gridinsert) ? !this.EmptyRow(infix) : true;
		if (checkrow) {
			addcnt++;
			elm = this.GetElements("x" + infix + "_Nama");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_darurat->Nama->FldCaption(), $data_darurat->Nama->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Alamat");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_darurat->Alamat->FldCaption(), $data_darurat->Alamat->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Telp");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_darurat->Telp->FldCaption(), $data_darurat->Telp->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Hubungan");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_darurat->Hubungan->FldCaption(), $data_darurat->Hubungan->ReqErrMsg)) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
		} // End Grid Add checking
	}
	return true;
}

// Check empty row
fdata_daruratgrid.EmptyRow = function(infix) {
	var fobj = this.Form;
	if (ew_ValueChanged(fobj, infix, "Nama", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Alamat", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Telp", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Hubungan", false)) return false;
	return true;
}

// Form_CustomValidate event
fdata_daruratgrid.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fdata_daruratgrid.ValidateRequired = true;
<?php } else { ?>
fdata_daruratgrid.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
// Form object for search

</script>
<?php } ?>
<?php
if ($data_darurat->CurrentAction == "gridadd") {
	if ($data_darurat->CurrentMode == "copy") {
		$bSelectLimit = $data_darurat_grid->UseSelectLimit;
		if ($bSelectLimit) {
			$data_darurat_grid->TotalRecs = $data_darurat->SelectRecordCount();
			$data_darurat_grid->Recordset = $data_darurat_grid->LoadRecordset($data_darurat_grid->StartRec-1, $data_darurat_grid->DisplayRecs);
		} else {
			if ($data_darurat_grid->Recordset = $data_darurat_grid->LoadRecordset())
				$data_darurat_grid->TotalRecs = $data_darurat_grid->Recordset->RecordCount();
		}
		$data_darurat_grid->StartRec = 1;
		$data_darurat_grid->DisplayRecs = $data_darurat_grid->TotalRecs;
	} else {
		$data_darurat->CurrentFilter = "0=1";
		$data_darurat_grid->StartRec = 1;
		$data_darurat_grid->DisplayRecs = $data_darurat->GridAddRowCount;
	}
	$data_darurat_grid->TotalRecs = $data_darurat_grid->DisplayRecs;
	$data_darurat_grid->StopRec = $data_darurat_grid->DisplayRecs;
} else {
	$bSelectLimit = $data_darurat_grid->UseSelectLimit;
	if ($bSelectLimit) {
		if ($data_darurat_grid->TotalRecs <= 0)
			$data_darurat_grid->TotalRecs = $data_darurat->SelectRecordCount();
	} else {
		if (!$data_darurat_grid->Recordset && ($data_darurat_grid->Recordset = $data_darurat_grid->LoadRecordset()))
			$data_darurat_grid->TotalRecs = $data_darurat_grid->Recordset->RecordCount();
	}
	$data_darurat_grid->StartRec = 1;
	$data_darurat_grid->DisplayRecs = $data_darurat_grid->TotalRecs; // Display all records
	if ($bSelectLimit)
		$data_darurat_grid->Recordset = $data_darurat_grid->LoadRecordset($data_darurat_grid->StartRec-1, $data_darurat_grid->DisplayRecs);

	// Set no record found message
	if ($data_darurat->CurrentAction == "" && $data_darurat_grid->TotalRecs == 0) {
		if (!$Security->CanList())
			$data_darurat_grid->setWarningMessage(ew_DeniedMsg());
		if ($data_darurat_grid->SearchWhere == "0=101")
			$data_darurat_grid->setWarningMessage($Language->Phrase("EnterSearchCriteria"));
		else
			$data_darurat_grid->setWarningMessage($Language->Phrase("NoRecord"));
	}
}
$data_darurat_grid->RenderOtherOptions();
?>
<?php $data_darurat_grid->ShowPageHeader(); ?>
<?php
$data_darurat_grid->ShowMessage();
?>
<?php if ($data_darurat_grid->TotalRecs > 0 || $data_darurat->CurrentAction <> "") { ?>
<div class="panel panel-default ewGrid data_darurat">
<div id="fdata_daruratgrid" class="ewForm form-inline">
<?php if ($data_darurat_grid->ShowOtherOptions) { ?>
<div class="panel-heading ewGridUpperPanel">
<?php
	foreach ($data_darurat_grid->OtherOptions as &$option)
		$option->Render("body");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<div id="gmp_data_darurat" class="<?php if (ew_IsResponsiveLayout()) { echo "table-responsive "; } ?>ewGridMiddlePanel">
<table id="tbl_data_daruratgrid" class="table ewTable">
<?php echo $data_darurat->TableCustomInnerHtml ?>
<thead><!-- Table header -->
	<tr class="ewTableHeader">
<?php

// Header row
$data_darurat_grid->RowType = EW_ROWTYPE_HEADER;

// Render list options
$data_darurat_grid->RenderListOptions();

// Render list options (header, left)
$data_darurat_grid->ListOptions->Render("header", "left");
?>
<?php if ($data_darurat->Nama->Visible) { // Nama ?>
	<?php if ($data_darurat->SortUrl($data_darurat->Nama) == "") { ?>
		<th data-name="Nama"><div id="elh_data_darurat_Nama" class="data_darurat_Nama"><div class="ewTableHeaderCaption"><?php echo $data_darurat->Nama->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Nama"><div><div id="elh_data_darurat_Nama" class="data_darurat_Nama">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_darurat->Nama->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_darurat->Nama->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_darurat->Nama->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($data_darurat->Alamat->Visible) { // Alamat ?>
	<?php if ($data_darurat->SortUrl($data_darurat->Alamat) == "") { ?>
		<th data-name="Alamat"><div id="elh_data_darurat_Alamat" class="data_darurat_Alamat"><div class="ewTableHeaderCaption"><?php echo $data_darurat->Alamat->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Alamat"><div><div id="elh_data_darurat_Alamat" class="data_darurat_Alamat">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_darurat->Alamat->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_darurat->Alamat->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_darurat->Alamat->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($data_darurat->Telp->Visible) { // Telp ?>
	<?php if ($data_darurat->SortUrl($data_darurat->Telp) == "") { ?>
		<th data-name="Telp"><div id="elh_data_darurat_Telp" class="data_darurat_Telp"><div class="ewTableHeaderCaption"><?php echo $data_darurat->Telp->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Telp"><div><div id="elh_data_darurat_Telp" class="data_darurat_Telp">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_darurat->Telp->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_darurat->Telp->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_darurat->Telp->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($data_darurat->Hubungan->Visible) { // Hubungan ?>
	<?php if ($data_darurat->SortUrl($data_darurat->Hubungan) == "") { ?>
		<th data-name="Hubungan"><div id="elh_data_darurat_Hubungan" class="data_darurat_Hubungan"><div class="ewTableHeaderCaption"><?php echo $data_darurat->Hubungan->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Hubungan"><div><div id="elh_data_darurat_Hubungan" class="data_darurat_Hubungan">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_darurat->Hubungan->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_darurat->Hubungan->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_darurat->Hubungan->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php

// Render list options (header, right)
$data_darurat_grid->ListOptions->Render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$data_darurat_grid->StartRec = 1;
$data_darurat_grid->StopRec = $data_darurat_grid->TotalRecs; // Show all records

// Restore number of post back records
if ($objForm) {
	$objForm->Index = -1;
	if ($objForm->HasValue($data_darurat_grid->FormKeyCountName) && ($data_darurat->CurrentAction == "gridadd" || $data_darurat->CurrentAction == "gridedit" || $data_darurat->CurrentAction == "F")) {
		$data_darurat_grid->KeyCount = $objForm->GetValue($data_darurat_grid->FormKeyCountName);
		$data_darurat_grid->StopRec = $data_darurat_grid->StartRec + $data_darurat_grid->KeyCount - 1;
	}
}
$data_darurat_grid->RecCnt = $data_darurat_grid->StartRec - 1;
if ($data_darurat_grid->Recordset && !$data_darurat_grid->Recordset->EOF) {
	$data_darurat_grid->Recordset->MoveFirst();
	$bSelectLimit = $data_darurat_grid->UseSelectLimit;
	if (!$bSelectLimit && $data_darurat_grid->StartRec > 1)
		$data_darurat_grid->Recordset->Move($data_darurat_grid->StartRec - 1);
} elseif (!$data_darurat->AllowAddDeleteRow && $data_darurat_grid->StopRec == 0) {
	$data_darurat_grid->StopRec = $data_darurat->GridAddRowCount;
}

// Initialize aggregate
$data_darurat->RowType = EW_ROWTYPE_AGGREGATEINIT;
$data_darurat->ResetAttrs();
$data_darurat_grid->RenderRow();
if ($data_darurat->CurrentAction == "gridadd")
	$data_darurat_grid->RowIndex = 0;
if ($data_darurat->CurrentAction == "gridedit")
	$data_darurat_grid->RowIndex = 0;
while ($data_darurat_grid->RecCnt < $data_darurat_grid->StopRec) {
	$data_darurat_grid->RecCnt++;
	if (intval($data_darurat_grid->RecCnt) >= intval($data_darurat_grid->StartRec)) {
		$data_darurat_grid->RowCnt++;
		if ($data_darurat->CurrentAction == "gridadd" || $data_darurat->CurrentAction == "gridedit" || $data_darurat->CurrentAction == "F") {
			$data_darurat_grid->RowIndex++;
			$objForm->Index = $data_darurat_grid->RowIndex;
			if ($objForm->HasValue($data_darurat_grid->FormActionName))
				$data_darurat_grid->RowAction = strval($objForm->GetValue($data_darurat_grid->FormActionName));
			elseif ($data_darurat->CurrentAction == "gridadd")
				$data_darurat_grid->RowAction = "insert";
			else
				$data_darurat_grid->RowAction = "";
		}

		// Set up key count
		$data_darurat_grid->KeyCount = $data_darurat_grid->RowIndex;

		// Init row class and style
		$data_darurat->ResetAttrs();
		$data_darurat->CssClass = "";
		if ($data_darurat->CurrentAction == "gridadd") {
			if ($data_darurat->CurrentMode == "copy") {
				$data_darurat_grid->LoadRowValues($data_darurat_grid->Recordset); // Load row values
				$data_darurat_grid->SetRecordKey($data_darurat_grid->RowOldKey, $data_darurat_grid->Recordset); // Set old record key
			} else {
				$data_darurat_grid->LoadDefaultValues(); // Load default values
				$data_darurat_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$data_darurat_grid->LoadRowValues($data_darurat_grid->Recordset); // Load row values
		}
		$data_darurat->RowType = EW_ROWTYPE_VIEW; // Render view
		if ($data_darurat->CurrentAction == "gridadd") // Grid add
			$data_darurat->RowType = EW_ROWTYPE_ADD; // Render add
		if ($data_darurat->CurrentAction == "gridadd" && $data_darurat->EventCancelled && !$objForm->HasValue("k_blankrow")) // Insert failed
			$data_darurat_grid->RestoreCurrentRowFormValues($data_darurat_grid->RowIndex); // Restore form values
		if ($data_darurat->CurrentAction == "gridedit") { // Grid edit
			if ($data_darurat->EventCancelled) {
				$data_darurat_grid->RestoreCurrentRowFormValues($data_darurat_grid->RowIndex); // Restore form values
			}
			if ($data_darurat_grid->RowAction == "insert")
				$data_darurat->RowType = EW_ROWTYPE_ADD; // Render add
			else
				$data_darurat->RowType = EW_ROWTYPE_EDIT; // Render edit
		}
		if ($data_darurat->CurrentAction == "gridedit" && ($data_darurat->RowType == EW_ROWTYPE_EDIT || $data_darurat->RowType == EW_ROWTYPE_ADD) && $data_darurat->EventCancelled) // Update failed
			$data_darurat_grid->RestoreCurrentRowFormValues($data_darurat_grid->RowIndex); // Restore form values
		if ($data_darurat->RowType == EW_ROWTYPE_EDIT) // Edit row
			$data_darurat_grid->EditRowCnt++;
		if ($data_darurat->CurrentAction == "F") // Confirm row
			$data_darurat_grid->RestoreCurrentRowFormValues($data_darurat_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$data_darurat->RowAttrs = array_merge($data_darurat->RowAttrs, array('data-rowindex'=>$data_darurat_grid->RowCnt, 'id'=>'r' . $data_darurat_grid->RowCnt . '_data_darurat', 'data-rowtype'=>$data_darurat->RowType));

		// Render row
		$data_darurat_grid->RenderRow();

		// Render list options
		$data_darurat_grid->RenderListOptions();

		// Skip delete row / empty row for confirm page
		if ($data_darurat_grid->RowAction <> "delete" && $data_darurat_grid->RowAction <> "insertdelete" && !($data_darurat_grid->RowAction == "insert" && $data_darurat->CurrentAction == "F" && $data_darurat_grid->EmptyRow())) {
?>
	<tr<?php echo $data_darurat->RowAttributes() ?>>
<?php

// Render list options (body, left)
$data_darurat_grid->ListOptions->Render("body", "left", $data_darurat_grid->RowCnt);
?>
	<?php if ($data_darurat->Nama->Visible) { // Nama ?>
		<td data-name="Nama"<?php echo $data_darurat->Nama->CellAttributes() ?>>
<?php if ($data_darurat->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Nama" class="form-group data_darurat_Nama">
<input type="text" data-table="data_darurat" data-field="x_Nama" name="x<?php echo $data_darurat_grid->RowIndex ?>_Nama" id="x<?php echo $data_darurat_grid->RowIndex ?>_Nama" size="30" maxlength="100" value="<?php echo $data_darurat->Nama->EditValue ?>"<?php echo $data_darurat->Nama->EditAttributes() ?>>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Nama" name="o<?php echo $data_darurat_grid->RowIndex ?>_Nama" id="o<?php echo $data_darurat_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_darurat->Nama->OldValue) ?>">
<?php } ?>
<?php if ($data_darurat->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Nama" class="form-group data_darurat_Nama">
<input type="text" data-table="data_darurat" data-field="x_Nama" name="x<?php echo $data_darurat_grid->RowIndex ?>_Nama" id="x<?php echo $data_darurat_grid->RowIndex ?>_Nama" size="30" maxlength="100" value="<?php echo $data_darurat->Nama->EditValue ?>"<?php echo $data_darurat->Nama->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($data_darurat->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Nama" class="data_darurat_Nama">
<span<?php echo $data_darurat->Nama->ViewAttributes() ?>>
<?php echo $data_darurat->Nama->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Nama" name="x<?php echo $data_darurat_grid->RowIndex ?>_Nama" id="x<?php echo $data_darurat_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_darurat->Nama->FormValue) ?>">
<input type="hidden" data-table="data_darurat" data-field="x_Nama" name="o<?php echo $data_darurat_grid->RowIndex ?>_Nama" id="o<?php echo $data_darurat_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_darurat->Nama->OldValue) ?>">
<?php } ?>
<a id="<?php echo $data_darurat_grid->PageObjName . "_row_" . $data_darurat_grid->RowCnt ?>"></a></td>
	<?php } ?>
<?php if ($data_darurat->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<input type="hidden" data-table="data_darurat" data-field="x_No" name="x<?php echo $data_darurat_grid->RowIndex ?>_No" id="x<?php echo $data_darurat_grid->RowIndex ?>_No" value="<?php echo ew_HtmlEncode($data_darurat->No->CurrentValue) ?>">
<input type="hidden" data-table="data_darurat" data-field="x_No" name="o<?php echo $data_darurat_grid->RowIndex ?>_No" id="o<?php echo $data_darurat_grid->RowIndex ?>_No" value="<?php echo ew_HtmlEncode($data_darurat->No->OldValue) ?>">
<?php } ?>
<?php if ($data_darurat->RowType == EW_ROWTYPE_EDIT || $data_darurat->CurrentMode == "edit") { ?>
<input type="hidden" data-table="data_darurat" data-field="x_No" name="x<?php echo $data_darurat_grid->RowIndex ?>_No" id="x<?php echo $data_darurat_grid->RowIndex ?>_No" value="<?php echo ew_HtmlEncode($data_darurat->No->CurrentValue) ?>">
<?php } ?>
	<?php if ($data_darurat->Alamat->Visible) { // Alamat ?>
		<td data-name="Alamat"<?php echo $data_darurat->Alamat->CellAttributes() ?>>
<?php if ($data_darurat->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Alamat" class="form-group data_darurat_Alamat">
<textarea data-table="data_darurat" data-field="x_Alamat" name="x<?php echo $data_darurat_grid->RowIndex ?>_Alamat" id="x<?php echo $data_darurat_grid->RowIndex ?>_Alamat" cols="35" rows="4"<?php echo $data_darurat->Alamat->EditAttributes() ?>><?php echo $data_darurat->Alamat->EditValue ?></textarea>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Alamat" name="o<?php echo $data_darurat_grid->RowIndex ?>_Alamat" id="o<?php echo $data_darurat_grid->RowIndex ?>_Alamat" value="<?php echo ew_HtmlEncode($data_darurat->Alamat->OldValue) ?>">
<?php } ?>
<?php if ($data_darurat->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Alamat" class="form-group data_darurat_Alamat">
<textarea data-table="data_darurat" data-field="x_Alamat" name="x<?php echo $data_darurat_grid->RowIndex ?>_Alamat" id="x<?php echo $data_darurat_grid->RowIndex ?>_Alamat" cols="35" rows="4"<?php echo $data_darurat->Alamat->EditAttributes() ?>><?php echo $data_darurat->Alamat->EditValue ?></textarea>
</span>
<?php } ?>
<?php if ($data_darurat->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Alamat" class="data_darurat_Alamat">
<span<?php echo $data_darurat->Alamat->ViewAttributes() ?>>
<?php echo $data_darurat->Alamat->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Alamat" name="x<?php echo $data_darurat_grid->RowIndex ?>_Alamat" id="x<?php echo $data_darurat_grid->RowIndex ?>_Alamat" value="<?php echo ew_HtmlEncode($data_darurat->Alamat->FormValue) ?>">
<input type="hidden" data-table="data_darurat" data-field="x_Alamat" name="o<?php echo $data_darurat_grid->RowIndex ?>_Alamat" id="o<?php echo $data_darurat_grid->RowIndex ?>_Alamat" value="<?php echo ew_HtmlEncode($data_darurat->Alamat->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($data_darurat->Telp->Visible) { // Telp ?>
		<td data-name="Telp"<?php echo $data_darurat->Telp->CellAttributes() ?>>
<?php if ($data_darurat->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Telp" class="form-group data_darurat_Telp">
<input type="text" data-table="data_darurat" data-field="x_Telp" name="x<?php echo $data_darurat_grid->RowIndex ?>_Telp" id="x<?php echo $data_darurat_grid->RowIndex ?>_Telp" size="30" maxlength="30" value="<?php echo $data_darurat->Telp->EditValue ?>"<?php echo $data_darurat->Telp->EditAttributes() ?>>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Telp" name="o<?php echo $data_darurat_grid->RowIndex ?>_Telp" id="o<?php echo $data_darurat_grid->RowIndex ?>_Telp" value="<?php echo ew_HtmlEncode($data_darurat->Telp->OldValue) ?>">
<?php } ?>
<?php if ($data_darurat->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Telp" class="form-group data_darurat_Telp">
<input type="text" data-table="data_darurat" data-field="x_Telp" name="x<?php echo $data_darurat_grid->RowIndex ?>_Telp" id="x<?php echo $data_darurat_grid->RowIndex ?>_Telp" size="30" maxlength="30" value="<?php echo $data_darurat->Telp->EditValue ?>"<?php echo $data_darurat->Telp->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($data_darurat->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Telp" class="data_darurat_Telp">
<span<?php echo $data_darurat->Telp->ViewAttributes() ?>>
<?php echo $data_darurat->Telp->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Telp" name="x<?php echo $data_darurat_grid->RowIndex ?>_Telp" id="x<?php echo $data_darurat_grid->RowIndex ?>_Telp" value="<?php echo ew_HtmlEncode($data_darurat->Telp->FormValue) ?>">
<input type="hidden" data-table="data_darurat" data-field="x_Telp" name="o<?php echo $data_darurat_grid->RowIndex ?>_Telp" id="o<?php echo $data_darurat_grid->RowIndex ?>_Telp" value="<?php echo ew_HtmlEncode($data_darurat->Telp->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($data_darurat->Hubungan->Visible) { // Hubungan ?>
		<td data-name="Hubungan"<?php echo $data_darurat->Hubungan->CellAttributes() ?>>
<?php if ($data_darurat->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Hubungan" class="form-group data_darurat_Hubungan">
<input type="text" data-table="data_darurat" data-field="x_Hubungan" name="x<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" id="x<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" size="30" maxlength="50" value="<?php echo $data_darurat->Hubungan->EditValue ?>"<?php echo $data_darurat->Hubungan->EditAttributes() ?>>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Hubungan" name="o<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" id="o<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" value="<?php echo ew_HtmlEncode($data_darurat->Hubungan->OldValue) ?>">
<?php } ?>
<?php if ($data_darurat->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Hubungan" class="form-group data_darurat_Hubungan">
<input type="text" data-table="data_darurat" data-field="x_Hubungan" name="x<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" id="x<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" size="30" maxlength="50" value="<?php echo $data_darurat->Hubungan->EditValue ?>"<?php echo $data_darurat->Hubungan->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($data_darurat->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_darurat_grid->RowCnt ?>_data_darurat_Hubungan" class="data_darurat_Hubungan">
<span<?php echo $data_darurat->Hubungan->ViewAttributes() ?>>
<?php echo $data_darurat->Hubungan->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Hubungan" name="x<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" id="x<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" value="<?php echo ew_HtmlEncode($data_darurat->Hubungan->FormValue) ?>">
<input type="hidden" data-table="data_darurat" data-field="x_Hubungan" name="o<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" id="o<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" value="<?php echo ew_HtmlEncode($data_darurat->Hubungan->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$data_darurat_grid->ListOptions->Render("body", "right", $data_darurat_grid->RowCnt);
?>
	</tr>
<?php if ($data_darurat->RowType == EW_ROWTYPE_ADD || $data_darurat->RowType == EW_ROWTYPE_EDIT) { ?>
<script type="text/javascript">
fdata_daruratgrid.UpdateOpts(<?php echo $data_darurat_grid->RowIndex ?>);
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if ($data_darurat->CurrentAction <> "gridadd" || $data_darurat->CurrentMode == "copy")
		if (!$data_darurat_grid->Recordset->EOF) $data_darurat_grid->Recordset->MoveNext();
}
?>
<?php
	if ($data_darurat->CurrentMode == "add" || $data_darurat->CurrentMode == "copy" || $data_darurat->CurrentMode == "edit") {
		$data_darurat_grid->RowIndex = '$rowindex$';
		$data_darurat_grid->LoadDefaultValues();

		// Set row properties
		$data_darurat->ResetAttrs();
		$data_darurat->RowAttrs = array_merge($data_darurat->RowAttrs, array('data-rowindex'=>$data_darurat_grid->RowIndex, 'id'=>'r0_data_darurat', 'data-rowtype'=>EW_ROWTYPE_ADD));
		ew_AppendClass($data_darurat->RowAttrs["class"], "ewTemplate");
		$data_darurat->RowType = EW_ROWTYPE_ADD;

		// Render row
		$data_darurat_grid->RenderRow();

		// Render list options
		$data_darurat_grid->RenderListOptions();
		$data_darurat_grid->StartRowCnt = 0;
?>
	<tr<?php echo $data_darurat->RowAttributes() ?>>
<?php

// Render list options (body, left)
$data_darurat_grid->ListOptions->Render("body", "left", $data_darurat_grid->RowIndex);
?>
	<?php if ($data_darurat->Nama->Visible) { // Nama ?>
		<td data-name="Nama">
<?php if ($data_darurat->CurrentAction <> "F") { ?>
<span id="el$rowindex$_data_darurat_Nama" class="form-group data_darurat_Nama">
<input type="text" data-table="data_darurat" data-field="x_Nama" name="x<?php echo $data_darurat_grid->RowIndex ?>_Nama" id="x<?php echo $data_darurat_grid->RowIndex ?>_Nama" size="30" maxlength="100" value="<?php echo $data_darurat->Nama->EditValue ?>"<?php echo $data_darurat->Nama->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_data_darurat_Nama" class="form-group data_darurat_Nama">
<span<?php echo $data_darurat->Nama->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_darurat->Nama->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Nama" name="x<?php echo $data_darurat_grid->RowIndex ?>_Nama" id="x<?php echo $data_darurat_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_darurat->Nama->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_darurat" data-field="x_Nama" name="o<?php echo $data_darurat_grid->RowIndex ?>_Nama" id="o<?php echo $data_darurat_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_darurat->Nama->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($data_darurat->Alamat->Visible) { // Alamat ?>
		<td data-name="Alamat">
<?php if ($data_darurat->CurrentAction <> "F") { ?>
<span id="el$rowindex$_data_darurat_Alamat" class="form-group data_darurat_Alamat">
<textarea data-table="data_darurat" data-field="x_Alamat" name="x<?php echo $data_darurat_grid->RowIndex ?>_Alamat" id="x<?php echo $data_darurat_grid->RowIndex ?>_Alamat" cols="35" rows="4"<?php echo $data_darurat->Alamat->EditAttributes() ?>><?php echo $data_darurat->Alamat->EditValue ?></textarea>
</span>
<?php } else { ?>
<span id="el$rowindex$_data_darurat_Alamat" class="form-group data_darurat_Alamat">
<span<?php echo $data_darurat->Alamat->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_darurat->Alamat->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Alamat" name="x<?php echo $data_darurat_grid->RowIndex ?>_Alamat" id="x<?php echo $data_darurat_grid->RowIndex ?>_Alamat" value="<?php echo ew_HtmlEncode($data_darurat->Alamat->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_darurat" data-field="x_Alamat" name="o<?php echo $data_darurat_grid->RowIndex ?>_Alamat" id="o<?php echo $data_darurat_grid->RowIndex ?>_Alamat" value="<?php echo ew_HtmlEncode($data_darurat->Alamat->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($data_darurat->Telp->Visible) { // Telp ?>
		<td data-name="Telp">
<?php if ($data_darurat->CurrentAction <> "F") { ?>
<span id="el$rowindex$_data_darurat_Telp" class="form-group data_darurat_Telp">
<input type="text" data-table="data_darurat" data-field="x_Telp" name="x<?php echo $data_darurat_grid->RowIndex ?>_Telp" id="x<?php echo $data_darurat_grid->RowIndex ?>_Telp" size="30" maxlength="30" value="<?php echo $data_darurat->Telp->EditValue ?>"<?php echo $data_darurat->Telp->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_data_darurat_Telp" class="form-group data_darurat_Telp">
<span<?php echo $data_darurat->Telp->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_darurat->Telp->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Telp" name="x<?php echo $data_darurat_grid->RowIndex ?>_Telp" id="x<?php echo $data_darurat_grid->RowIndex ?>_Telp" value="<?php echo ew_HtmlEncode($data_darurat->Telp->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_darurat" data-field="x_Telp" name="o<?php echo $data_darurat_grid->RowIndex ?>_Telp" id="o<?php echo $data_darurat_grid->RowIndex ?>_Telp" value="<?php echo ew_HtmlEncode($data_darurat->Telp->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($data_darurat->Hubungan->Visible) { // Hubungan ?>
		<td data-name="Hubungan">
<?php if ($data_darurat->CurrentAction <> "F") { ?>
<span id="el$rowindex$_data_darurat_Hubungan" class="form-group data_darurat_Hubungan">
<input type="text" data-table="data_darurat" data-field="x_Hubungan" name="x<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" id="x<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" size="30" maxlength="50" value="<?php echo $data_darurat->Hubungan->EditValue ?>"<?php echo $data_darurat->Hubungan->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_data_darurat_Hubungan" class="form-group data_darurat_Hubungan">
<span<?php echo $data_darurat->Hubungan->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_darurat->Hubungan->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_darurat" data-field="x_Hubungan" name="x<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" id="x<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" value="<?php echo ew_HtmlEncode($data_darurat->Hubungan->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_darurat" data-field="x_Hubungan" name="o<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" id="o<?php echo $data_darurat_grid->RowIndex ?>_Hubungan" value="<?php echo ew_HtmlEncode($data_darurat->Hubungan->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$data_darurat_grid->ListOptions->Render("body", "right", $data_darurat_grid->RowCnt);
?>
<script type="text/javascript">
fdata_daruratgrid.UpdateOpts(<?php echo $data_darurat_grid->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
</tbody>
</table>
<?php if ($data_darurat->CurrentMode == "add" || $data_darurat->CurrentMode == "copy") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridinsert">
<input type="hidden" name="<?php echo $data_darurat_grid->FormKeyCountName ?>" id="<?php echo $data_darurat_grid->FormKeyCountName ?>" value="<?php echo $data_darurat_grid->KeyCount ?>">
<?php echo $data_darurat_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($data_darurat->CurrentMode == "edit") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridupdate">
<input type="hidden" name="<?php echo $data_darurat_grid->FormKeyCountName ?>" id="<?php echo $data_darurat_grid->FormKeyCountName ?>" value="<?php echo $data_darurat_grid->KeyCount ?>">
<?php echo $data_darurat_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($data_darurat->CurrentMode == "") { ?>
<input type="hidden" name="a_list" id="a_list" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fdata_daruratgrid">
</div>
<?php

// Close recordset
if ($data_darurat_grid->Recordset)
	$data_darurat_grid->Recordset->Close();
?>
<?php if ($data_darurat_grid->ShowOtherOptions) { ?>
<div class="panel-footer ewGridLowerPanel">
<?php
	foreach ($data_darurat_grid->OtherOptions as &$option)
		$option->Render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div>
</div>
<?php } ?>
<?php if ($data_darurat_grid->TotalRecs == 0 && $data_darurat->CurrentAction == "") { // Show other options ?>
<div class="ewListOtherOptions">
<?php
	foreach ($data_darurat_grid->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->Render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if ($data_darurat->Export == "") { ?>
<script type="text/javascript">
fdata_daruratgrid.Init();
</script>
<?php } ?>
<?php
$data_darurat_grid->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<?php
$data_darurat_grid->Page_Terminate();
?>
