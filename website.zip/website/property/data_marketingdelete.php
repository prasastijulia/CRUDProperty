<?php
if (session_id() == "") session_start(); // Init session data
ob_start(); // Turn on output buffering
?>
<?php include_once "ewcfg13.php" ?>
<?php include_once ((EW_USE_ADODB) ? "adodb5/adodb.inc.php" : "ewmysql13.php") ?>
<?php include_once "phpfn13.php" ?>
<?php include_once "data_marketinginfo.php" ?>
<?php include_once "admininfo.php" ?>
<?php include_once "userfn13.php" ?>
<?php

//
// Page class
//

$data_marketing_delete = NULL; // Initialize page object first

class cdata_marketing_delete extends cdata_marketing {

	// Page ID
	var $PageID = 'delete';

	// Project ID
	var $ProjectID = "{1B30E8D9-D363-49E8-A880-2B04CACE607B}";

	// Table name
	var $TableName = 'data_marketing';

	// Page object name
	var $PageObjName = 'data_marketing_delete';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		if ($this->UseTokenInUrl) $PageUrl .= "t=" . $this->TableVar . "&"; // Add page token
		return $PageUrl;
	}

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_MESSAGE], $v);
	}

	function getFailureMessage() {
		return @$_SESSION[EW_SESSION_FAILURE_MESSAGE];
	}

	function setFailureMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_FAILURE_MESSAGE], $v);
	}

	function getSuccessMessage() {
		return @$_SESSION[EW_SESSION_SUCCESS_MESSAGE];
	}

	function setSuccessMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_SUCCESS_MESSAGE], $v);
	}

	function getWarningMessage() {
		return @$_SESSION[EW_SESSION_WARNING_MESSAGE];
	}

	function setWarningMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_WARNING_MESSAGE], $v);
	}

	// Methods to clear message
	function ClearMessage() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
	}

	function ClearFailureMessage() {
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
	}

	function ClearSuccessMessage() {
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
	}

	function ClearWarningMessage() {
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	function ClearMessages() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	// Show message
	function ShowMessage() {
		$hidden = TRUE;
		$html = "";

		// Message
		$sMessage = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sMessage, "");
		if ($sMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sMessage;
			$html .= "<div class=\"alert alert-info ewInfo\">" . $sMessage . "</div>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$sWarningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sWarningMessage, "warning");
		if ($sWarningMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sWarningMessage;
			$html .= "<div class=\"alert alert-warning ewWarning\">" . $sWarningMessage . "</div>";
			$_SESSION[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$sSuccessMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sSuccessMessage, "success");
		if ($sSuccessMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sSuccessMessage;
			$html .= "<div class=\"alert alert-success ewSuccess\">" . $sSuccessMessage . "</div>";
			$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$sErrorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sErrorMessage, "failure");
		if ($sErrorMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sErrorMessage;
			$html .= "<div class=\"alert alert-danger ewError\">" . $sErrorMessage . "</div>";
			$_SESSION[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo "<div class=\"ewMessageDialog\"" . (($hidden) ? " style=\"display: none;\"" : "") . ">" . $html . "</div>";
	}
	var $PageHeader;
	var $PageFooter;

	// Show Page Header
	function ShowPageHeader() {
		$sHeader = $this->PageHeader;
		$this->Page_DataRendering($sHeader);
		if ($sHeader <> "") { // Header exists, display
			echo "<p>" . $sHeader . "</p>";
		}
	}

	// Show Page Footer
	function ShowPageFooter() {
		$sFooter = $this->PageFooter;
		$this->Page_DataRendered($sFooter);
		if ($sFooter <> "") { // Footer exists, display
			echo "<p>" . $sFooter . "</p>";
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm;
		if ($this->UseTokenInUrl) {
			if ($objForm)
				return ($this->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($this->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}
	var $Token = "";
	var $TokenTimeout = 0;
	var $CheckToken = EW_CHECK_TOKEN;
	var $CheckTokenFn = "ew_CheckToken";
	var $CreateTokenFn = "ew_CreateToken";

	// Valid Post
	function ValidPost() {
		if (!$this->CheckToken || !ew_IsHttpPost())
			return TRUE;
		if (!isset($_POST[EW_TOKEN_NAME]))
			return FALSE;
		$fn = $this->CheckTokenFn;
		if (is_callable($fn))
			return $fn($_POST[EW_TOKEN_NAME], $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	function CreateToken() {
		global $gsToken;
		if ($this->CheckToken) {
			$fn = $this->CreateTokenFn;
			if ($this->Token == "" && is_callable($fn)) // Create token
				$this->Token = $fn();
			$gsToken = $this->Token; // Save to global variable
		}
	}

	//
	// Page class constructor
	//
	function __construct() {
		global $conn, $Language;
		global $UserTable, $UserTableConn;
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = ew_SessionTimeoutTime();

		// Language object
		if (!isset($Language)) $Language = new cLanguage();

		// Parent constuctor
		parent::__construct();

		// Table object (data_marketing)
		if (!isset($GLOBALS["data_marketing"]) || get_class($GLOBALS["data_marketing"]) == "cdata_marketing") {
			$GLOBALS["data_marketing"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["data_marketing"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin'])) $GLOBALS['admin'] = new cadmin();

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'delete', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'data_marketing', TRUE);

		// Start timer
		if (!isset($GLOBALS["gTimer"])) $GLOBALS["gTimer"] = new cTimer();

		// Open connection
		if (!isset($conn)) $conn = ew_Connect($this->DBID);

		// User table object (admin)
		if (!isset($UserTable)) {
			$UserTable = new cadmin();
			$UserTableConn = Conn($UserTable->DBID);
		}
	}

	//
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsCustomExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;

		// Security
		$Security = new cAdvancedSecurity();
		if (!$Security->IsLoggedIn()) $Security->AutoLogin();
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loading();
		$Security->LoadCurrentUserLevel($this->ProjectID . $this->TableName);
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loaded();
		if (!$Security->CanDelete()) {
			$Security->SaveLastUrl();
			$this->setFailureMessage(ew_DeniedMsg()); // Set no permission
			if ($Security->CanList())
				$this->Page_Terminate(ew_GetUrl("data_marketinglist.php"));
			else
				$this->Page_Terminate(ew_GetUrl("login.php"));
		}
		$this->CurrentAction = (@$_GET["a"] <> "") ? $_GET["a"] : @$_POST["a_list"]; // Set up current action
		$this->No->SetVisibility();
		$this->No->Visible = !$this->IsAdd() && !$this->IsCopy() && !$this->IsGridAdd();
		$this->Nama->SetVisibility();
		$this->Alamat->SetVisibility();
		$this->No_Ktp->SetVisibility();
		$this->NPWP->SetVisibility();
		$this->Telp->SetVisibility();
		$this->Kode->SetVisibility();
		$this->Area_Listing->SetVisibility();
		$this->Alamat_Lengkap->SetVisibility();
		$this->Nama_yang_bisa_dihubungi->SetVisibility();
		$this->No_Telp->SetVisibility();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->ValidPost()) {
			echo $Language->Phrase("InvalidPostRequest");
			$this->Page_Terminate();
			exit();
		}

		// Create Token
		$this->CreateToken();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $gsExportFile, $gTmpImages;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $EW_EXPORT, $data_marketing;
		if ($this->CustomExport <> "" && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, $EW_EXPORT)) {
				$sContent = ob_get_contents();
			if ($gsExportFile == "") $gsExportFile = $this->TableVar;
			$class = $EW_EXPORT[$this->CustomExport];
			if (class_exists($class)) {
				$doc = new $class($data_marketing);
				$doc->Text = $sContent;
				if ($this->Export == "email")
					echo $this->ExportEmail($doc->Text);
				else
					$doc->Export();
				ew_DeleteTmpImages(); // Delete temp images
				exit();
			}
		}
		$this->Page_Redirecting($url);

		 // Close connection
		ew_CloseConn();

		// Go to URL if specified
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
		exit();
	}
	var $DbMasterFilter = "";
	var $DbDetailFilter = "";
	var $StartRec;
	var $TotalRecs = 0;
	var $RecCnt;
	var $RecKeys = array();
	var $Recordset;
	var $StartRowCnt = 1;
	var $RowCnt = 0;

	//
	// Page main
	//
	function Page_Main() {
		global $Language;

		// Set up Breadcrumb
		$this->SetupBreadcrumb();

		// Load key parameters
		$this->RecKeys = $this->GetRecordKeys(); // Load record keys
		$sFilter = $this->GetKeyFilter();
		if ($sFilter == "")
			$this->Page_Terminate("data_marketinglist.php"); // Prevent SQL injection, return to list

		// Set up filter (SQL WHHERE clause) and get return SQL
		// SQL constructor in data_marketing class, data_marketinginfo.php

		$this->CurrentFilter = $sFilter;

		// Get action
		if (@$_POST["a_delete"] <> "") {
			$this->CurrentAction = $_POST["a_delete"];
		} elseif (@$_GET["a_delete"] == "1") {
			$this->CurrentAction = "D"; // Delete record directly
		} else {
			$this->CurrentAction = "D"; // Delete record directly
		}
		if ($this->CurrentAction == "D") {
			$this->SendEmail = TRUE; // Send email on delete success
			if ($this->DeleteRows()) { // Delete rows
				if ($this->getSuccessMessage() == "")
					$this->setSuccessMessage($Language->Phrase("DeleteSuccess")); // Set up success message
				$this->Page_Terminate($this->getReturnUrl()); // Return to caller
			} else { // Delete failed
				$this->Page_Terminate($this->getReturnUrl()); // Return to caller
			}
		}
		if ($this->CurrentAction == "I") { // Load records for display
			if ($this->Recordset = $this->LoadRecordset())
				$this->TotalRecs = $this->Recordset->RecordCount(); // Get record count
			if ($this->TotalRecs <= 0) { // No record found, exit
				if ($this->Recordset)
					$this->Recordset->Close();
				$this->Page_Terminate("data_marketinglist.php"); // Return to list
			}
		}
	}

	// Load recordset
	function LoadRecordset($offset = -1, $rowcnt = -1) {

		// Load List page SQL
		$sSql = $this->SelectSQL();
		$conn = &$this->Connection();

		// Load recordset
		$dbtype = ew_GetConnectionType($this->DBID);
		if ($this->UseSelectLimit) {
			$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
			if ($dbtype == "MSSQL") {
				$rs = $conn->SelectLimit($sSql, $rowcnt, $offset, array("_hasOrderBy" => trim($this->getOrderBy()) || trim($this->getSessionOrderBy())));
			} else {
				$rs = $conn->SelectLimit($sSql, $rowcnt, $offset);
			}
			$conn->raiseErrorFn = '';
		} else {
			$rs = ew_LoadRecordset($sSql, $conn);
		}

		// Call Recordset Selected event
		$this->Recordset_Selected($rs);
		return $rs;
	}

	// Load row based on key values
	function LoadRow() {
		global $Security, $Language;
		$sFilter = $this->KeyFilter();

		// Call Row Selecting event
		$this->Row_Selecting($sFilter);

		// Load SQL based on filter
		$this->CurrentFilter = $sFilter;
		$sSql = $this->SQL();
		$conn = &$this->Connection();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		if (!$rs || $rs->EOF) return;

		// Call Row Selected event
		$row = &$rs->fields;
		$this->Row_Selected($row);
		$this->No->setDbValue($rs->fields('No'));
		$this->Nama->setDbValue($rs->fields('Nama'));
		$this->Alamat->setDbValue($rs->fields('Alamat'));
		$this->No_Ktp->setDbValue($rs->fields('No_Ktp'));
		$this->NPWP->setDbValue($rs->fields('NPWP'));
		$this->Telp->setDbValue($rs->fields('Telp'));
		$this->Kode->setDbValue($rs->fields('Kode'));
		$this->Area_Listing->setDbValue($rs->fields('Area_Listing'));
		$this->Alamat_Lengkap->setDbValue($rs->fields('Alamat_Lengkap'));
		$this->Nama_yang_bisa_dihubungi->setDbValue($rs->fields('Nama_yang_bisa_dihubungi'));
		$this->No_Telp->setDbValue($rs->fields('No_Telp'));
		$this->Hubungan->setDbValue($rs->fields('Hubungan'));
	}

	// Load DbValue from recordset
	function LoadDbValues(&$rs) {
		if (!$rs || !is_array($rs) && $rs->EOF) return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->No->DbValue = $row['No'];
		$this->Nama->DbValue = $row['Nama'];
		$this->Alamat->DbValue = $row['Alamat'];
		$this->No_Ktp->DbValue = $row['No_Ktp'];
		$this->NPWP->DbValue = $row['NPWP'];
		$this->Telp->DbValue = $row['Telp'];
		$this->Kode->DbValue = $row['Kode'];
		$this->Area_Listing->DbValue = $row['Area_Listing'];
		$this->Alamat_Lengkap->DbValue = $row['Alamat_Lengkap'];
		$this->Nama_yang_bisa_dihubungi->DbValue = $row['Nama_yang_bisa_dihubungi'];
		$this->No_Telp->DbValue = $row['No_Telp'];
		$this->Hubungan->DbValue = $row['Hubungan'];
	}

	// Render row values based on field settings
	function RenderRow() {
		global $Security, $Language, $gsLanguage;

		// Initialize URLs
		// Call Row_Rendering event

		$this->Row_Rendering();

		// Common render codes for all row types
		// No
		// Nama
		// Alamat
		// No_Ktp
		// NPWP
		// Telp
		// Kode
		// Area_Listing
		// Alamat_Lengkap
		// Nama_yang_bisa_dihubungi
		// No_Telp
		// Hubungan

		if ($this->RowType == EW_ROWTYPE_VIEW) { // View row

		// No
		$this->No->ViewValue = $this->No->CurrentValue;
		$this->No->ViewCustomAttributes = "";

		// Nama
		$this->Nama->ViewValue = $this->Nama->CurrentValue;
		$this->Nama->ViewCustomAttributes = "";

		// Alamat
		$this->Alamat->ViewValue = $this->Alamat->CurrentValue;
		$this->Alamat->ViewCustomAttributes = "";

		// No_Ktp
		$this->No_Ktp->ViewValue = $this->No_Ktp->CurrentValue;
		$this->No_Ktp->ViewCustomAttributes = "";

		// NPWP
		$this->NPWP->ViewValue = $this->NPWP->CurrentValue;
		$this->NPWP->ViewCustomAttributes = "";

		// Telp
		$this->Telp->ViewValue = $this->Telp->CurrentValue;
		$this->Telp->ViewCustomAttributes = "";

		// Kode
		$this->Kode->ViewValue = $this->Kode->CurrentValue;
		$this->Kode->ViewCustomAttributes = "";

		// Area_Listing
		$this->Area_Listing->ViewValue = $this->Area_Listing->CurrentValue;
		$this->Area_Listing->ViewCustomAttributes = "";

		// Alamat_Lengkap
		$this->Alamat_Lengkap->ViewValue = $this->Alamat_Lengkap->CurrentValue;
		$this->Alamat_Lengkap->ViewCustomAttributes = "";

		// Nama_yang_bisa_dihubungi
		$this->Nama_yang_bisa_dihubungi->ViewValue = $this->Nama_yang_bisa_dihubungi->CurrentValue;
		$this->Nama_yang_bisa_dihubungi->ViewCustomAttributes = "";

		// No_Telp
		$this->No_Telp->ViewValue = $this->No_Telp->CurrentValue;
		$this->No_Telp->ViewCustomAttributes = "";

			// No
			$this->No->LinkCustomAttributes = "";
			$this->No->HrefValue = "";
			$this->No->TooltipValue = "";

			// Nama
			$this->Nama->LinkCustomAttributes = "";
			$this->Nama->HrefValue = "";
			$this->Nama->TooltipValue = "";

			// Alamat
			$this->Alamat->LinkCustomAttributes = "";
			$this->Alamat->HrefValue = "";
			$this->Alamat->TooltipValue = "";

			// No_Ktp
			$this->No_Ktp->LinkCustomAttributes = "";
			$this->No_Ktp->HrefValue = "";
			$this->No_Ktp->TooltipValue = "";

			// NPWP
			$this->NPWP->LinkCustomAttributes = "";
			$this->NPWP->HrefValue = "";
			$this->NPWP->TooltipValue = "";

			// Telp
			$this->Telp->LinkCustomAttributes = "";
			$this->Telp->HrefValue = "";
			$this->Telp->TooltipValue = "";

			// Kode
			$this->Kode->LinkCustomAttributes = "";
			$this->Kode->HrefValue = "";
			$this->Kode->TooltipValue = "";

			// Area_Listing
			$this->Area_Listing->LinkCustomAttributes = "";
			$this->Area_Listing->HrefValue = "";
			$this->Area_Listing->TooltipValue = "";

			// Alamat_Lengkap
			$this->Alamat_Lengkap->LinkCustomAttributes = "";
			$this->Alamat_Lengkap->HrefValue = "";
			$this->Alamat_Lengkap->TooltipValue = "";

			// Nama_yang_bisa_dihubungi
			$this->Nama_yang_bisa_dihubungi->LinkCustomAttributes = "";
			$this->Nama_yang_bisa_dihubungi->HrefValue = "";
			$this->Nama_yang_bisa_dihubungi->TooltipValue = "";

			// No_Telp
			$this->No_Telp->LinkCustomAttributes = "";
			$this->No_Telp->HrefValue = "";
			$this->No_Telp->TooltipValue = "";
		}

		// Call Row Rendered event
		if ($this->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	//
	// Delete records based on current filter
	//
	function DeleteRows() {
		global $Language, $Security;
		if (!$Security->CanDelete()) {
			$this->setFailureMessage($Language->Phrase("NoDeletePermission")); // No delete permission
			return FALSE;
		}
		$DeleteRows = TRUE;
		$sSql = $this->SQL();
		$conn = &$this->Connection();
		$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
		$rs = $conn->Execute($sSql);
		$conn->raiseErrorFn = '';
		if ($rs === FALSE) {
			return FALSE;
		} elseif ($rs->EOF) {
			$this->setFailureMessage($Language->Phrase("NoRecord")); // No record found
			$rs->Close();
			return FALSE;

		//} else {
		//	$this->LoadRowValues($rs); // Load row values

		}
		$rows = ($rs) ? $rs->GetRows() : array();
		$conn->BeginTrans();

		// Clone old rows
		$rsold = $rows;
		if ($rs)
			$rs->Close();

		// Call row deleting event
		if ($DeleteRows) {
			foreach ($rsold as $row) {
				$DeleteRows = $this->Row_Deleting($row);
				if (!$DeleteRows) break;
			}
		}
		if ($DeleteRows) {
			$sKey = "";
			foreach ($rsold as $row) {
				$sThisKey = "";
				if ($sThisKey <> "") $sThisKey .= $GLOBALS["EW_COMPOSITE_KEY_SEPARATOR"];
				$sThisKey .= $row['No'];
				$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
				$DeleteRows = $this->Delete($row); // Delete
				$conn->raiseErrorFn = '';
				if ($DeleteRows === FALSE)
					break;
				if ($sKey <> "") $sKey .= ", ";
				$sKey .= $sThisKey;
			}
		} else {

			// Set up error message
			if ($this->getSuccessMessage() <> "" || $this->getFailureMessage() <> "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage <> "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->Phrase("DeleteCancelled"));
			}
		}
		if ($DeleteRows) {
			$conn->CommitTrans(); // Commit the changes
		} else {
			$conn->RollbackTrans(); // Rollback changes
		}

		// Call Row Deleted event
		if ($DeleteRows) {
			foreach ($rsold as $row) {
				$this->Row_Deleted($row);
			}
		}
		return $DeleteRows;
	}

	// Set up Breadcrumb
	function SetupBreadcrumb() {
		global $Breadcrumb, $Language;
		$Breadcrumb = new cBreadcrumb();
		$url = substr(ew_CurrentUrl(), strrpos(ew_CurrentUrl(), "/")+1);
		$Breadcrumb->Add("list", $this->TableVar, $this->AddMasterUrl("data_marketinglist.php"), "", $this->TableVar, TRUE);
		$PageId = "delete";
		$Breadcrumb->Add("delete", $PageId, $url);
	}

	// Setup lookup filters of a field
	function SetupLookupFilters($fld, $pageId = null) {
		global $gsLanguage;
		$pageId = $pageId ?: $this->PageID;
		switch ($fld->FldVar) {
		}
	}

	// Setup AutoSuggest filters of a field
	function SetupAutoSuggestFilters($fld, $pageId = null) {
		global $gsLanguage;
		$pageId = $pageId ?: $this->PageID;
		switch ($fld->FldVar) {
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}
}
?>
<?php ew_Header(FALSE) ?>
<?php

// Create page object
if (!isset($data_marketing_delete)) $data_marketing_delete = new cdata_marketing_delete();

// Page init
$data_marketing_delete->Page_Init();

// Page main
$data_marketing_delete->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$data_marketing_delete->Page_Render();
?>
<?php include_once "header.php" ?>
<script type="text/javascript">

// Form object
var CurrentPageID = EW_PAGE_ID = "delete";
var CurrentForm = fdata_marketingdelete = new ew_Form("fdata_marketingdelete", "delete");

// Form_CustomValidate event
fdata_marketingdelete.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fdata_marketingdelete.ValidateRequired = true;
<?php } else { ?>
fdata_marketingdelete.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
// Form object for search

</script>
<script type="text/javascript">

// Write your client script here, no need to add script tags.
</script>
<div class="ewToolbar">
<?php $Breadcrumb->Render(); ?>
<?php echo $Language->SelectionForm(); ?>
<div class="clearfix"></div>
</div>
<?php $data_marketing_delete->ShowPageHeader(); ?>
<?php
$data_marketing_delete->ShowMessage();
?>
<form name="fdata_marketingdelete" id="fdata_marketingdelete" class="form-inline ewForm ewDeleteForm" action="<?php echo ew_CurrentPage() ?>" method="post">
<?php if ($data_marketing_delete->CheckToken) { ?>
<input type="hidden" name="<?php echo EW_TOKEN_NAME ?>" value="<?php echo $data_marketing_delete->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="data_marketing">
<input type="hidden" name="a_delete" id="a_delete" value="D">
<?php foreach ($data_marketing_delete->RecKeys as $key) { ?>
<?php $keyvalue = is_array($key) ? implode($EW_COMPOSITE_KEY_SEPARATOR, $key) : $key; ?>
<input type="hidden" name="key_m[]" value="<?php echo ew_HtmlEncode($keyvalue) ?>">
<?php } ?>
<div class="ewGrid">
<div class="<?php if (ew_IsResponsiveLayout()) { echo "table-responsive "; } ?>ewGridMiddlePanel">
<table class="table ewTable">
<?php echo $data_marketing->TableCustomInnerHtml ?>
	<thead>
	<tr class="ewTableHeader">
<?php if ($data_marketing->No->Visible) { // No ?>
		<th><span id="elh_data_marketing_No" class="data_marketing_No"><?php echo $data_marketing->No->FldCaption() ?></span></th>
<?php } ?>
<?php if ($data_marketing->Nama->Visible) { // Nama ?>
		<th><span id="elh_data_marketing_Nama" class="data_marketing_Nama"><?php echo $data_marketing->Nama->FldCaption() ?></span></th>
<?php } ?>
<?php if ($data_marketing->Alamat->Visible) { // Alamat ?>
		<th><span id="elh_data_marketing_Alamat" class="data_marketing_Alamat"><?php echo $data_marketing->Alamat->FldCaption() ?></span></th>
<?php } ?>
<?php if ($data_marketing->No_Ktp->Visible) { // No_Ktp ?>
		<th><span id="elh_data_marketing_No_Ktp" class="data_marketing_No_Ktp"><?php echo $data_marketing->No_Ktp->FldCaption() ?></span></th>
<?php } ?>
<?php if ($data_marketing->NPWP->Visible) { // NPWP ?>
		<th><span id="elh_data_marketing_NPWP" class="data_marketing_NPWP"><?php echo $data_marketing->NPWP->FldCaption() ?></span></th>
<?php } ?>
<?php if ($data_marketing->Telp->Visible) { // Telp ?>
		<th><span id="elh_data_marketing_Telp" class="data_marketing_Telp"><?php echo $data_marketing->Telp->FldCaption() ?></span></th>
<?php } ?>
<?php if ($data_marketing->Kode->Visible) { // Kode ?>
		<th><span id="elh_data_marketing_Kode" class="data_marketing_Kode"><?php echo $data_marketing->Kode->FldCaption() ?></span></th>
<?php } ?>
<?php if ($data_marketing->Area_Listing->Visible) { // Area_Listing ?>
		<th><span id="elh_data_marketing_Area_Listing" class="data_marketing_Area_Listing"><?php echo $data_marketing->Area_Listing->FldCaption() ?></span></th>
<?php } ?>
<?php if ($data_marketing->Alamat_Lengkap->Visible) { // Alamat_Lengkap ?>
		<th><span id="elh_data_marketing_Alamat_Lengkap" class="data_marketing_Alamat_Lengkap"><?php echo $data_marketing->Alamat_Lengkap->FldCaption() ?></span></th>
<?php } ?>
<?php if ($data_marketing->Nama_yang_bisa_dihubungi->Visible) { // Nama_yang_bisa_dihubungi ?>
		<th><span id="elh_data_marketing_Nama_yang_bisa_dihubungi" class="data_marketing_Nama_yang_bisa_dihubungi"><?php echo $data_marketing->Nama_yang_bisa_dihubungi->FldCaption() ?></span></th>
<?php } ?>
<?php if ($data_marketing->No_Telp->Visible) { // No_Telp ?>
		<th><span id="elh_data_marketing_No_Telp" class="data_marketing_No_Telp"><?php echo $data_marketing->No_Telp->FldCaption() ?></span></th>
<?php } ?>
	</tr>
	</thead>
	<tbody>
<?php
$data_marketing_delete->RecCnt = 0;
$i = 0;
while (!$data_marketing_delete->Recordset->EOF) {
	$data_marketing_delete->RecCnt++;
	$data_marketing_delete->RowCnt++;

	// Set row properties
	$data_marketing->ResetAttrs();
	$data_marketing->RowType = EW_ROWTYPE_VIEW; // View

	// Get the field contents
	$data_marketing_delete->LoadRowValues($data_marketing_delete->Recordset);

	// Render row
	$data_marketing_delete->RenderRow();
?>
	<tr<?php echo $data_marketing->RowAttributes() ?>>
<?php if ($data_marketing->No->Visible) { // No ?>
		<td<?php echo $data_marketing->No->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_No" class="data_marketing_No">
<span<?php echo $data_marketing->No->ViewAttributes() ?>>
<?php echo $data_marketing->No->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Nama->Visible) { // Nama ?>
		<td<?php echo $data_marketing->Nama->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_Nama" class="data_marketing_Nama">
<span<?php echo $data_marketing->Nama->ViewAttributes() ?>>
<?php echo $data_marketing->Nama->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Alamat->Visible) { // Alamat ?>
		<td<?php echo $data_marketing->Alamat->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_Alamat" class="data_marketing_Alamat">
<span<?php echo $data_marketing->Alamat->ViewAttributes() ?>>
<?php echo $data_marketing->Alamat->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->No_Ktp->Visible) { // No_Ktp ?>
		<td<?php echo $data_marketing->No_Ktp->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_No_Ktp" class="data_marketing_No_Ktp">
<span<?php echo $data_marketing->No_Ktp->ViewAttributes() ?>>
<?php echo $data_marketing->No_Ktp->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->NPWP->Visible) { // NPWP ?>
		<td<?php echo $data_marketing->NPWP->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_NPWP" class="data_marketing_NPWP">
<span<?php echo $data_marketing->NPWP->ViewAttributes() ?>>
<?php echo $data_marketing->NPWP->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Telp->Visible) { // Telp ?>
		<td<?php echo $data_marketing->Telp->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_Telp" class="data_marketing_Telp">
<span<?php echo $data_marketing->Telp->ViewAttributes() ?>>
<?php echo $data_marketing->Telp->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Kode->Visible) { // Kode ?>
		<td<?php echo $data_marketing->Kode->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_Kode" class="data_marketing_Kode">
<span<?php echo $data_marketing->Kode->ViewAttributes() ?>>
<?php echo $data_marketing->Kode->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Area_Listing->Visible) { // Area_Listing ?>
		<td<?php echo $data_marketing->Area_Listing->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_Area_Listing" class="data_marketing_Area_Listing">
<span<?php echo $data_marketing->Area_Listing->ViewAttributes() ?>>
<?php echo $data_marketing->Area_Listing->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Alamat_Lengkap->Visible) { // Alamat_Lengkap ?>
		<td<?php echo $data_marketing->Alamat_Lengkap->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_Alamat_Lengkap" class="data_marketing_Alamat_Lengkap">
<span<?php echo $data_marketing->Alamat_Lengkap->ViewAttributes() ?>>
<?php echo $data_marketing->Alamat_Lengkap->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Nama_yang_bisa_dihubungi->Visible) { // Nama_yang_bisa_dihubungi ?>
		<td<?php echo $data_marketing->Nama_yang_bisa_dihubungi->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_Nama_yang_bisa_dihubungi" class="data_marketing_Nama_yang_bisa_dihubungi">
<span<?php echo $data_marketing->Nama_yang_bisa_dihubungi->ViewAttributes() ?>>
<?php echo $data_marketing->Nama_yang_bisa_dihubungi->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->No_Telp->Visible) { // No_Telp ?>
		<td<?php echo $data_marketing->No_Telp->CellAttributes() ?>>
<span id="el<?php echo $data_marketing_delete->RowCnt ?>_data_marketing_No_Telp" class="data_marketing_No_Telp">
<span<?php echo $data_marketing->No_Telp->ViewAttributes() ?>>
<?php echo $data_marketing->No_Telp->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
	</tr>
<?php
	$data_marketing_delete->Recordset->MoveNext();
}
$data_marketing_delete->Recordset->Close();
?>
</tbody>
</table>
</div>
</div>
<div>
<button class="btn btn-primary ewButton" name="btnAction" id="btnAction" type="submit"><?php echo $Language->Phrase("DeleteBtn") ?></button>
<button class="btn btn-default ewButton" name="btnCancel" id="btnCancel" type="button" data-href="<?php echo $data_marketing_delete->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
</div>
</form>
<script type="text/javascript">
fdata_marketingdelete.Init();
</script>
<?php
$data_marketing_delete->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<script type="text/javascript">

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$data_marketing_delete->Page_Terminate();
?>
