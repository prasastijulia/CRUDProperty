<?php include_once "admininfo.php" ?>
<?php

// Create page object
if (!isset($data_marketing_grid)) $data_marketing_grid = new cdata_marketing_grid();

// Page init
$data_marketing_grid->Page_Init();

// Page main
$data_marketing_grid->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$data_marketing_grid->Page_Render();
?>
<?php if ($data_marketing->Export == "") { ?>
<script type="text/javascript">

// Form object
var fdata_marketinggrid = new ew_Form("fdata_marketinggrid", "grid");
fdata_marketinggrid.FormKeyCountName = '<?php echo $data_marketing_grid->FormKeyCountName ?>';

// Validate form
fdata_marketinggrid.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
		var checkrow = (gridinsert) ? !this.EmptyRow(infix) : true;
		if (checkrow) {
			addcnt++;
			elm = this.GetElements("x" + infix + "_Nama");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Nama->FldCaption(), $data_marketing->Nama->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Alamat");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Alamat->FldCaption(), $data_marketing->Alamat->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_No_Ktp");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->No_Ktp->FldCaption(), $data_marketing->No_Ktp->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_NPWP");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->NPWP->FldCaption(), $data_marketing->NPWP->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Telp");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Telp->FldCaption(), $data_marketing->Telp->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Kode");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Kode->FldCaption(), $data_marketing->Kode->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Area_Listing");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Area_Listing->FldCaption(), $data_marketing->Area_Listing->ReqErrMsg)) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
		} // End Grid Add checking
	}
	return true;
}

// Check empty row
fdata_marketinggrid.EmptyRow = function(infix) {
	var fobj = this.Form;
	if (ew_ValueChanged(fobj, infix, "Nama", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Alamat", false)) return false;
	if (ew_ValueChanged(fobj, infix, "No_Ktp", false)) return false;
	if (ew_ValueChanged(fobj, infix, "NPWP", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Telp", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Kode", false)) return false;
	if (ew_ValueChanged(fobj, infix, "Area_Listing", false)) return false;
	return true;
}

// Form_CustomValidate event
fdata_marketinggrid.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fdata_marketinggrid.ValidateRequired = true;
<?php } else { ?>
fdata_marketinggrid.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
// Form object for search

</script>
<?php } ?>
<?php
if ($data_marketing->CurrentAction == "gridadd") {
	if ($data_marketing->CurrentMode == "copy") {
		$bSelectLimit = $data_marketing_grid->UseSelectLimit;
		if ($bSelectLimit) {
			$data_marketing_grid->TotalRecs = $data_marketing->SelectRecordCount();
			$data_marketing_grid->Recordset = $data_marketing_grid->LoadRecordset($data_marketing_grid->StartRec-1, $data_marketing_grid->DisplayRecs);
		} else {
			if ($data_marketing_grid->Recordset = $data_marketing_grid->LoadRecordset())
				$data_marketing_grid->TotalRecs = $data_marketing_grid->Recordset->RecordCount();
		}
		$data_marketing_grid->StartRec = 1;
		$data_marketing_grid->DisplayRecs = $data_marketing_grid->TotalRecs;
	} else {
		$data_marketing->CurrentFilter = "0=1";
		$data_marketing_grid->StartRec = 1;
		$data_marketing_grid->DisplayRecs = $data_marketing->GridAddRowCount;
	}
	$data_marketing_grid->TotalRecs = $data_marketing_grid->DisplayRecs;
	$data_marketing_grid->StopRec = $data_marketing_grid->DisplayRecs;
} else {
	$bSelectLimit = $data_marketing_grid->UseSelectLimit;
	if ($bSelectLimit) {
		if ($data_marketing_grid->TotalRecs <= 0)
			$data_marketing_grid->TotalRecs = $data_marketing->SelectRecordCount();
	} else {
		if (!$data_marketing_grid->Recordset && ($data_marketing_grid->Recordset = $data_marketing_grid->LoadRecordset()))
			$data_marketing_grid->TotalRecs = $data_marketing_grid->Recordset->RecordCount();
	}
	$data_marketing_grid->StartRec = 1;
	$data_marketing_grid->DisplayRecs = $data_marketing_grid->TotalRecs; // Display all records
	if ($bSelectLimit)
		$data_marketing_grid->Recordset = $data_marketing_grid->LoadRecordset($data_marketing_grid->StartRec-1, $data_marketing_grid->DisplayRecs);

	// Set no record found message
	if ($data_marketing->CurrentAction == "" && $data_marketing_grid->TotalRecs == 0) {
		if (!$Security->CanList())
			$data_marketing_grid->setWarningMessage(ew_DeniedMsg());
		if ($data_marketing_grid->SearchWhere == "0=101")
			$data_marketing_grid->setWarningMessage($Language->Phrase("EnterSearchCriteria"));
		else
			$data_marketing_grid->setWarningMessage($Language->Phrase("NoRecord"));
	}
}
$data_marketing_grid->RenderOtherOptions();
?>
<?php $data_marketing_grid->ShowPageHeader(); ?>
<?php
$data_marketing_grid->ShowMessage();
?>
<?php if ($data_marketing_grid->TotalRecs > 0 || $data_marketing->CurrentAction <> "") { ?>
<div class="panel panel-default ewGrid data_marketing">
<div id="fdata_marketinggrid" class="ewForm form-inline">
<?php if ($data_marketing_grid->ShowOtherOptions) { ?>
<div class="panel-heading ewGridUpperPanel">
<?php
	foreach ($data_marketing_grid->OtherOptions as &$option)
		$option->Render("body");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<div id="gmp_data_marketing" class="<?php if (ew_IsResponsiveLayout()) { echo "table-responsive "; } ?>ewGridMiddlePanel">
<table id="tbl_data_marketinggrid" class="table ewTable">
<?php echo $data_marketing->TableCustomInnerHtml ?>
<thead><!-- Table header -->
	<tr class="ewTableHeader">
<?php

// Header row
$data_marketing_grid->RowType = EW_ROWTYPE_HEADER;

// Render list options
$data_marketing_grid->RenderListOptions();

// Render list options (header, left)
$data_marketing_grid->ListOptions->Render("header", "left");
?>
<?php if ($data_marketing->No->Visible) { // No ?>
	<?php if ($data_marketing->SortUrl($data_marketing->No) == "") { ?>
		<th data-name="No"><div id="elh_data_marketing_No" class="data_marketing_No"><div class="ewTableHeaderCaption"><?php echo $data_marketing->No->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="No"><div><div id="elh_data_marketing_No" class="data_marketing_No">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_marketing->No->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_marketing->No->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_marketing->No->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($data_marketing->Nama->Visible) { // Nama ?>
	<?php if ($data_marketing->SortUrl($data_marketing->Nama) == "") { ?>
		<th data-name="Nama"><div id="elh_data_marketing_Nama" class="data_marketing_Nama"><div class="ewTableHeaderCaption"><?php echo $data_marketing->Nama->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Nama"><div><div id="elh_data_marketing_Nama" class="data_marketing_Nama">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_marketing->Nama->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_marketing->Nama->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_marketing->Nama->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($data_marketing->Alamat->Visible) { // Alamat ?>
	<?php if ($data_marketing->SortUrl($data_marketing->Alamat) == "") { ?>
		<th data-name="Alamat"><div id="elh_data_marketing_Alamat" class="data_marketing_Alamat"><div class="ewTableHeaderCaption"><?php echo $data_marketing->Alamat->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Alamat"><div><div id="elh_data_marketing_Alamat" class="data_marketing_Alamat">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_marketing->Alamat->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_marketing->Alamat->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_marketing->Alamat->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($data_marketing->No_Ktp->Visible) { // No_Ktp ?>
	<?php if ($data_marketing->SortUrl($data_marketing->No_Ktp) == "") { ?>
		<th data-name="No_Ktp"><div id="elh_data_marketing_No_Ktp" class="data_marketing_No_Ktp"><div class="ewTableHeaderCaption"><?php echo $data_marketing->No_Ktp->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="No_Ktp"><div><div id="elh_data_marketing_No_Ktp" class="data_marketing_No_Ktp">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_marketing->No_Ktp->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_marketing->No_Ktp->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_marketing->No_Ktp->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($data_marketing->NPWP->Visible) { // NPWP ?>
	<?php if ($data_marketing->SortUrl($data_marketing->NPWP) == "") { ?>
		<th data-name="NPWP"><div id="elh_data_marketing_NPWP" class="data_marketing_NPWP"><div class="ewTableHeaderCaption"><?php echo $data_marketing->NPWP->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="NPWP"><div><div id="elh_data_marketing_NPWP" class="data_marketing_NPWP">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_marketing->NPWP->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_marketing->NPWP->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_marketing->NPWP->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($data_marketing->Telp->Visible) { // Telp ?>
	<?php if ($data_marketing->SortUrl($data_marketing->Telp) == "") { ?>
		<th data-name="Telp"><div id="elh_data_marketing_Telp" class="data_marketing_Telp"><div class="ewTableHeaderCaption"><?php echo $data_marketing->Telp->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Telp"><div><div id="elh_data_marketing_Telp" class="data_marketing_Telp">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_marketing->Telp->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_marketing->Telp->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_marketing->Telp->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($data_marketing->Kode->Visible) { // Kode ?>
	<?php if ($data_marketing->SortUrl($data_marketing->Kode) == "") { ?>
		<th data-name="Kode"><div id="elh_data_marketing_Kode" class="data_marketing_Kode"><div class="ewTableHeaderCaption"><?php echo $data_marketing->Kode->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Kode"><div><div id="elh_data_marketing_Kode" class="data_marketing_Kode">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_marketing->Kode->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_marketing->Kode->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_marketing->Kode->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php if ($data_marketing->Area_Listing->Visible) { // Area_Listing ?>
	<?php if ($data_marketing->SortUrl($data_marketing->Area_Listing) == "") { ?>
		<th data-name="Area_Listing"><div id="elh_data_marketing_Area_Listing" class="data_marketing_Area_Listing"><div class="ewTableHeaderCaption"><?php echo $data_marketing->Area_Listing->FldCaption() ?></div></div></th>
	<?php } else { ?>
		<th data-name="Area_Listing"><div><div id="elh_data_marketing_Area_Listing" class="data_marketing_Area_Listing">
			<div class="ewTableHeaderBtn"><span class="ewTableHeaderCaption"><?php echo $data_marketing->Area_Listing->FldCaption() ?></span><span class="ewTableHeaderSort"><?php if ($data_marketing->Area_Listing->getSort() == "ASC") { ?><span class="caret ewSortUp"></span><?php } elseif ($data_marketing->Area_Listing->getSort() == "DESC") { ?><span class="caret"></span><?php } ?></span></div>
        </div></div></th>
	<?php } ?>
<?php } ?>		
<?php

// Render list options (header, right)
$data_marketing_grid->ListOptions->Render("header", "right");
?>
	</tr>
</thead>
<tbody>
<?php
$data_marketing_grid->StartRec = 1;
$data_marketing_grid->StopRec = $data_marketing_grid->TotalRecs; // Show all records

// Restore number of post back records
if ($objForm) {
	$objForm->Index = -1;
	if ($objForm->HasValue($data_marketing_grid->FormKeyCountName) && ($data_marketing->CurrentAction == "gridadd" || $data_marketing->CurrentAction == "gridedit" || $data_marketing->CurrentAction == "F")) {
		$data_marketing_grid->KeyCount = $objForm->GetValue($data_marketing_grid->FormKeyCountName);
		$data_marketing_grid->StopRec = $data_marketing_grid->StartRec + $data_marketing_grid->KeyCount - 1;
	}
}
$data_marketing_grid->RecCnt = $data_marketing_grid->StartRec - 1;
if ($data_marketing_grid->Recordset && !$data_marketing_grid->Recordset->EOF) {
	$data_marketing_grid->Recordset->MoveFirst();
	$bSelectLimit = $data_marketing_grid->UseSelectLimit;
	if (!$bSelectLimit && $data_marketing_grid->StartRec > 1)
		$data_marketing_grid->Recordset->Move($data_marketing_grid->StartRec - 1);
} elseif (!$data_marketing->AllowAddDeleteRow && $data_marketing_grid->StopRec == 0) {
	$data_marketing_grid->StopRec = $data_marketing->GridAddRowCount;
}

// Initialize aggregate
$data_marketing->RowType = EW_ROWTYPE_AGGREGATEINIT;
$data_marketing->ResetAttrs();
$data_marketing_grid->RenderRow();
if ($data_marketing->CurrentAction == "gridadd")
	$data_marketing_grid->RowIndex = 0;
if ($data_marketing->CurrentAction == "gridedit")
	$data_marketing_grid->RowIndex = 0;
while ($data_marketing_grid->RecCnt < $data_marketing_grid->StopRec) {
	$data_marketing_grid->RecCnt++;
	if (intval($data_marketing_grid->RecCnt) >= intval($data_marketing_grid->StartRec)) {
		$data_marketing_grid->RowCnt++;
		if ($data_marketing->CurrentAction == "gridadd" || $data_marketing->CurrentAction == "gridedit" || $data_marketing->CurrentAction == "F") {
			$data_marketing_grid->RowIndex++;
			$objForm->Index = $data_marketing_grid->RowIndex;
			if ($objForm->HasValue($data_marketing_grid->FormActionName))
				$data_marketing_grid->RowAction = strval($objForm->GetValue($data_marketing_grid->FormActionName));
			elseif ($data_marketing->CurrentAction == "gridadd")
				$data_marketing_grid->RowAction = "insert";
			else
				$data_marketing_grid->RowAction = "";
		}

		// Set up key count
		$data_marketing_grid->KeyCount = $data_marketing_grid->RowIndex;

		// Init row class and style
		$data_marketing->ResetAttrs();
		$data_marketing->CssClass = "";
		if ($data_marketing->CurrentAction == "gridadd") {
			if ($data_marketing->CurrentMode == "copy") {
				$data_marketing_grid->LoadRowValues($data_marketing_grid->Recordset); // Load row values
				$data_marketing_grid->SetRecordKey($data_marketing_grid->RowOldKey, $data_marketing_grid->Recordset); // Set old record key
			} else {
				$data_marketing_grid->LoadDefaultValues(); // Load default values
				$data_marketing_grid->RowOldKey = ""; // Clear old key value
			}
		} else {
			$data_marketing_grid->LoadRowValues($data_marketing_grid->Recordset); // Load row values
		}
		$data_marketing->RowType = EW_ROWTYPE_VIEW; // Render view
		if ($data_marketing->CurrentAction == "gridadd") // Grid add
			$data_marketing->RowType = EW_ROWTYPE_ADD; // Render add
		if ($data_marketing->CurrentAction == "gridadd" && $data_marketing->EventCancelled && !$objForm->HasValue("k_blankrow")) // Insert failed
			$data_marketing_grid->RestoreCurrentRowFormValues($data_marketing_grid->RowIndex); // Restore form values
		if ($data_marketing->CurrentAction == "gridedit") { // Grid edit
			if ($data_marketing->EventCancelled) {
				$data_marketing_grid->RestoreCurrentRowFormValues($data_marketing_grid->RowIndex); // Restore form values
			}
			if ($data_marketing_grid->RowAction == "insert")
				$data_marketing->RowType = EW_ROWTYPE_ADD; // Render add
			else
				$data_marketing->RowType = EW_ROWTYPE_EDIT; // Render edit
		}
		if ($data_marketing->CurrentAction == "gridedit" && ($data_marketing->RowType == EW_ROWTYPE_EDIT || $data_marketing->RowType == EW_ROWTYPE_ADD) && $data_marketing->EventCancelled) // Update failed
			$data_marketing_grid->RestoreCurrentRowFormValues($data_marketing_grid->RowIndex); // Restore form values
		if ($data_marketing->RowType == EW_ROWTYPE_EDIT) // Edit row
			$data_marketing_grid->EditRowCnt++;
		if ($data_marketing->CurrentAction == "F") // Confirm row
			$data_marketing_grid->RestoreCurrentRowFormValues($data_marketing_grid->RowIndex); // Restore form values

		// Set up row id / data-rowindex
		$data_marketing->RowAttrs = array_merge($data_marketing->RowAttrs, array('data-rowindex'=>$data_marketing_grid->RowCnt, 'id'=>'r' . $data_marketing_grid->RowCnt . '_data_marketing', 'data-rowtype'=>$data_marketing->RowType));

		// Render row
		$data_marketing_grid->RenderRow();

		// Render list options
		$data_marketing_grid->RenderListOptions();

		// Skip delete row / empty row for confirm page
		if ($data_marketing_grid->RowAction <> "delete" && $data_marketing_grid->RowAction <> "insertdelete" && !($data_marketing_grid->RowAction == "insert" && $data_marketing->CurrentAction == "F" && $data_marketing_grid->EmptyRow())) {
?>
	<tr<?php echo $data_marketing->RowAttributes() ?>>
<?php

// Render list options (body, left)
$data_marketing_grid->ListOptions->Render("body", "left", $data_marketing_grid->RowCnt);
?>
	<?php if ($data_marketing->No->Visible) { // No ?>
		<td data-name="No"<?php echo $data_marketing->No->CellAttributes() ?>>
<?php if ($data_marketing->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<input type="hidden" data-table="data_marketing" data-field="x_No" name="o<?php echo $data_marketing_grid->RowIndex ?>_No" id="o<?php echo $data_marketing_grid->RowIndex ?>_No" value="<?php echo ew_HtmlEncode($data_marketing->No->OldValue) ?>">
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_No" class="form-group data_marketing_No">
<span<?php echo $data_marketing->No->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->No->EditValue ?></p></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_No" name="x<?php echo $data_marketing_grid->RowIndex ?>_No" id="x<?php echo $data_marketing_grid->RowIndex ?>_No" value="<?php echo ew_HtmlEncode($data_marketing->No->CurrentValue) ?>">
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_No" class="data_marketing_No">
<span<?php echo $data_marketing->No->ViewAttributes() ?>>
<?php echo $data_marketing->No->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_No" name="x<?php echo $data_marketing_grid->RowIndex ?>_No" id="x<?php echo $data_marketing_grid->RowIndex ?>_No" value="<?php echo ew_HtmlEncode($data_marketing->No->FormValue) ?>">
<input type="hidden" data-table="data_marketing" data-field="x_No" name="o<?php echo $data_marketing_grid->RowIndex ?>_No" id="o<?php echo $data_marketing_grid->RowIndex ?>_No" value="<?php echo ew_HtmlEncode($data_marketing->No->OldValue) ?>">
<?php } ?>
<a id="<?php echo $data_marketing_grid->PageObjName . "_row_" . $data_marketing_grid->RowCnt ?>"></a></td>
	<?php } ?>
	<?php if ($data_marketing->Nama->Visible) { // Nama ?>
		<td data-name="Nama"<?php echo $data_marketing->Nama->CellAttributes() ?>>
<?php if ($data_marketing->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<?php if ($data_marketing->Nama->getSessionValue() <> "") { ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Nama" class="form-group data_marketing_Nama">
<span<?php echo $data_marketing->Nama->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->Nama->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" name="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_marketing->Nama->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Nama" class="form-group data_marketing_Nama">
<input type="text" data-table="data_marketing" data-field="x_Nama" name="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" id="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" size="60" maxlength="100" value="<?php echo $data_marketing->Nama->EditValue ?>"<?php echo $data_marketing->Nama->EditAttributes() ?>>
</span>
<?php } ?>
<input type="hidden" data-table="data_marketing" data-field="x_Nama" name="o<?php echo $data_marketing_grid->RowIndex ?>_Nama" id="o<?php echo $data_marketing_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_marketing->Nama->OldValue) ?>">
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<?php if ($data_marketing->Nama->getSessionValue() <> "") { ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Nama" class="form-group data_marketing_Nama">
<span<?php echo $data_marketing->Nama->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->Nama->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" name="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_marketing->Nama->CurrentValue) ?>">
<?php } else { ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Nama" class="form-group data_marketing_Nama">
<input type="text" data-table="data_marketing" data-field="x_Nama" name="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" id="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" size="60" maxlength="100" value="<?php echo $data_marketing->Nama->EditValue ?>"<?php echo $data_marketing->Nama->EditAttributes() ?>>
</span>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Nama" class="data_marketing_Nama">
<span<?php echo $data_marketing->Nama->ViewAttributes() ?>>
<?php echo $data_marketing->Nama->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Nama" name="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" id="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_marketing->Nama->FormValue) ?>">
<input type="hidden" data-table="data_marketing" data-field="x_Nama" name="o<?php echo $data_marketing_grid->RowIndex ?>_Nama" id="o<?php echo $data_marketing_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_marketing->Nama->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($data_marketing->Alamat->Visible) { // Alamat ?>
		<td data-name="Alamat"<?php echo $data_marketing->Alamat->CellAttributes() ?>>
<?php if ($data_marketing->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Alamat" class="form-group data_marketing_Alamat">
<textarea data-table="data_marketing" data-field="x_Alamat" name="x<?php echo $data_marketing_grid->RowIndex ?>_Alamat" id="x<?php echo $data_marketing_grid->RowIndex ?>_Alamat" cols="35" rows="4"<?php echo $data_marketing->Alamat->EditAttributes() ?>><?php echo $data_marketing->Alamat->EditValue ?></textarea>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Alamat" name="o<?php echo $data_marketing_grid->RowIndex ?>_Alamat" id="o<?php echo $data_marketing_grid->RowIndex ?>_Alamat" value="<?php echo ew_HtmlEncode($data_marketing->Alamat->OldValue) ?>">
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Alamat" class="form-group data_marketing_Alamat">
<textarea data-table="data_marketing" data-field="x_Alamat" name="x<?php echo $data_marketing_grid->RowIndex ?>_Alamat" id="x<?php echo $data_marketing_grid->RowIndex ?>_Alamat" cols="35" rows="4"<?php echo $data_marketing->Alamat->EditAttributes() ?>><?php echo $data_marketing->Alamat->EditValue ?></textarea>
</span>
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Alamat" class="data_marketing_Alamat">
<span<?php echo $data_marketing->Alamat->ViewAttributes() ?>>
<?php echo $data_marketing->Alamat->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Alamat" name="x<?php echo $data_marketing_grid->RowIndex ?>_Alamat" id="x<?php echo $data_marketing_grid->RowIndex ?>_Alamat" value="<?php echo ew_HtmlEncode($data_marketing->Alamat->FormValue) ?>">
<input type="hidden" data-table="data_marketing" data-field="x_Alamat" name="o<?php echo $data_marketing_grid->RowIndex ?>_Alamat" id="o<?php echo $data_marketing_grid->RowIndex ?>_Alamat" value="<?php echo ew_HtmlEncode($data_marketing->Alamat->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($data_marketing->No_Ktp->Visible) { // No_Ktp ?>
		<td data-name="No_Ktp"<?php echo $data_marketing->No_Ktp->CellAttributes() ?>>
<?php if ($data_marketing->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_No_Ktp" class="form-group data_marketing_No_Ktp">
<input type="text" data-table="data_marketing" data-field="x_No_Ktp" name="x<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" id="x<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" size="30" maxlength="50" value="<?php echo $data_marketing->No_Ktp->EditValue ?>"<?php echo $data_marketing->No_Ktp->EditAttributes() ?>>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_No_Ktp" name="o<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" id="o<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" value="<?php echo ew_HtmlEncode($data_marketing->No_Ktp->OldValue) ?>">
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_No_Ktp" class="form-group data_marketing_No_Ktp">
<input type="text" data-table="data_marketing" data-field="x_No_Ktp" name="x<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" id="x<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" size="30" maxlength="50" value="<?php echo $data_marketing->No_Ktp->EditValue ?>"<?php echo $data_marketing->No_Ktp->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_No_Ktp" class="data_marketing_No_Ktp">
<span<?php echo $data_marketing->No_Ktp->ViewAttributes() ?>>
<?php echo $data_marketing->No_Ktp->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_No_Ktp" name="x<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" id="x<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" value="<?php echo ew_HtmlEncode($data_marketing->No_Ktp->FormValue) ?>">
<input type="hidden" data-table="data_marketing" data-field="x_No_Ktp" name="o<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" id="o<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" value="<?php echo ew_HtmlEncode($data_marketing->No_Ktp->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($data_marketing->NPWP->Visible) { // NPWP ?>
		<td data-name="NPWP"<?php echo $data_marketing->NPWP->CellAttributes() ?>>
<?php if ($data_marketing->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_NPWP" class="form-group data_marketing_NPWP">
<input type="text" data-table="data_marketing" data-field="x_NPWP" name="x<?php echo $data_marketing_grid->RowIndex ?>_NPWP" id="x<?php echo $data_marketing_grid->RowIndex ?>_NPWP" size="30" maxlength="50" value="<?php echo $data_marketing->NPWP->EditValue ?>"<?php echo $data_marketing->NPWP->EditAttributes() ?>>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_NPWP" name="o<?php echo $data_marketing_grid->RowIndex ?>_NPWP" id="o<?php echo $data_marketing_grid->RowIndex ?>_NPWP" value="<?php echo ew_HtmlEncode($data_marketing->NPWP->OldValue) ?>">
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_NPWP" class="form-group data_marketing_NPWP">
<input type="text" data-table="data_marketing" data-field="x_NPWP" name="x<?php echo $data_marketing_grid->RowIndex ?>_NPWP" id="x<?php echo $data_marketing_grid->RowIndex ?>_NPWP" size="30" maxlength="50" value="<?php echo $data_marketing->NPWP->EditValue ?>"<?php echo $data_marketing->NPWP->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_NPWP" class="data_marketing_NPWP">
<span<?php echo $data_marketing->NPWP->ViewAttributes() ?>>
<?php echo $data_marketing->NPWP->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_NPWP" name="x<?php echo $data_marketing_grid->RowIndex ?>_NPWP" id="x<?php echo $data_marketing_grid->RowIndex ?>_NPWP" value="<?php echo ew_HtmlEncode($data_marketing->NPWP->FormValue) ?>">
<input type="hidden" data-table="data_marketing" data-field="x_NPWP" name="o<?php echo $data_marketing_grid->RowIndex ?>_NPWP" id="o<?php echo $data_marketing_grid->RowIndex ?>_NPWP" value="<?php echo ew_HtmlEncode($data_marketing->NPWP->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($data_marketing->Telp->Visible) { // Telp ?>
		<td data-name="Telp"<?php echo $data_marketing->Telp->CellAttributes() ?>>
<?php if ($data_marketing->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Telp" class="form-group data_marketing_Telp">
<input type="text" data-table="data_marketing" data-field="x_Telp" name="x<?php echo $data_marketing_grid->RowIndex ?>_Telp" id="x<?php echo $data_marketing_grid->RowIndex ?>_Telp" size="30" maxlength="30" value="<?php echo $data_marketing->Telp->EditValue ?>"<?php echo $data_marketing->Telp->EditAttributes() ?>>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Telp" name="o<?php echo $data_marketing_grid->RowIndex ?>_Telp" id="o<?php echo $data_marketing_grid->RowIndex ?>_Telp" value="<?php echo ew_HtmlEncode($data_marketing->Telp->OldValue) ?>">
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Telp" class="form-group data_marketing_Telp">
<input type="text" data-table="data_marketing" data-field="x_Telp" name="x<?php echo $data_marketing_grid->RowIndex ?>_Telp" id="x<?php echo $data_marketing_grid->RowIndex ?>_Telp" size="30" maxlength="30" value="<?php echo $data_marketing->Telp->EditValue ?>"<?php echo $data_marketing->Telp->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Telp" class="data_marketing_Telp">
<span<?php echo $data_marketing->Telp->ViewAttributes() ?>>
<?php echo $data_marketing->Telp->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Telp" name="x<?php echo $data_marketing_grid->RowIndex ?>_Telp" id="x<?php echo $data_marketing_grid->RowIndex ?>_Telp" value="<?php echo ew_HtmlEncode($data_marketing->Telp->FormValue) ?>">
<input type="hidden" data-table="data_marketing" data-field="x_Telp" name="o<?php echo $data_marketing_grid->RowIndex ?>_Telp" id="o<?php echo $data_marketing_grid->RowIndex ?>_Telp" value="<?php echo ew_HtmlEncode($data_marketing->Telp->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($data_marketing->Kode->Visible) { // Kode ?>
		<td data-name="Kode"<?php echo $data_marketing->Kode->CellAttributes() ?>>
<?php if ($data_marketing->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Kode" class="form-group data_marketing_Kode">
<input type="text" data-table="data_marketing" data-field="x_Kode" name="x<?php echo $data_marketing_grid->RowIndex ?>_Kode" id="x<?php echo $data_marketing_grid->RowIndex ?>_Kode" size="20" maxlength="30" value="<?php echo $data_marketing->Kode->EditValue ?>"<?php echo $data_marketing->Kode->EditAttributes() ?>>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Kode" name="o<?php echo $data_marketing_grid->RowIndex ?>_Kode" id="o<?php echo $data_marketing_grid->RowIndex ?>_Kode" value="<?php echo ew_HtmlEncode($data_marketing->Kode->OldValue) ?>">
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Kode" class="form-group data_marketing_Kode">
<input type="text" data-table="data_marketing" data-field="x_Kode" name="x<?php echo $data_marketing_grid->RowIndex ?>_Kode" id="x<?php echo $data_marketing_grid->RowIndex ?>_Kode" size="20" maxlength="30" value="<?php echo $data_marketing->Kode->EditValue ?>"<?php echo $data_marketing->Kode->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Kode" class="data_marketing_Kode">
<span<?php echo $data_marketing->Kode->ViewAttributes() ?>>
<?php echo $data_marketing->Kode->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Kode" name="x<?php echo $data_marketing_grid->RowIndex ?>_Kode" id="x<?php echo $data_marketing_grid->RowIndex ?>_Kode" value="<?php echo ew_HtmlEncode($data_marketing->Kode->FormValue) ?>">
<input type="hidden" data-table="data_marketing" data-field="x_Kode" name="o<?php echo $data_marketing_grid->RowIndex ?>_Kode" id="o<?php echo $data_marketing_grid->RowIndex ?>_Kode" value="<?php echo ew_HtmlEncode($data_marketing->Kode->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
	<?php if ($data_marketing->Area_Listing->Visible) { // Area_Listing ?>
		<td data-name="Area_Listing"<?php echo $data_marketing->Area_Listing->CellAttributes() ?>>
<?php if ($data_marketing->RowType == EW_ROWTYPE_ADD) { // Add record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Area_Listing" class="form-group data_marketing_Area_Listing">
<input type="text" data-table="data_marketing" data-field="x_Area_Listing" name="x<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" id="x<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" size="60" maxlength="100" value="<?php echo $data_marketing->Area_Listing->EditValue ?>"<?php echo $data_marketing->Area_Listing->EditAttributes() ?>>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Area_Listing" name="o<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" id="o<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" value="<?php echo ew_HtmlEncode($data_marketing->Area_Listing->OldValue) ?>">
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_EDIT) { // Edit record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Area_Listing" class="form-group data_marketing_Area_Listing">
<input type="text" data-table="data_marketing" data-field="x_Area_Listing" name="x<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" id="x<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" size="60" maxlength="100" value="<?php echo $data_marketing->Area_Listing->EditValue ?>"<?php echo $data_marketing->Area_Listing->EditAttributes() ?>>
</span>
<?php } ?>
<?php if ($data_marketing->RowType == EW_ROWTYPE_VIEW) { // View record ?>
<span id="el<?php echo $data_marketing_grid->RowCnt ?>_data_marketing_Area_Listing" class="data_marketing_Area_Listing">
<span<?php echo $data_marketing->Area_Listing->ViewAttributes() ?>>
<?php echo $data_marketing->Area_Listing->ListViewValue() ?></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Area_Listing" name="x<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" id="x<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" value="<?php echo ew_HtmlEncode($data_marketing->Area_Listing->FormValue) ?>">
<input type="hidden" data-table="data_marketing" data-field="x_Area_Listing" name="o<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" id="o<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" value="<?php echo ew_HtmlEncode($data_marketing->Area_Listing->OldValue) ?>">
<?php } ?>
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$data_marketing_grid->ListOptions->Render("body", "right", $data_marketing_grid->RowCnt);
?>
	</tr>
<?php if ($data_marketing->RowType == EW_ROWTYPE_ADD || $data_marketing->RowType == EW_ROWTYPE_EDIT) { ?>
<script type="text/javascript">
fdata_marketinggrid.UpdateOpts(<?php echo $data_marketing_grid->RowIndex ?>);
</script>
<?php } ?>
<?php
	}
	} // End delete row checking
	if ($data_marketing->CurrentAction <> "gridadd" || $data_marketing->CurrentMode == "copy")
		if (!$data_marketing_grid->Recordset->EOF) $data_marketing_grid->Recordset->MoveNext();
}
?>
<?php
	if ($data_marketing->CurrentMode == "add" || $data_marketing->CurrentMode == "copy" || $data_marketing->CurrentMode == "edit") {
		$data_marketing_grid->RowIndex = '$rowindex$';
		$data_marketing_grid->LoadDefaultValues();

		// Set row properties
		$data_marketing->ResetAttrs();
		$data_marketing->RowAttrs = array_merge($data_marketing->RowAttrs, array('data-rowindex'=>$data_marketing_grid->RowIndex, 'id'=>'r0_data_marketing', 'data-rowtype'=>EW_ROWTYPE_ADD));
		ew_AppendClass($data_marketing->RowAttrs["class"], "ewTemplate");
		$data_marketing->RowType = EW_ROWTYPE_ADD;

		// Render row
		$data_marketing_grid->RenderRow();

		// Render list options
		$data_marketing_grid->RenderListOptions();
		$data_marketing_grid->StartRowCnt = 0;
?>
	<tr<?php echo $data_marketing->RowAttributes() ?>>
<?php

// Render list options (body, left)
$data_marketing_grid->ListOptions->Render("body", "left", $data_marketing_grid->RowIndex);
?>
	<?php if ($data_marketing->No->Visible) { // No ?>
		<td data-name="No">
<?php if ($data_marketing->CurrentAction <> "F") { ?>
<?php } else { ?>
<span id="el$rowindex$_data_marketing_No" class="form-group data_marketing_No">
<span<?php echo $data_marketing->No->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->No->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_No" name="x<?php echo $data_marketing_grid->RowIndex ?>_No" id="x<?php echo $data_marketing_grid->RowIndex ?>_No" value="<?php echo ew_HtmlEncode($data_marketing->No->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_marketing" data-field="x_No" name="o<?php echo $data_marketing_grid->RowIndex ?>_No" id="o<?php echo $data_marketing_grid->RowIndex ?>_No" value="<?php echo ew_HtmlEncode($data_marketing->No->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($data_marketing->Nama->Visible) { // Nama ?>
		<td data-name="Nama">
<?php if ($data_marketing->CurrentAction <> "F") { ?>
<?php if ($data_marketing->Nama->getSessionValue() <> "") { ?>
<span id="el$rowindex$_data_marketing_Nama" class="form-group data_marketing_Nama">
<span<?php echo $data_marketing->Nama->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->Nama->ViewValue ?></p></span>
</span>
<input type="hidden" id="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" name="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_marketing->Nama->CurrentValue) ?>">
<?php } else { ?>
<span id="el$rowindex$_data_marketing_Nama" class="form-group data_marketing_Nama">
<input type="text" data-table="data_marketing" data-field="x_Nama" name="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" id="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" size="60" maxlength="100" value="<?php echo $data_marketing->Nama->EditValue ?>"<?php echo $data_marketing->Nama->EditAttributes() ?>>
</span>
<?php } ?>
<?php } else { ?>
<span id="el$rowindex$_data_marketing_Nama" class="form-group data_marketing_Nama">
<span<?php echo $data_marketing->Nama->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->Nama->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Nama" name="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" id="x<?php echo $data_marketing_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_marketing->Nama->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_marketing" data-field="x_Nama" name="o<?php echo $data_marketing_grid->RowIndex ?>_Nama" id="o<?php echo $data_marketing_grid->RowIndex ?>_Nama" value="<?php echo ew_HtmlEncode($data_marketing->Nama->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($data_marketing->Alamat->Visible) { // Alamat ?>
		<td data-name="Alamat">
<?php if ($data_marketing->CurrentAction <> "F") { ?>
<span id="el$rowindex$_data_marketing_Alamat" class="form-group data_marketing_Alamat">
<textarea data-table="data_marketing" data-field="x_Alamat" name="x<?php echo $data_marketing_grid->RowIndex ?>_Alamat" id="x<?php echo $data_marketing_grid->RowIndex ?>_Alamat" cols="35" rows="4"<?php echo $data_marketing->Alamat->EditAttributes() ?>><?php echo $data_marketing->Alamat->EditValue ?></textarea>
</span>
<?php } else { ?>
<span id="el$rowindex$_data_marketing_Alamat" class="form-group data_marketing_Alamat">
<span<?php echo $data_marketing->Alamat->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->Alamat->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Alamat" name="x<?php echo $data_marketing_grid->RowIndex ?>_Alamat" id="x<?php echo $data_marketing_grid->RowIndex ?>_Alamat" value="<?php echo ew_HtmlEncode($data_marketing->Alamat->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_marketing" data-field="x_Alamat" name="o<?php echo $data_marketing_grid->RowIndex ?>_Alamat" id="o<?php echo $data_marketing_grid->RowIndex ?>_Alamat" value="<?php echo ew_HtmlEncode($data_marketing->Alamat->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($data_marketing->No_Ktp->Visible) { // No_Ktp ?>
		<td data-name="No_Ktp">
<?php if ($data_marketing->CurrentAction <> "F") { ?>
<span id="el$rowindex$_data_marketing_No_Ktp" class="form-group data_marketing_No_Ktp">
<input type="text" data-table="data_marketing" data-field="x_No_Ktp" name="x<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" id="x<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" size="30" maxlength="50" value="<?php echo $data_marketing->No_Ktp->EditValue ?>"<?php echo $data_marketing->No_Ktp->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_data_marketing_No_Ktp" class="form-group data_marketing_No_Ktp">
<span<?php echo $data_marketing->No_Ktp->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->No_Ktp->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_No_Ktp" name="x<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" id="x<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" value="<?php echo ew_HtmlEncode($data_marketing->No_Ktp->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_marketing" data-field="x_No_Ktp" name="o<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" id="o<?php echo $data_marketing_grid->RowIndex ?>_No_Ktp" value="<?php echo ew_HtmlEncode($data_marketing->No_Ktp->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($data_marketing->NPWP->Visible) { // NPWP ?>
		<td data-name="NPWP">
<?php if ($data_marketing->CurrentAction <> "F") { ?>
<span id="el$rowindex$_data_marketing_NPWP" class="form-group data_marketing_NPWP">
<input type="text" data-table="data_marketing" data-field="x_NPWP" name="x<?php echo $data_marketing_grid->RowIndex ?>_NPWP" id="x<?php echo $data_marketing_grid->RowIndex ?>_NPWP" size="30" maxlength="50" value="<?php echo $data_marketing->NPWP->EditValue ?>"<?php echo $data_marketing->NPWP->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_data_marketing_NPWP" class="form-group data_marketing_NPWP">
<span<?php echo $data_marketing->NPWP->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->NPWP->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_NPWP" name="x<?php echo $data_marketing_grid->RowIndex ?>_NPWP" id="x<?php echo $data_marketing_grid->RowIndex ?>_NPWP" value="<?php echo ew_HtmlEncode($data_marketing->NPWP->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_marketing" data-field="x_NPWP" name="o<?php echo $data_marketing_grid->RowIndex ?>_NPWP" id="o<?php echo $data_marketing_grid->RowIndex ?>_NPWP" value="<?php echo ew_HtmlEncode($data_marketing->NPWP->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($data_marketing->Telp->Visible) { // Telp ?>
		<td data-name="Telp">
<?php if ($data_marketing->CurrentAction <> "F") { ?>
<span id="el$rowindex$_data_marketing_Telp" class="form-group data_marketing_Telp">
<input type="text" data-table="data_marketing" data-field="x_Telp" name="x<?php echo $data_marketing_grid->RowIndex ?>_Telp" id="x<?php echo $data_marketing_grid->RowIndex ?>_Telp" size="30" maxlength="30" value="<?php echo $data_marketing->Telp->EditValue ?>"<?php echo $data_marketing->Telp->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_data_marketing_Telp" class="form-group data_marketing_Telp">
<span<?php echo $data_marketing->Telp->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->Telp->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Telp" name="x<?php echo $data_marketing_grid->RowIndex ?>_Telp" id="x<?php echo $data_marketing_grid->RowIndex ?>_Telp" value="<?php echo ew_HtmlEncode($data_marketing->Telp->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_marketing" data-field="x_Telp" name="o<?php echo $data_marketing_grid->RowIndex ?>_Telp" id="o<?php echo $data_marketing_grid->RowIndex ?>_Telp" value="<?php echo ew_HtmlEncode($data_marketing->Telp->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($data_marketing->Kode->Visible) { // Kode ?>
		<td data-name="Kode">
<?php if ($data_marketing->CurrentAction <> "F") { ?>
<span id="el$rowindex$_data_marketing_Kode" class="form-group data_marketing_Kode">
<input type="text" data-table="data_marketing" data-field="x_Kode" name="x<?php echo $data_marketing_grid->RowIndex ?>_Kode" id="x<?php echo $data_marketing_grid->RowIndex ?>_Kode" size="20" maxlength="30" value="<?php echo $data_marketing->Kode->EditValue ?>"<?php echo $data_marketing->Kode->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_data_marketing_Kode" class="form-group data_marketing_Kode">
<span<?php echo $data_marketing->Kode->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->Kode->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Kode" name="x<?php echo $data_marketing_grid->RowIndex ?>_Kode" id="x<?php echo $data_marketing_grid->RowIndex ?>_Kode" value="<?php echo ew_HtmlEncode($data_marketing->Kode->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_marketing" data-field="x_Kode" name="o<?php echo $data_marketing_grid->RowIndex ?>_Kode" id="o<?php echo $data_marketing_grid->RowIndex ?>_Kode" value="<?php echo ew_HtmlEncode($data_marketing->Kode->OldValue) ?>">
</td>
	<?php } ?>
	<?php if ($data_marketing->Area_Listing->Visible) { // Area_Listing ?>
		<td data-name="Area_Listing">
<?php if ($data_marketing->CurrentAction <> "F") { ?>
<span id="el$rowindex$_data_marketing_Area_Listing" class="form-group data_marketing_Area_Listing">
<input type="text" data-table="data_marketing" data-field="x_Area_Listing" name="x<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" id="x<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" size="60" maxlength="100" value="<?php echo $data_marketing->Area_Listing->EditValue ?>"<?php echo $data_marketing->Area_Listing->EditAttributes() ?>>
</span>
<?php } else { ?>
<span id="el$rowindex$_data_marketing_Area_Listing" class="form-group data_marketing_Area_Listing">
<span<?php echo $data_marketing->Area_Listing->ViewAttributes() ?>>
<p class="form-control-static"><?php echo $data_marketing->Area_Listing->ViewValue ?></p></span>
</span>
<input type="hidden" data-table="data_marketing" data-field="x_Area_Listing" name="x<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" id="x<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" value="<?php echo ew_HtmlEncode($data_marketing->Area_Listing->FormValue) ?>">
<?php } ?>
<input type="hidden" data-table="data_marketing" data-field="x_Area_Listing" name="o<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" id="o<?php echo $data_marketing_grid->RowIndex ?>_Area_Listing" value="<?php echo ew_HtmlEncode($data_marketing->Area_Listing->OldValue) ?>">
</td>
	<?php } ?>
<?php

// Render list options (body, right)
$data_marketing_grid->ListOptions->Render("body", "right", $data_marketing_grid->RowCnt);
?>
<script type="text/javascript">
fdata_marketinggrid.UpdateOpts(<?php echo $data_marketing_grid->RowIndex ?>);
</script>
	</tr>
<?php
}
?>
</tbody>
</table>
<?php if ($data_marketing->CurrentMode == "add" || $data_marketing->CurrentMode == "copy") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridinsert">
<input type="hidden" name="<?php echo $data_marketing_grid->FormKeyCountName ?>" id="<?php echo $data_marketing_grid->FormKeyCountName ?>" value="<?php echo $data_marketing_grid->KeyCount ?>">
<?php echo $data_marketing_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($data_marketing->CurrentMode == "edit") { ?>
<input type="hidden" name="a_list" id="a_list" value="gridupdate">
<input type="hidden" name="<?php echo $data_marketing_grid->FormKeyCountName ?>" id="<?php echo $data_marketing_grid->FormKeyCountName ?>" value="<?php echo $data_marketing_grid->KeyCount ?>">
<?php echo $data_marketing_grid->MultiSelectKey ?>
<?php } ?>
<?php if ($data_marketing->CurrentMode == "") { ?>
<input type="hidden" name="a_list" id="a_list" value="">
<?php } ?>
<input type="hidden" name="detailpage" value="fdata_marketinggrid">
</div>
<?php

// Close recordset
if ($data_marketing_grid->Recordset)
	$data_marketing_grid->Recordset->Close();
?>
<?php if ($data_marketing_grid->ShowOtherOptions) { ?>
<div class="panel-footer ewGridLowerPanel">
<?php
	foreach ($data_marketing_grid->OtherOptions as &$option)
		$option->Render("body", "bottom");
?>
</div>
<div class="clearfix"></div>
<?php } ?>
</div>
</div>
<?php } ?>
<?php if ($data_marketing_grid->TotalRecs == 0 && $data_marketing->CurrentAction == "") { // Show other options ?>
<div class="ewListOtherOptions">
<?php
	foreach ($data_marketing_grid->OtherOptions as &$option) {
		$option->ButtonClass = "";
		$option->Render("body", "");
	}
?>
</div>
<div class="clearfix"></div>
<?php } ?>
<?php if ($data_marketing->Export == "") { ?>
<script type="text/javascript">
fdata_marketinggrid.Init();
</script>
<?php } ?>
<?php
$data_marketing_grid->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<?php
$data_marketing_grid->Page_Terminate();
?>
