<?php
if (session_id() == "") session_start(); // Init session data
ob_start(); // Turn on output buffering
?>
<?php include_once "ewcfg13.php" ?>
<?php include_once ((EW_USE_ADODB) ? "adodb5/adodb.inc.php" : "ewmysql13.php") ?>
<?php include_once "phpfn13.php" ?>
<?php

// Global variable for table object
$Laporan_Property = NULL;

//
// Table class for Laporan Property
//
class cLaporan_Property extends cTableBase {
	var $Id;
	var $Alamat_Property;
	var $Alamat;
	var $Luas_Tanah2FBangunan;
	var $Lantai;
	var $Kamar_Tidur;
	var $Kamar_Mandi_Pembantu;
	var $Listrik;
	var $Air;
	var $Furtinure;
	var $Hadap;
	var $Sertifikat;
	var $Keterangan;
	var $Foto;

	//
	// Table class constructor
	//
	function __construct() {
		global $Language;

		// Language object
		if (!isset($Language)) $Language = new cLanguage();
		$this->TableVar = 'Laporan_Property';
		$this->TableName = 'Laporan Property';
		$this->TableType = 'REPORT';

		// Update Table
		$this->UpdateTable = "`property`";
		$this->DBID = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = ""; // Page orientation (PHPExcel only)
		$this->ExportExcelPageSize = ""; // Page size (PHPExcel only)
		$this->UserIDAllowSecurity = 0; // User ID Allow

		// Id
		$this->Id = new cField('Laporan_Property', 'Laporan Property', 'x_Id', 'Id', '`Id`', '`Id`', 3, -1, FALSE, '`Id`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->Id->Sortable = TRUE; // Allow sort
		$this->Id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['Id'] = &$this->Id;

		// Alamat_Property
		$this->Alamat_Property = new cField('Laporan_Property', 'Laporan Property', 'x_Alamat_Property', 'Alamat_Property', '`Alamat_Property`', '`Alamat_Property`', 200, -1, FALSE, '`Alamat_Property`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->Alamat_Property->Sortable = TRUE; // Allow sort
		$this->fields['Alamat_Property'] = &$this->Alamat_Property;

		// Alamat
		$this->Alamat = new cField('Laporan_Property', 'Laporan Property', 'x_Alamat', 'Alamat', '`Alamat`', '`Alamat`', 200, -1, FALSE, '`Alamat`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->Alamat->Sortable = TRUE; // Allow sort
		$this->fields['Alamat'] = &$this->Alamat;

		// Luas_Tanah/Bangunan
		$this->Luas_Tanah2FBangunan = new cField('Laporan_Property', 'Laporan Property', 'x_Luas_Tanah2FBangunan', 'Luas_Tanah/Bangunan', '`Luas_Tanah/Bangunan`', '`Luas_Tanah/Bangunan`', 200, -1, FALSE, '`Luas_Tanah/Bangunan`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->Luas_Tanah2FBangunan->Sortable = TRUE; // Allow sort
		$this->fields['Luas_Tanah/Bangunan'] = &$this->Luas_Tanah2FBangunan;

		// Lantai
		$this->Lantai = new cField('Laporan_Property', 'Laporan Property', 'x_Lantai', 'Lantai', '`Lantai`', '`Lantai`', 201, -1, FALSE, '`Lantai`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'CHECKBOX');
		$this->Lantai->Sortable = TRUE; // Allow sort
		$this->Lantai->OptionCount = 5;
		$this->fields['Lantai'] = &$this->Lantai;

		// Kamar_Tidur
		$this->Kamar_Tidur = new cField('Laporan_Property', 'Laporan Property', 'x_Kamar_Tidur', 'Kamar_Tidur', '`Kamar_Tidur`', '`Kamar_Tidur`', 201, -1, FALSE, '`Kamar_Tidur`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'RADIO');
		$this->Kamar_Tidur->Sortable = TRUE; // Allow sort
		$this->Kamar_Tidur->OptionCount = 5;
		$this->fields['Kamar_Tidur'] = &$this->Kamar_Tidur;

		// Kamar_Mandi_Pembantu
		$this->Kamar_Mandi_Pembantu = new cField('Laporan_Property', 'Laporan Property', 'x_Kamar_Mandi_Pembantu', 'Kamar_Mandi_Pembantu', '`Kamar_Mandi_Pembantu`', '`Kamar_Mandi_Pembantu`', 201, -1, FALSE, '`Kamar_Mandi_Pembantu`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'CHECKBOX');
		$this->Kamar_Mandi_Pembantu->Sortable = TRUE; // Allow sort
		$this->Kamar_Mandi_Pembantu->OptionCount = 5;
		$this->fields['Kamar_Mandi_Pembantu'] = &$this->Kamar_Mandi_Pembantu;

		// Listrik
		$this->Listrik = new cField('Laporan_Property', 'Laporan Property', 'x_Listrik', 'Listrik', '`Listrik`', '`Listrik`', 200, -1, FALSE, '`Listrik`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'RADIO');
		$this->Listrik->Sortable = TRUE; // Allow sort
		$this->Listrik->OptionCount = 4;
		$this->fields['Listrik'] = &$this->Listrik;

		// Air
		$this->Air = new cField('Laporan_Property', 'Laporan Property', 'x_Air', 'Air', '`Air`', '`Air`', 201, -1, FALSE, '`Air`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'CHECKBOX');
		$this->Air->Sortable = TRUE; // Allow sort
		$this->Air->OptionCount = 2;
		$this->fields['Air'] = &$this->Air;

		// Furtinure
		$this->Furtinure = new cField('Laporan_Property', 'Laporan Property', 'x_Furtinure', 'Furtinure', '`Furtinure`', '`Furtinure`', 201, -1, FALSE, '`Furtinure`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'CHECKBOX');
		$this->Furtinure->Sortable = TRUE; // Allow sort
		$this->Furtinure->OptionCount = 2;
		$this->fields['Furtinure'] = &$this->Furtinure;

		// Hadap
		$this->Hadap = new cField('Laporan_Property', 'Laporan Property', 'x_Hadap', 'Hadap', '`Hadap`', '`Hadap`', 201, -1, FALSE, '`Hadap`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'CHECKBOX');
		$this->Hadap->Sortable = TRUE; // Allow sort
		$this->Hadap->OptionCount = 4;
		$this->fields['Hadap'] = &$this->Hadap;

		// Sertifikat
		$this->Sertifikat = new cField('Laporan_Property', 'Laporan Property', 'x_Sertifikat', 'Sertifikat', '`Sertifikat`', '`Sertifikat`', 201, -1, FALSE, '`Sertifikat`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'CHECKBOX');
		$this->Sertifikat->Sortable = TRUE; // Allow sort
		$this->Sertifikat->OptionCount = 4;
		$this->fields['Sertifikat'] = &$this->Sertifikat;

		// Keterangan
		$this->Keterangan = new cField('Laporan_Property', 'Laporan Property', 'x_Keterangan', 'Keterangan', '`Keterangan`', '`Keterangan`', 200, -1, FALSE, '`Keterangan`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->Keterangan->Sortable = TRUE; // Allow sort
		$this->fields['Keterangan'] = &$this->Keterangan;

		// Foto
		$this->Foto = new cField('Laporan_Property', 'Laporan Property', 'x_Foto', 'Foto', '`Foto`', '`Foto`', 205, -1, TRUE, '`Foto`', FALSE, FALSE, FALSE, 'IMAGE', 'FILE');
		$this->Foto->Sortable = TRUE; // Allow sort
		$this->Foto->ImageResize = TRUE;
		$this->fields['Foto'] = &$this->Foto;
	}

	// Set Field Visibility
	function SetFieldVisibility($fldparm) {
		global $Security;
		return $this->$fldparm->Visible; // Returns original value
	}

	// Report detail level SQL
	var $_SqlDetailSelect = "";

	function getSqlDetailSelect() { // Select
		return ($this->_SqlDetailSelect <> "") ? $this->_SqlDetailSelect : "SELECT * FROM `property`";
	}

	function SqlDetailSelect() { // For backward compatibility
		return $this->getSqlDetailSelect();
	}

	function setSqlDetailSelect($v) {
		$this->_SqlDetailSelect = $v;
	}
	var $_SqlDetailWhere = "";

	function getSqlDetailWhere() { // Where
		return ($this->_SqlDetailWhere <> "") ? $this->_SqlDetailWhere : "";
	}

	function SqlDetailWhere() { // For backward compatibility
		return $this->getSqlDetailWhere();
	}

	function setSqlDetailWhere($v) {
		$this->_SqlDetailWhere = $v;
	}
	var $_SqlDetailGroupBy = "";

	function getSqlDetailGroupBy() { // Group By
		return ($this->_SqlDetailGroupBy <> "") ? $this->_SqlDetailGroupBy : "";
	}

	function SqlDetailGroupBy() { // For backward compatibility
		return $this->getSqlDetailGroupBy();
	}

	function setSqlDetailGroupBy($v) {
		$this->_SqlDetailGroupBy = $v;
	}
	var $_SqlDetailHaving = "";

	function getSqlDetailHaving() { // Having
		return ($this->_SqlDetailHaving <> "") ? $this->_SqlDetailHaving : "";
	}

	function SqlDetailHaving() { // For backward compatibility
		return $this->getSqlDetailHaving();
	}

	function setSqlDetailHaving($v) {
		$this->_SqlDetailHaving = $v;
	}
	var $_SqlDetailOrderBy = "";

	function getSqlDetailOrderBy() { // Order By
		return ($this->_SqlDetailOrderBy <> "") ? $this->_SqlDetailOrderBy : "";
	}

	function SqlDetailOrderBy() { // For backward compatibility
		return $this->getSqlDetailOrderBy();
	}

	function setSqlDetailOrderBy($v) {
		$this->_SqlDetailOrderBy = $v;
	}

	// Apply User ID filters
	function ApplyUserIDFilters($sFilter) {
		return $sFilter;
	}

	// Check if User ID security allows view all
	function UserIDAllow($id = "") {
		$allow = EW_USER_ID_ALLOW;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Report detail SQL
	function DetailSQL() {
		$sFilter = $this->CurrentFilter;
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$sSort = "";
		return ew_BuildSelectSql($this->getSqlDetailSelect(), $this->getSqlDetailWhere(),
			$this->getSqlDetailGroupBy(), $this->getSqlDetailHaving(),
			$this->getSqlDetailOrderBy(), $sFilter, $sSort);
	}

	// Return page URL
	function getReturnUrl() {
		$name = EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL;

		// Get referer URL automatically
		if (ew_ServerVar("HTTP_REFERER") <> "" && ew_ReferPage() <> ew_CurrentPage() && ew_ReferPage() <> "login.php") // Referer not same page or login page
			$_SESSION[$name] = ew_ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] <> "") {
			return $_SESSION[$name];
		} else {
			return "Laporan_Propertyreport.php";
		}
	}

	function setReturnUrl($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL] = $v;
	}

	// List URL
	function GetListUrl() {
		return "Laporan_Propertyreport.php";
	}

	// View URL
	function GetViewUrl($parm = "") {
		if ($parm <> "")
			$url = $this->KeyUrl("", $this->UrlParm($parm));
		else
			$url = $this->KeyUrl("", $this->UrlParm(EW_TABLE_SHOW_DETAIL . "="));
		return $this->AddMasterUrl($url);
	}

	// Add URL
	function GetAddUrl($parm = "") {
		if ($parm <> "")
			$url = "?" . $this->UrlParm($parm);
		else
			$url = "";
		return $this->AddMasterUrl($url);
	}

	// Edit URL
	function GetEditUrl($parm = "") {
		$url = $this->KeyUrl("", $this->UrlParm($parm));
		return $this->AddMasterUrl($url);
	}

	// Inline edit URL
	function GetInlineEditUrl() {
		$url = $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=edit"));
		return $this->AddMasterUrl($url);
	}

	// Copy URL
	function GetCopyUrl($parm = "") {
		$url = $this->KeyUrl("", $this->UrlParm($parm));
		return $this->AddMasterUrl($url);
	}

	// Inline copy URL
	function GetInlineCopyUrl() {
		$url = $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=copy"));
		return $this->AddMasterUrl($url);
	}

	// Delete URL
	function GetDeleteUrl() {
		return $this->KeyUrl("", $this->UrlParm());
	}

	// Add master url
	function AddMasterUrl($url) {
		return $url;
	}

	function KeyToJson() {
		$json = "";
		$json .= "Id:" . ew_VarToJson($this->Id->CurrentValue, "number", "'");
		return "{" . $json . "}";
	}

	// Add key value to URL
	function KeyUrl($url, $parm = "") {
		$sUrl = $url . "?";
		if ($parm <> "") $sUrl .= $parm . "&";
		if (!is_null($this->Id->CurrentValue)) {
			$sUrl .= "Id=" . urlencode($this->Id->CurrentValue);
		} else {
			return "javascript:ew_Alert(ewLanguage.Phrase('InvalidRecord'));";
		}
		return $sUrl;
	}

	// Sort URL
	function SortUrl(&$fld) {
		return "";
	}

	// Get record keys from $_POST/$_GET/$_SESSION
	function GetRecordKeys() {
		global $EW_COMPOSITE_KEY_SEPARATOR;
		$arKeys = array();
		$arKey = array();
		if (isset($_POST["key_m"])) {
			$arKeys = ew_StripSlashes($_POST["key_m"]);
			$cnt = count($arKeys);
		} elseif (isset($_GET["key_m"])) {
			$arKeys = ew_StripSlashes($_GET["key_m"]);
			$cnt = count($arKeys);
		} elseif (!empty($_GET) || !empty($_POST)) {
			$isPost = ew_IsHttpPost();
			if ($isPost && isset($_POST["Id"]))
				$arKeys[] = ew_StripSlashes($_POST["Id"]);
			elseif (isset($_GET["Id"]))
				$arKeys[] = ew_StripSlashes($_GET["Id"]);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = array();
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get key filter
	function GetKeyFilter() {
		$arKeys = $this->GetRecordKeys();
		$sKeyFilter = "";
		foreach ($arKeys as $key) {
			if ($sKeyFilter <> "") $sKeyFilter .= " OR ";
			$this->Id->CurrentValue = $key;
			$sKeyFilter .= "(" . $this->KeyFilter() . ")";
		}
		return $sKeyFilter;
	}

	// Load rows based on filter
	function &LoadRs($sFilter) {

		// Set up filter (SQL WHERE clause) and get return SQL
		//$this->CurrentFilter = $sFilter;
		//$sSql = $this->SQL();

		$sSql = $this->GetSQL($sFilter, "");
		$conn = &$this->Connection();
		$rs = $conn->Execute($sSql);
		return $rs;
	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here	
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>); 

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>
<?php include_once "admininfo.php" ?>
<?php include_once "userfn13.php" ?>
<?php

//
// Page class
//

$Laporan_Property_report = NULL; // Initialize page object first

class cLaporan_Property_report extends cLaporan_Property {

	// Page ID
	var $PageID = 'report';

	// Project ID
	var $ProjectID = "{1B30E8D9-D363-49E8-A880-2B04CACE607B}";

	// Table name
	var $TableName = 'Laporan Property';

	// Page object name
	var $PageObjName = 'Laporan_Property_report';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		return $PageUrl;
	}

	// Page URLs
	var $AddUrl;
	var $EditUrl;
	var $CopyUrl;
	var $DeleteUrl;
	var $ViewUrl;
	var $ListUrl;

	// Export URLs
	var $ExportPrintUrl;
	var $ExportHtmlUrl;
	var $ExportExcelUrl;
	var $ExportWordUrl;
	var $ExportXmlUrl;
	var $ExportCsvUrl;
	var $ExportPdfUrl;

	// Custom export
	var $ExportExcelCustom = FALSE;
	var $ExportWordCustom = FALSE;
	var $ExportPdfCustom = FALSE;
	var $ExportEmailCustom = FALSE;

	// Update URLs
	var $InlineAddUrl;
	var $InlineCopyUrl;
	var $InlineEditUrl;
	var $GridAddUrl;
	var $GridEditUrl;
	var $MultiDeleteUrl;
	var $MultiUpdateUrl;

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_MESSAGE], $v);
	}

	function getFailureMessage() {
		return @$_SESSION[EW_SESSION_FAILURE_MESSAGE];
	}

	function setFailureMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_FAILURE_MESSAGE], $v);
	}

	function getSuccessMessage() {
		return @$_SESSION[EW_SESSION_SUCCESS_MESSAGE];
	}

	function setSuccessMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_SUCCESS_MESSAGE], $v);
	}

	function getWarningMessage() {
		return @$_SESSION[EW_SESSION_WARNING_MESSAGE];
	}

	function setWarningMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_WARNING_MESSAGE], $v);
	}

	// Methods to clear message
	function ClearMessage() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
	}

	function ClearFailureMessage() {
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
	}

	function ClearSuccessMessage() {
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
	}

	function ClearWarningMessage() {
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	function ClearMessages() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	// Show message
	function ShowMessage() {
		$hidden = TRUE;
		$html = "";

		// Message
		$sMessage = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sMessage, "");
		if ($sMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sMessage;
			$html .= "<div class=\"alert alert-info ewInfo\">" . $sMessage . "</div>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$sWarningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sWarningMessage, "warning");
		if ($sWarningMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sWarningMessage;
			$html .= "<div class=\"alert alert-warning ewWarning\">" . $sWarningMessage . "</div>";
			$_SESSION[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$sSuccessMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sSuccessMessage, "success");
		if ($sSuccessMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sSuccessMessage;
			$html .= "<div class=\"alert alert-success ewSuccess\">" . $sSuccessMessage . "</div>";
			$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$sErrorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sErrorMessage, "failure");
		if ($sErrorMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sErrorMessage;
			$html .= "<div class=\"alert alert-danger ewError\">" . $sErrorMessage . "</div>";
			$_SESSION[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo "<div class=\"ewMessageDialog\"" . (($hidden) ? " style=\"display: none;\"" : "") . ">" . $html . "</div>";
	}
	var $PageHeader;
	var $PageFooter;

	// Show Page Header
	function ShowPageHeader() {
		$sHeader = $this->PageHeader;
		$this->Page_DataRendering($sHeader);
		if ($sHeader <> "") { // Header exists, display
			echo "<p>" . $sHeader . "</p>";
		}
	}

	// Show Page Footer
	function ShowPageFooter() {
		$sFooter = $this->PageFooter;
		$this->Page_DataRendered($sFooter);
		if ($sFooter <> "") { // Footer exists, display
			echo "<p>" . $sFooter . "</p>";
		}
	}

	// Validate page request
	function IsPageRequest() {
		return TRUE;
	}
	var $Token = "";
	var $TokenTimeout = 0;
	var $CheckToken = EW_CHECK_TOKEN;
	var $CheckTokenFn = "ew_CheckToken";
	var $CreateTokenFn = "ew_CreateToken";

	// Valid Post
	function ValidPost() {
		if (!$this->CheckToken || !ew_IsHttpPost())
			return TRUE;
		if (!isset($_POST[EW_TOKEN_NAME]))
			return FALSE;
		$fn = $this->CheckTokenFn;
		if (is_callable($fn))
			return $fn($_POST[EW_TOKEN_NAME], $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	function CreateToken() {
		global $gsToken;
		if ($this->CheckToken) {
			$fn = $this->CreateTokenFn;
			if ($this->Token == "" && is_callable($fn)) // Create token
				$this->Token = $fn();
			$gsToken = $this->Token; // Save to global variable
		}
	}

	//
	// Page class constructor
	//
	function __construct() {
		global $conn, $Language;
		global $UserTable, $UserTableConn;
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = ew_SessionTimeoutTime();

		// Language object
		if (!isset($Language)) $Language = new cLanguage();

		// Parent constuctor
		parent::__construct();

		// Table object (Laporan_Property)
		if (!isset($GLOBALS["Laporan_Property"]) || get_class($GLOBALS["Laporan_Property"]) == "cLaporan_Property") {
			$GLOBALS["Laporan_Property"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["Laporan_Property"];
		}

		// Initialize URLs
		$this->ExportPrintUrl = $this->PageUrl() . "export=print";
		$this->ExportExcelUrl = $this->PageUrl() . "export=excel";
		$this->ExportWordUrl = $this->PageUrl() . "export=word";

		// Table object (admin)
		if (!isset($GLOBALS['admin'])) $GLOBALS['admin'] = new cadmin();

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'report', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'Laporan Property', TRUE);

		// Start timer
		if (!isset($GLOBALS["gTimer"])) $GLOBALS["gTimer"] = new cTimer();

		// Open connection
		if (!isset($conn)) $conn = ew_Connect($this->DBID);

		// User table object (admin)
		if (!isset($UserTable)) {
			$UserTable = new cadmin();
			$UserTableConn = Conn($UserTable->DBID);
		}

		// Export options
		$this->ExportOptions = new cListOptions();
		$this->ExportOptions->Tag = "div";
		$this->ExportOptions->TagClassName = "ewExportOption";
	}

	//
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsCustomExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;

		// Security
		$Security = new cAdvancedSecurity();
		if (!$Security->IsLoggedIn()) $Security->AutoLogin();
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loading();
		$Security->LoadCurrentUserLevel($this->ProjectID . $this->TableName);
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loaded();
		if (!$Security->CanReport()) {
			$Security->SaveLastUrl();
			$this->setFailureMessage(ew_DeniedMsg()); // Set no permission
			$this->Page_Terminate(ew_GetUrl("index.php"));
		}

		// Get export parameters
		$custom = "";
		if (@$_GET["export"] <> "") {
			$this->Export = $_GET["export"];
			$custom = @$_GET["custom"];
		} elseif (@$_POST["export"] <> "") {
			$this->Export = $_POST["export"];
			$custom = @$_POST["custom"];
		}
		$gsExportFile = $this->TableVar; // Get export file, used in header

		// Get custom export parameters
		if ($this->Export <> "" && $custom <> "") {
			$this->CustomExport = $this->Export;
			$this->Export = "print";
		}
		$gsCustomExport = $this->CustomExport;
		$gsExport = $this->Export; // Get export parameter, used in header

		// Update Export URLs
		if (defined("EW_USE_PHPEXCEL"))
			$this->ExportExcelCustom = FALSE;
		if ($this->ExportExcelCustom)
			$this->ExportExcelUrl .= "&amp;custom=1";
		if (defined("EW_USE_PHPWORD"))
			$this->ExportWordCustom = FALSE;
		if ($this->ExportWordCustom)
			$this->ExportWordUrl .= "&amp;custom=1";
		if ($this->ExportPdfCustom)
			$this->ExportPdfUrl .= "&amp;custom=1";
		$this->CurrentAction = (@$_GET["a"] <> "") ? $_GET["a"] : @$_POST["a_list"]; // Set up current action

		// Setup export options
		$this->SetupExportOptions();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->ValidPost()) {
			echo $Language->Phrase("InvalidPostRequest");
			$this->Page_Terminate();
			exit();
		}

		// Create Token
		$this->CreateToken();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $gsExportFile, $gTmpImages;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $EW_EXPORT_REPORT;
		if ($this->Export <> "" && array_key_exists($this->Export, $EW_EXPORT_REPORT)) {
			$sContent = ob_get_contents();
			$fn = $EW_EXPORT_REPORT[$this->Export];
			$this->$fn($sContent);
		}
		$this->Page_Redirecting($url);

		 // Close connection
		ew_CloseConn();

		// Go to URL if specified
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			header("Location: " . $url);
		}
		exit();
	}
	var $ExportOptions; // Export options
	var $RecCnt = 0;
	var $RowCnt = 0; // For custom view tag
	var $ReportSql = "";
	var $ReportFilter = "";
	var $DefaultFilter = "";
	var $DbMasterFilter = "";
	var $DbDetailFilter = "";
	var $MasterRecordExists;
	var $Command;
	var $DtlRecordCount;
	var $ReportGroups;
	var $ReportCounts;
	var $LevelBreak;
	var $ReportTotals;
	var $ReportMaxs;
	var $ReportMins;
	var $Recordset;
	var $DetailRecordset;
	var $RecordExists;

	//
	// Page main
	//
	function Page_Main() {
		global $Language;
		$this->ReportGroups = &ew_InitArray(1, NULL);
		$this->ReportCounts = &ew_InitArray(1, 0);
		$this->LevelBreak = &ew_InitArray(1, FALSE);
		$this->ReportTotals = &ew_Init2DArray(1, 15, 0);
		$this->ReportMaxs = &ew_Init2DArray(1, 15, 0);
		$this->ReportMins = &ew_Init2DArray(1, 15, 0);

		// Set up Breadcrumb
		$this->SetupBreadcrumb();
	}

	// Render row values based on field settings
	function RenderRow() {
		global $Security, $Language, $gsLanguage;

		// Initialize URLs
		// Call Row_Rendering event

		$this->Row_Rendering();

		// Common render codes for all row types
		// Id
		// Alamat_Property
		// Alamat
		// Luas_Tanah/Bangunan
		// Lantai
		// Kamar_Tidur
		// Kamar_Mandi_Pembantu
		// Listrik
		// Air
		// Furtinure
		// Hadap
		// Sertifikat
		// Keterangan
		// Foto

		if ($this->RowType == EW_ROWTYPE_VIEW) { // View row

		// Id
		$this->Id->ViewValue = $this->Id->CurrentValue;
		$this->Id->ViewCustomAttributes = "";

		// Alamat_Property
		$this->Alamat_Property->ViewValue = $this->Alamat_Property->CurrentValue;
		$this->Alamat_Property->CellCssStyle .= "text-align: center;";
		$this->Alamat_Property->ViewCustomAttributes = "";

		// Alamat
		$this->Alamat->ViewValue = $this->Alamat->CurrentValue;
		$this->Alamat->ViewCustomAttributes = "";

		// Luas_Tanah/Bangunan
		$this->Luas_Tanah2FBangunan->ViewValue = $this->Luas_Tanah2FBangunan->CurrentValue;
		$this->Luas_Tanah2FBangunan->CellCssStyle .= "text-align: center;";
		$this->Luas_Tanah2FBangunan->ViewCustomAttributes = "";

		// Lantai
		if (strval($this->Lantai->CurrentValue) <> "") {
			$this->Lantai->ViewValue = "";
			$arwrk = explode(",", strval($this->Lantai->CurrentValue));
			$cnt = count($arwrk);
			for ($ari = 0; $ari < $cnt; $ari++) {
				$this->Lantai->ViewValue .= $this->Lantai->OptionCaption(trim($arwrk[$ari]));
				if ($ari < $cnt-1) $this->Lantai->ViewValue .= ew_ViewOptionSeparator($ari);
			}
		} else {
			$this->Lantai->ViewValue = NULL;
		}
		$this->Lantai->CellCssStyle .= "text-align: center;";
		$this->Lantai->ViewCustomAttributes = "";

		// Kamar_Tidur
		if (strval($this->Kamar_Tidur->CurrentValue) <> "") {
			$this->Kamar_Tidur->ViewValue = $this->Kamar_Tidur->OptionCaption($this->Kamar_Tidur->CurrentValue);
		} else {
			$this->Kamar_Tidur->ViewValue = NULL;
		}
		$this->Kamar_Tidur->CellCssStyle .= "text-align: center;";
		$this->Kamar_Tidur->ViewCustomAttributes = "";

		// Kamar_Mandi_Pembantu
		if (strval($this->Kamar_Mandi_Pembantu->CurrentValue) <> "") {
			$this->Kamar_Mandi_Pembantu->ViewValue = "";
			$arwrk = explode(",", strval($this->Kamar_Mandi_Pembantu->CurrentValue));
			$cnt = count($arwrk);
			for ($ari = 0; $ari < $cnt; $ari++) {
				$this->Kamar_Mandi_Pembantu->ViewValue .= $this->Kamar_Mandi_Pembantu->OptionCaption(trim($arwrk[$ari]));
				if ($ari < $cnt-1) $this->Kamar_Mandi_Pembantu->ViewValue .= ew_ViewOptionSeparator($ari);
			}
		} else {
			$this->Kamar_Mandi_Pembantu->ViewValue = NULL;
		}
		$this->Kamar_Mandi_Pembantu->CellCssStyle .= "text-align: center;";
		$this->Kamar_Mandi_Pembantu->ViewCustomAttributes = "";

		// Listrik
		if (strval($this->Listrik->CurrentValue) <> "") {
			$this->Listrik->ViewValue = $this->Listrik->OptionCaption($this->Listrik->CurrentValue);
		} else {
			$this->Listrik->ViewValue = NULL;
		}
		$this->Listrik->CellCssStyle .= "text-align: center;";
		$this->Listrik->ViewCustomAttributes = "";

		// Air
		if (strval($this->Air->CurrentValue) <> "") {
			$this->Air->ViewValue = "";
			$arwrk = explode(",", strval($this->Air->CurrentValue));
			$cnt = count($arwrk);
			for ($ari = 0; $ari < $cnt; $ari++) {
				$this->Air->ViewValue .= $this->Air->OptionCaption(trim($arwrk[$ari]));
				if ($ari < $cnt-1) $this->Air->ViewValue .= ew_ViewOptionSeparator($ari);
			}
		} else {
			$this->Air->ViewValue = NULL;
		}
		$this->Air->CellCssStyle .= "text-align: center;";
		$this->Air->ViewCustomAttributes = "";

		// Furtinure
		if (strval($this->Furtinure->CurrentValue) <> "") {
			$this->Furtinure->ViewValue = "";
			$arwrk = explode(",", strval($this->Furtinure->CurrentValue));
			$cnt = count($arwrk);
			for ($ari = 0; $ari < $cnt; $ari++) {
				$this->Furtinure->ViewValue .= $this->Furtinure->OptionCaption(trim($arwrk[$ari]));
				if ($ari < $cnt-1) $this->Furtinure->ViewValue .= ew_ViewOptionSeparator($ari);
			}
		} else {
			$this->Furtinure->ViewValue = NULL;
		}
		$this->Furtinure->CellCssStyle .= "text-align: center;";
		$this->Furtinure->ViewCustomAttributes = "";

		// Hadap
		if (strval($this->Hadap->CurrentValue) <> "") {
			$this->Hadap->ViewValue = "";
			$arwrk = explode(",", strval($this->Hadap->CurrentValue));
			$cnt = count($arwrk);
			for ($ari = 0; $ari < $cnt; $ari++) {
				$this->Hadap->ViewValue .= $this->Hadap->OptionCaption(trim($arwrk[$ari]));
				if ($ari < $cnt-1) $this->Hadap->ViewValue .= ew_ViewOptionSeparator($ari);
			}
		} else {
			$this->Hadap->ViewValue = NULL;
		}
		$this->Hadap->CellCssStyle .= "text-align: center;";
		$this->Hadap->ViewCustomAttributes = "";

		// Sertifikat
		if (strval($this->Sertifikat->CurrentValue) <> "") {
			$this->Sertifikat->ViewValue = "";
			$arwrk = explode(",", strval($this->Sertifikat->CurrentValue));
			$cnt = count($arwrk);
			for ($ari = 0; $ari < $cnt; $ari++) {
				$this->Sertifikat->ViewValue .= $this->Sertifikat->OptionCaption(trim($arwrk[$ari]));
				if ($ari < $cnt-1) $this->Sertifikat->ViewValue .= ew_ViewOptionSeparator($ari);
			}
		} else {
			$this->Sertifikat->ViewValue = NULL;
		}
		$this->Sertifikat->CellCssStyle .= "text-align: center;";
		$this->Sertifikat->ViewCustomAttributes = "";

		// Keterangan
		$this->Keterangan->ViewValue = $this->Keterangan->CurrentValue;
		$this->Keterangan->CellCssStyle .= "text-align: center;";
		$this->Keterangan->ViewCustomAttributes = "";

		// Foto
		if (!ew_Empty($this->Foto->Upload->DbValue)) {
			$this->Foto->ImageWidth = EW_THUMBNAIL_DEFAULT_WIDTH;
			$this->Foto->ImageHeight = EW_THUMBNAIL_DEFAULT_HEIGHT;
			$this->Foto->ImageAlt = $this->Foto->FldAlt();
			$this->Foto->ViewValue = "Laporan_Property_Foto_bv.php?" . "Id=" . $this->Id->CurrentValue . "&amp;showthumbnail=1&amp;thumbnailwidth=" . $this->Foto->ImageWidth . "&amp;thumbnailheight=" . $this->Foto->ImageHeight;
			$this->Foto->IsBlobImage = ew_IsImageFile("image" . ew_ContentExt(substr($this->Foto->Upload->DbValue, 0, 11)));
		} else {
			$this->Foto->ViewValue = "";
		}
		$this->Foto->ViewCustomAttributes = "";

			// Id
			$this->Id->LinkCustomAttributes = "";
			$this->Id->HrefValue = "";
			$this->Id->TooltipValue = "";

			// Alamat_Property
			$this->Alamat_Property->LinkCustomAttributes = "";
			$this->Alamat_Property->HrefValue = "";
			$this->Alamat_Property->TooltipValue = "";

			// Alamat
			$this->Alamat->LinkCustomAttributes = "";
			$this->Alamat->HrefValue = "";
			$this->Alamat->TooltipValue = "";

			// Luas_Tanah/Bangunan
			$this->Luas_Tanah2FBangunan->LinkCustomAttributes = "";
			$this->Luas_Tanah2FBangunan->HrefValue = "";
			$this->Luas_Tanah2FBangunan->TooltipValue = "";

			// Lantai
			$this->Lantai->LinkCustomAttributes = "";
			$this->Lantai->HrefValue = "";
			$this->Lantai->TooltipValue = "";

			// Kamar_Tidur
			$this->Kamar_Tidur->LinkCustomAttributes = "";
			$this->Kamar_Tidur->HrefValue = "";
			$this->Kamar_Tidur->TooltipValue = "";

			// Kamar_Mandi_Pembantu
			$this->Kamar_Mandi_Pembantu->LinkCustomAttributes = "";
			$this->Kamar_Mandi_Pembantu->HrefValue = "";
			$this->Kamar_Mandi_Pembantu->TooltipValue = "";

			// Listrik
			$this->Listrik->LinkCustomAttributes = "";
			$this->Listrik->HrefValue = "";
			$this->Listrik->TooltipValue = "";

			// Air
			$this->Air->LinkCustomAttributes = "";
			$this->Air->HrefValue = "";
			$this->Air->TooltipValue = "";

			// Furtinure
			$this->Furtinure->LinkCustomAttributes = "";
			$this->Furtinure->HrefValue = "";
			$this->Furtinure->TooltipValue = "";

			// Hadap
			$this->Hadap->LinkCustomAttributes = "";
			$this->Hadap->HrefValue = "";
			$this->Hadap->TooltipValue = "";

			// Sertifikat
			$this->Sertifikat->LinkCustomAttributes = "";
			$this->Sertifikat->HrefValue = "";
			$this->Sertifikat->TooltipValue = "";

			// Keterangan
			$this->Keterangan->LinkCustomAttributes = "";
			$this->Keterangan->HrefValue = "";
			$this->Keterangan->TooltipValue = "";

			// Foto
			$this->Foto->LinkCustomAttributes = "";
			if (!empty($this->Foto->Upload->DbValue)) {
				$this->Foto->HrefValue = "Laporan_Property_Foto_bv.php?Id=" . $this->Id->CurrentValue;
				$this->Foto->LinkAttrs["target"] = "_blank";
				if ($this->Export <> "") $this->Foto->HrefValue = ew_ConvertFullUrl($this->Foto->HrefValue);
			} else {
				$this->Foto->HrefValue = "";
			}
			$this->Foto->HrefValue2 = "Laporan_Property_Foto_bv.php?Id=" . $this->Id->CurrentValue . "&amp;showthumbnail=1&amp;thumbnailwidth=" . $this->Foto->ImageWidth . "&amp;thumbnailheight=" . $this->Foto->ImageHeight;
			$this->Foto->TooltipValue = "";
			if ($this->Foto->UseColorbox) {
				if (ew_Empty($this->Foto->TooltipValue))
					$this->Foto->LinkAttrs["title"] = $Language->Phrase("ViewImageGallery");
				$this->Foto->LinkAttrs["data-rel"] = "Laporan_Property_x_Foto";
				ew_AppendClass($this->Foto->LinkAttrs["class"], "ewLightbox");
			}
		}

		// Call Row Rendered event
		if ($this->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Set up export options
	function SetupExportOptions() {
		global $Language;

		// Printer friendly
		$item = &$this->ExportOptions->Add("print");
		$item->Body = "<a href=\"" . $this->ExportPrintUrl . "\" class=\"ewExportLink ewPrint\" title=\"" . ew_HtmlEncode($Language->Phrase("PrinterFriendlyText")) . "\" data-caption=\"" . ew_HtmlEncode($Language->Phrase("PrinterFriendlyText")) . "\">" . $Language->Phrase("PrinterFriendly") . "</a>";
		$item->Visible = TRUE;

		// Export to Excel
		$item = &$this->ExportOptions->Add("excel");
		$item->Body = "<a href=\"" . $this->ExportExcelUrl . "\" class=\"ewExportLink ewExcel\" title=\"" . ew_HtmlEncode($Language->Phrase("ExportToExcelText")) . "\" data-caption=\"" . ew_HtmlEncode($Language->Phrase("ExportToExcelText")) . "\">" . $Language->Phrase("ExportToExcel") . "</a>";
		$item->Visible = TRUE;

		// Export to Word
		$item = &$this->ExportOptions->Add("word");
		$item->Body = "<a href=\"" . $this->ExportWordUrl . "\" class=\"ewExportLink ewWord\" title=\"" . ew_HtmlEncode($Language->Phrase("ExportToWordText")) . "\" data-caption=\"" . ew_HtmlEncode($Language->Phrase("ExportToWordText")) . "\">" . $Language->Phrase("ExportToWord") . "</a>";
		$item->Visible = TRUE;

		// Drop down button for export
		$this->ExportOptions->UseButtonGroup = TRUE;
		$this->ExportOptions->UseImageAndText = TRUE;
		$this->ExportOptions->UseDropDownButton = TRUE;
		if ($this->ExportOptions->UseButtonGroup && ew_IsMobile())
			$this->ExportOptions->UseDropDownButton = TRUE;
		$this->ExportOptions->DropDownButtonPhrase = $Language->Phrase("ButtonExport");

		// Add group option item
		$item = &$this->ExportOptions->Add($this->ExportOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Hide options for export
		if ($this->Export <> "")
			$this->ExportOptions->HideAllOptions();
	}

	// Set up Breadcrumb
	function SetupBreadcrumb() {
		global $Breadcrumb, $Language;
		$Breadcrumb = new cBreadcrumb();
		$url = substr(ew_CurrentUrl(), strrpos(ew_CurrentUrl(), "/")+1);
		$url = preg_replace('/\?cmd=reset(all){0,1}$/i', '', $url); // Remove cmd=reset / cmd=resetall
		$Breadcrumb->Add("report", $this->TableVar, $url, "", $this->TableVar, TRUE);
	}

	// Setup lookup filters of a field
	function SetupLookupFilters($fld, $pageId = null) {
		global $gsLanguage;
		$pageId = $pageId ?: $this->PageID;
		switch ($fld->FldVar) {
		}
	}

	// Setup AutoSuggest filters of a field
	function SetupAutoSuggestFilters($fld, $pageId = null) {
		global $gsLanguage;
		$pageId = $pageId ?: $this->PageID;
		switch ($fld->FldVar) {
		}
	}

	// Export report to HTML
	function ExportReportHtml($html) {

		//global $gsExportFile;
		//header('Content-Type: text/html' . (EW_CHARSET <> '' ? ';charset=' . EW_CHARSET : ''));
		//header('Content-Disposition: attachment; filename=' . $gsExportFile . '.html');
		//echo $html;

	}

	// Export report to WORD
	function ExportReportWord($html) {
		global $gsExportFile;
		header('Content-Type: application/vnd.ms-word' . (EW_CHARSET <> '' ? ';charset=' . EW_CHARSET : ''));
		header('Content-Disposition: attachment; filename=' . $gsExportFile . '.doc');
		echo $html;
	}

	// Export report to EXCEL
	function ExportReportExcel($html) {
		global $gsExportFile;
		header('Content-Type: application/vnd.ms-excel' . (EW_CHARSET <> '' ? ';charset=' . EW_CHARSET : ''));
		header('Content-Disposition: attachment; filename=' . $gsExportFile . '.xls');
		echo $html;
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}
}
?>
<?php ew_Header(FALSE) ?>
<?php

// Create page object
if (!isset($Laporan_Property_report)) $Laporan_Property_report = new cLaporan_Property_report();

// Page init
$Laporan_Property_report->Page_Init();

// Page main
$Laporan_Property_report->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$Laporan_Property_report->Page_Render();
?>
<?php include_once "header.php" ?>
<?php if ($Laporan_Property->Export == "") { ?>
<script type="text/javascript">

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<div class="ewToolbar">
<?php if ($Laporan_Property->Export == "") { ?>
<?php $Breadcrumb->Render(); ?>
<?php } ?>
<?php if ($Laporan_Property->Export == "") { ?>
<?php echo $Language->SelectionForm(); ?>
<?php } ?>
<div class="clearfix"></div>
</div>
<?php
$Laporan_Property_report->RecCnt = 1; // No grouping
if ($Laporan_Property_report->DbDetailFilter <> "") {
	if ($Laporan_Property_report->ReportFilter <> "") $Laporan_Property_report->ReportFilter .= " AND ";
	$Laporan_Property_report->ReportFilter .= "(" . $Laporan_Property_report->DbDetailFilter . ")";
}
$ReportConn = &$Laporan_Property_report->Connection();

// Set up detail SQL
$Laporan_Property->CurrentFilter = $Laporan_Property_report->ReportFilter;
$Laporan_Property_report->ReportSql = $Laporan_Property->DetailSQL();

// Load recordset
$Laporan_Property_report->Recordset = $ReportConn->Execute($Laporan_Property_report->ReportSql);
$Laporan_Property_report->RecordExists = !$Laporan_Property_report->Recordset->EOF;
?>
<?php if ($Laporan_Property->Export == "") { ?>
<?php if ($Laporan_Property_report->RecordExists) { ?>
<div class="ewViewExportOptions"><?php $Laporan_Property_report->ExportOptions->Render("body") ?></div>
<?php } ?>
<?php } ?>
<?php $Laporan_Property_report->ShowPageHeader(); ?>
<table class="ewReportTable">
<?php

	// Get detail records
	$Laporan_Property_report->ReportFilter = $Laporan_Property_report->DefaultFilter;
	if ($Laporan_Property_report->DbDetailFilter <> "") {
		if ($Laporan_Property_report->ReportFilter <> "")
			$Laporan_Property_report->ReportFilter .= " AND ";
		$Laporan_Property_report->ReportFilter .= "(" . $Laporan_Property_report->DbDetailFilter . ")";
	}
	if (!$Security->CanReport()) {
		if ($sFilter <> "") $sFilter .= " AND ";
		$sFilter .= "(0=1)";
	}

	// Set up detail SQL
	$Laporan_Property->CurrentFilter = $Laporan_Property_report->ReportFilter;
	$Laporan_Property_report->ReportSql = $Laporan_Property->DetailSQL();

	// Load detail records
	$Laporan_Property_report->DetailRecordset = $ReportConn->Execute($Laporan_Property_report->ReportSql);
	$Laporan_Property_report->DtlRecordCount = $Laporan_Property_report->DetailRecordset->RecordCount();

	// Initialize aggregates
	if (!$Laporan_Property_report->DetailRecordset->EOF) {
		$Laporan_Property_report->RecCnt++;
	}
	if ($Laporan_Property_report->RecCnt == 1) {
		$Laporan_Property_report->ReportCounts[0] = 0;
	}
	$Laporan_Property_report->ReportCounts[0] += $Laporan_Property_report->DtlRecordCount;
	if ($Laporan_Property_report->RecordExists) {
?>
	<tr>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Id->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Alamat_Property->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Alamat->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Luas_Tanah2FBangunan->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Lantai->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Kamar_Tidur->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Kamar_Mandi_Pembantu->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Listrik->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Air->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Furtinure->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Hadap->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Sertifikat->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Keterangan->FldCaption() ?></td>
		<td class="ewGroupHeader"><?php echo $Laporan_Property->Foto->FldCaption() ?></td>
	</tr>
<?php
	}
	while (!$Laporan_Property_report->DetailRecordset->EOF) {
		$Laporan_Property_report->RowCnt++;
		$Laporan_Property->Id->setDbValue($Laporan_Property_report->DetailRecordset->fields('Id'));
		$Laporan_Property->Alamat_Property->setDbValue($Laporan_Property_report->DetailRecordset->fields('Alamat_Property'));
		$Laporan_Property->Alamat->setDbValue($Laporan_Property_report->DetailRecordset->fields('Alamat'));
		$Laporan_Property->Luas_Tanah2FBangunan->setDbValue($Laporan_Property_report->DetailRecordset->fields('Luas_Tanah/Bangunan'));
		$Laporan_Property->Lantai->setDbValue($Laporan_Property_report->DetailRecordset->fields('Lantai'));
		$Laporan_Property->Kamar_Tidur->setDbValue($Laporan_Property_report->DetailRecordset->fields('Kamar_Tidur'));
		$Laporan_Property->Kamar_Mandi_Pembantu->setDbValue($Laporan_Property_report->DetailRecordset->fields('Kamar_Mandi_Pembantu'));
		$Laporan_Property->Listrik->setDbValue($Laporan_Property_report->DetailRecordset->fields('Listrik'));
		$Laporan_Property->Air->setDbValue($Laporan_Property_report->DetailRecordset->fields('Air'));
		$Laporan_Property->Furtinure->setDbValue($Laporan_Property_report->DetailRecordset->fields('Furtinure'));
		$Laporan_Property->Hadap->setDbValue($Laporan_Property_report->DetailRecordset->fields('Hadap'));
		$Laporan_Property->Sertifikat->setDbValue($Laporan_Property_report->DetailRecordset->fields('Sertifikat'));
		$Laporan_Property->Keterangan->setDbValue($Laporan_Property_report->DetailRecordset->fields('Keterangan'));
		$Laporan_Property->Foto->Upload->DbValue = $Laporan_Property_report->DetailRecordset->fields('Foto');

		// Render for view
		$Laporan_Property->RowType = EW_ROWTYPE_VIEW;
		$Laporan_Property->ResetAttrs();
		$Laporan_Property_report->RenderRow();
?>
	<tr>
		<td<?php echo $Laporan_Property->Id->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Id->ViewAttributes() ?>>
<?php echo $Laporan_Property->Id->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Alamat_Property->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Alamat_Property->ViewAttributes() ?>>
<?php echo $Laporan_Property->Alamat_Property->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Alamat->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Alamat->ViewAttributes() ?>>
<?php echo $Laporan_Property->Alamat->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Luas_Tanah2FBangunan->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Luas_Tanah2FBangunan->ViewAttributes() ?>>
<?php echo $Laporan_Property->Luas_Tanah2FBangunan->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Lantai->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Lantai->ViewAttributes() ?>>
<?php echo $Laporan_Property->Lantai->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Kamar_Tidur->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Kamar_Tidur->ViewAttributes() ?>>
<?php echo $Laporan_Property->Kamar_Tidur->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Kamar_Mandi_Pembantu->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Kamar_Mandi_Pembantu->ViewAttributes() ?>>
<?php echo $Laporan_Property->Kamar_Mandi_Pembantu->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Listrik->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Listrik->ViewAttributes() ?>>
<?php echo $Laporan_Property->Listrik->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Air->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Air->ViewAttributes() ?>>
<?php echo $Laporan_Property->Air->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Furtinure->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Furtinure->ViewAttributes() ?>>
<?php echo $Laporan_Property->Furtinure->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Hadap->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Hadap->ViewAttributes() ?>>
<?php echo $Laporan_Property->Hadap->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Sertifikat->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Sertifikat->ViewAttributes() ?>>
<?php echo $Laporan_Property->Sertifikat->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Keterangan->CellAttributes() ?>>
<span<?php echo $Laporan_Property->Keterangan->ViewAttributes() ?>>
<?php echo $Laporan_Property->Keterangan->ViewValue ?></span>
</td>
		<td<?php echo $Laporan_Property->Foto->CellAttributes() ?>>
<span>
<?php echo ew_GetFileViewTag($Laporan_Property->Foto, $Laporan_Property->Foto->ViewValue) ?>
</span>
</td>
	</tr>
<?php
		$Laporan_Property_report->DetailRecordset->MoveNext();
	}
	$Laporan_Property_report->DetailRecordset->Close();
?>
<?php if ($Laporan_Property_report->RecordExists) { ?>
	<tr><td colspan=14>&nbsp;<br></td></tr>
	<tr><td colspan=14 class="ewGrandSummary"><?php echo $Language->Phrase("RptGrandTotal") ?>&nbsp;(<?php echo ew_FormatNumber($Laporan_Property_report->ReportCounts[0], 0) ?>&nbsp;<?php echo $Language->Phrase("RptDtlRec") ?>)</td></tr>
<?php } ?>
<?php if ($Laporan_Property_report->RecordExists) { ?>
	<tr><td colspan=14>&nbsp;<br></td></tr>
<?php } else { ?>
	<tr><td><?php echo $Language->Phrase("NoRecord") ?></td></tr>
<?php } ?>
</table>
<?php
$Laporan_Property_report->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<?php if ($Laporan_Property->Export == "") { ?>
<script type="text/javascript">

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php } ?>
<?php include_once "footer.php" ?>
<?php
$Laporan_Property_report->Page_Terminate();
?>
