<?php
if (session_id() == "") session_start(); // Init session data
ob_start(); // Turn on output buffering
?>
<?php include_once "ewcfg13.php" ?>
<?php include_once ((EW_USE_ADODB) ? "adodb5/adodb.inc.php" : "ewmysql13.php") ?>
<?php include_once "phpfn13.php" ?>
<?php include_once "data_marketinginfo.php" ?>
<?php include_once "admininfo.php" ?>
<?php include_once "userfn13.php" ?>
<?php

//
// Page class
//

$data_marketing_add = NULL; // Initialize page object first

class cdata_marketing_add extends cdata_marketing {

	// Page ID
	var $PageID = 'add';

	// Project ID
	var $ProjectID = "{1B30E8D9-D363-49E8-A880-2B04CACE607B}";

	// Table name
	var $TableName = 'data_marketing';

	// Page object name
	var $PageObjName = 'data_marketing_add';

	// Page name
	function PageName() {
		return ew_CurrentPage();
	}

	// Page URL
	function PageUrl() {
		$PageUrl = ew_CurrentPage() . "?";
		if ($this->UseTokenInUrl) $PageUrl .= "t=" . $this->TableVar . "&"; // Add page token
		return $PageUrl;
	}

	// Message
	function getMessage() {
		return @$_SESSION[EW_SESSION_MESSAGE];
	}

	function setMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_MESSAGE], $v);
	}

	function getFailureMessage() {
		return @$_SESSION[EW_SESSION_FAILURE_MESSAGE];
	}

	function setFailureMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_FAILURE_MESSAGE], $v);
	}

	function getSuccessMessage() {
		return @$_SESSION[EW_SESSION_SUCCESS_MESSAGE];
	}

	function setSuccessMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_SUCCESS_MESSAGE], $v);
	}

	function getWarningMessage() {
		return @$_SESSION[EW_SESSION_WARNING_MESSAGE];
	}

	function setWarningMessage($v) {
		ew_AddMessage($_SESSION[EW_SESSION_WARNING_MESSAGE], $v);
	}

	// Methods to clear message
	function ClearMessage() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
	}

	function ClearFailureMessage() {
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
	}

	function ClearSuccessMessage() {
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
	}

	function ClearWarningMessage() {
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	function ClearMessages() {
		$_SESSION[EW_SESSION_MESSAGE] = "";
		$_SESSION[EW_SESSION_FAILURE_MESSAGE] = "";
		$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = "";
		$_SESSION[EW_SESSION_WARNING_MESSAGE] = "";
	}

	// Show message
	function ShowMessage() {
		$hidden = TRUE;
		$html = "";

		// Message
		$sMessage = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sMessage, "");
		if ($sMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sMessage;
			$html .= "<div class=\"alert alert-info ewInfo\">" . $sMessage . "</div>";
			$_SESSION[EW_SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$sWarningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sWarningMessage, "warning");
		if ($sWarningMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sWarningMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sWarningMessage;
			$html .= "<div class=\"alert alert-warning ewWarning\">" . $sWarningMessage . "</div>";
			$_SESSION[EW_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$sSuccessMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sSuccessMessage, "success");
		if ($sSuccessMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sSuccessMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sSuccessMessage;
			$html .= "<div class=\"alert alert-success ewSuccess\">" . $sSuccessMessage . "</div>";
			$_SESSION[EW_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$sErrorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($sErrorMessage, "failure");
		if ($sErrorMessage <> "") { // Message in Session, display
			if (!$hidden)
				$sErrorMessage = "<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" . $sErrorMessage;
			$html .= "<div class=\"alert alert-danger ewError\">" . $sErrorMessage . "</div>";
			$_SESSION[EW_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo "<div class=\"ewMessageDialog\"" . (($hidden) ? " style=\"display: none;\"" : "") . ">" . $html . "</div>";
	}
	var $PageHeader;
	var $PageFooter;

	// Show Page Header
	function ShowPageHeader() {
		$sHeader = $this->PageHeader;
		$this->Page_DataRendering($sHeader);
		if ($sHeader <> "") { // Header exists, display
			echo "<p>" . $sHeader . "</p>";
		}
	}

	// Show Page Footer
	function ShowPageFooter() {
		$sFooter = $this->PageFooter;
		$this->Page_DataRendered($sFooter);
		if ($sFooter <> "") { // Footer exists, display
			echo "<p>" . $sFooter . "</p>";
		}
	}

	// Validate page request
	function IsPageRequest() {
		global $objForm;
		if ($this->UseTokenInUrl) {
			if ($objForm)
				return ($this->TableVar == $objForm->GetValue("t"));
			if (@$_GET["t"] <> "")
				return ($this->TableVar == $_GET["t"]);
		} else {
			return TRUE;
		}
	}
	var $Token = "";
	var $TokenTimeout = 0;
	var $CheckToken = EW_CHECK_TOKEN;
	var $CheckTokenFn = "ew_CheckToken";
	var $CreateTokenFn = "ew_CreateToken";

	// Valid Post
	function ValidPost() {
		if (!$this->CheckToken || !ew_IsHttpPost())
			return TRUE;
		if (!isset($_POST[EW_TOKEN_NAME]))
			return FALSE;
		$fn = $this->CheckTokenFn;
		if (is_callable($fn))
			return $fn($_POST[EW_TOKEN_NAME], $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	function CreateToken() {
		global $gsToken;
		if ($this->CheckToken) {
			$fn = $this->CreateTokenFn;
			if ($this->Token == "" && is_callable($fn)) // Create token
				$this->Token = $fn();
			$gsToken = $this->Token; // Save to global variable
		}
	}

	//
	// Page class constructor
	//
	function __construct() {
		global $conn, $Language;
		global $UserTable, $UserTableConn;
		$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = ew_SessionTimeoutTime();

		// Language object
		if (!isset($Language)) $Language = new cLanguage();

		// Parent constuctor
		parent::__construct();

		// Table object (data_marketing)
		if (!isset($GLOBALS["data_marketing"]) || get_class($GLOBALS["data_marketing"]) == "cdata_marketing") {
			$GLOBALS["data_marketing"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["data_marketing"];
		}

		// Table object (admin)
		if (!isset($GLOBALS['admin'])) $GLOBALS['admin'] = new cadmin();

		// Page ID
		if (!defined("EW_PAGE_ID"))
			define("EW_PAGE_ID", 'add', TRUE);

		// Table name (for backward compatibility)
		if (!defined("EW_TABLE_NAME"))
			define("EW_TABLE_NAME", 'data_marketing', TRUE);

		// Start timer
		if (!isset($GLOBALS["gTimer"])) $GLOBALS["gTimer"] = new cTimer();

		// Open connection
		if (!isset($conn)) $conn = ew_Connect($this->DBID);

		// User table object (admin)
		if (!isset($UserTable)) {
			$UserTable = new cadmin();
			$UserTableConn = Conn($UserTable->DBID);
		}
	}

	//
	//  Page_Init
	//
	function Page_Init() {
		global $gsExport, $gsCustomExport, $gsExportFile, $UserProfile, $Language, $Security, $objForm;

		// Security
		$Security = new cAdvancedSecurity();
		if (!$Security->IsLoggedIn()) $Security->AutoLogin();
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loading();
		$Security->LoadCurrentUserLevel($this->ProjectID . $this->TableName);
		if ($Security->IsLoggedIn()) $Security->TablePermission_Loaded();
		if (!$Security->CanAdd()) {
			$Security->SaveLastUrl();
			$this->setFailureMessage(ew_DeniedMsg()); // Set no permission
			if ($Security->CanList())
				$this->Page_Terminate(ew_GetUrl("data_marketinglist.php"));
			else
				$this->Page_Terminate(ew_GetUrl("login.php"));
		}

		// Create form object
		$objForm = new cFormObj();
		$this->CurrentAction = (@$_GET["a"] <> "") ? $_GET["a"] : @$_POST["a_list"]; // Set up current action
		$this->Nama->SetVisibility();
		$this->Alamat->SetVisibility();
		$this->No_Ktp->SetVisibility();
		$this->NPWP->SetVisibility();
		$this->Telp->SetVisibility();
		$this->Kode->SetVisibility();
		$this->Area_Listing->SetVisibility();
		$this->Alamat_Lengkap->SetVisibility();
		$this->Nama_yang_bisa_dihubungi->SetVisibility();
		$this->No_Telp->SetVisibility();
		$this->Hubungan->SetVisibility();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->ValidPost()) {
			echo $Language->Phrase("InvalidPostRequest");
			$this->Page_Terminate();
			exit();
		}

		// Process auto fill
		if (@$_POST["ajax"] == "autofill") {
			$results = $this->GetAutoFill(@$_POST["name"], @$_POST["q"]);
			if ($results) {

				// Clean output buffer
				if (!EW_DEBUG_ENABLED && ob_get_length())
					ob_end_clean();
				echo $results;
				$this->Page_Terminate();
				exit();
			}
		}

		// Create Token
		$this->CreateToken();
	}

	//
	// Page_Terminate
	//
	function Page_Terminate($url = "") {
		global $gsExportFile, $gTmpImages;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		global $EW_EXPORT, $data_marketing;
		if ($this->CustomExport <> "" && $this->CustomExport == $this->Export && array_key_exists($this->CustomExport, $EW_EXPORT)) {
				$sContent = ob_get_contents();
			if ($gsExportFile == "") $gsExportFile = $this->TableVar;
			$class = $EW_EXPORT[$this->CustomExport];
			if (class_exists($class)) {
				$doc = new $class($data_marketing);
				$doc->Text = $sContent;
				if ($this->Export == "email")
					echo $this->ExportEmail($doc->Text);
				else
					$doc->Export();
				ew_DeleteTmpImages(); // Delete temp images
				exit();
			}
		}
		$this->Page_Redirecting($url);

		 // Close connection
		ew_CloseConn();

		// Go to URL if specified
		if ($url <> "") {
			if (!EW_DEBUG_ENABLED && ob_get_length())
				ob_end_clean();

			// Handle modal response
			if ($this->IsModal) {
				$row = array();
				$row["url"] = $url;
				echo ew_ArrayToJson(array($row));
			} else {
				header("Location: " . $url);
			}
		}
		exit();
	}
	var $FormClassName = "form-horizontal ewForm ewAddForm";
	var $IsModal = FALSE;
	var $DbMasterFilter = "";
	var $DbDetailFilter = "";
	var $StartRec;
	var $Priv = 0;
	var $OldRecordset;
	var $CopyRecord;

	// 
	// Page main
	//
	function Page_Main() {
		global $objForm, $Language, $gsFormError;
		global $gbSkipHeaderFooter;

		// Check modal
		$this->IsModal = (@$_GET["modal"] == "1" || @$_POST["modal"] == "1");
		if ($this->IsModal)
			$gbSkipHeaderFooter = TRUE;
		$this->FormClassName = "ewForm ewAddForm";
		if (ew_IsMobile() || $this->IsModal)
			$this->FormClassName = ew_Concat("form-horizontal", $this->FormClassName, " ");

		// Process form if post back
		if (@$_POST["a_add"] <> "") {
			$this->CurrentAction = $_POST["a_add"]; // Get form action
			$this->CopyRecord = $this->LoadOldRecord(); // Load old recordset
			$this->LoadFormValues(); // Load form values
		} else { // Not post back

			// Load key values from QueryString
			$this->CopyRecord = TRUE;
			if (@$_GET["No"] != "") {
				$this->No->setQueryStringValue($_GET["No"]);
				$this->setKey("No", $this->No->CurrentValue); // Set up key
			} else {
				$this->setKey("No", ""); // Clear key
				$this->CopyRecord = FALSE;
			}
			if ($this->CopyRecord) {
				$this->CurrentAction = "C"; // Copy record
			} else {
				$this->CurrentAction = "I"; // Display blank record
			}
		}

		// Set up Breadcrumb
		$this->SetupBreadcrumb();

		// Validate form if post back
		if (@$_POST["a_add"] <> "") {
			if (!$this->ValidateForm()) {
				$this->CurrentAction = "I"; // Form error, reset action
				$this->EventCancelled = TRUE; // Event cancelled
				$this->RestoreFormValues(); // Restore form values
				$this->setFailureMessage($gsFormError);
			}
		} else {
			if ($this->CurrentAction == "I") // Load default values for blank record
				$this->LoadDefaultValues();
		}

		// Perform action based on action code
		switch ($this->CurrentAction) {
			case "I": // Blank record, no action required
				break;
			case "C": // Copy an existing record
				if (!$this->LoadRow()) { // Load record based on key
					if ($this->getFailureMessage() == "") $this->setFailureMessage($Language->Phrase("NoRecord")); // No record found
					$this->Page_Terminate("data_marketinglist.php"); // No matching record, return to list
				}
				break;
			case "A": // Add new record
				$this->SendEmail = TRUE; // Send email on add success
				if ($this->AddRow($this->OldRecordset)) { // Add successful
					if ($this->getSuccessMessage() == "")
						$this->setSuccessMessage($Language->Phrase("AddSuccess")); // Set up success message
					$sReturnUrl = $this->getReturnUrl();
					if (ew_GetPageName($sReturnUrl) == "data_marketinglist.php")
						$sReturnUrl = $this->AddMasterUrl($sReturnUrl); // List page, return to list page with correct master key if necessary
					elseif (ew_GetPageName($sReturnUrl) == "data_marketingview.php")
						$sReturnUrl = $this->GetViewUrl(); // View page, return to view page with keyurl directly
					$this->Page_Terminate($sReturnUrl); // Clean up and return
				} else {
					$this->EventCancelled = TRUE; // Event cancelled
					$this->RestoreFormValues(); // Add failed, restore form values
				}
		}

		// Render row based on row type
		$this->RowType = EW_ROWTYPE_ADD; // Render add type

		// Render row
		$this->ResetAttrs();
		$this->RenderRow();
	}

	// Get upload files
	function GetUploadFiles() {
		global $objForm, $Language;

		// Get upload data
	}

	// Load default values
	function LoadDefaultValues() {
		$this->Nama->CurrentValue = NULL;
		$this->Nama->OldValue = $this->Nama->CurrentValue;
		$this->Alamat->CurrentValue = NULL;
		$this->Alamat->OldValue = $this->Alamat->CurrentValue;
		$this->No_Ktp->CurrentValue = NULL;
		$this->No_Ktp->OldValue = $this->No_Ktp->CurrentValue;
		$this->NPWP->CurrentValue = NULL;
		$this->NPWP->OldValue = $this->NPWP->CurrentValue;
		$this->Telp->CurrentValue = NULL;
		$this->Telp->OldValue = $this->Telp->CurrentValue;
		$this->Kode->CurrentValue = NULL;
		$this->Kode->OldValue = $this->Kode->CurrentValue;
		$this->Area_Listing->CurrentValue = NULL;
		$this->Area_Listing->OldValue = $this->Area_Listing->CurrentValue;
		$this->Alamat_Lengkap->CurrentValue = NULL;
		$this->Alamat_Lengkap->OldValue = $this->Alamat_Lengkap->CurrentValue;
		$this->Nama_yang_bisa_dihubungi->CurrentValue = NULL;
		$this->Nama_yang_bisa_dihubungi->OldValue = $this->Nama_yang_bisa_dihubungi->CurrentValue;
		$this->No_Telp->CurrentValue = NULL;
		$this->No_Telp->OldValue = $this->No_Telp->CurrentValue;
		$this->Hubungan->CurrentValue = NULL;
		$this->Hubungan->OldValue = $this->Hubungan->CurrentValue;
	}

	// Load form values
	function LoadFormValues() {

		// Load from form
		global $objForm;
		if (!$this->Nama->FldIsDetailKey) {
			$this->Nama->setFormValue($objForm->GetValue("x_Nama"));
		}
		if (!$this->Alamat->FldIsDetailKey) {
			$this->Alamat->setFormValue($objForm->GetValue("x_Alamat"));
		}
		if (!$this->No_Ktp->FldIsDetailKey) {
			$this->No_Ktp->setFormValue($objForm->GetValue("x_No_Ktp"));
		}
		if (!$this->NPWP->FldIsDetailKey) {
			$this->NPWP->setFormValue($objForm->GetValue("x_NPWP"));
		}
		if (!$this->Telp->FldIsDetailKey) {
			$this->Telp->setFormValue($objForm->GetValue("x_Telp"));
		}
		if (!$this->Kode->FldIsDetailKey) {
			$this->Kode->setFormValue($objForm->GetValue("x_Kode"));
		}
		if (!$this->Area_Listing->FldIsDetailKey) {
			$this->Area_Listing->setFormValue($objForm->GetValue("x_Area_Listing"));
		}
		if (!$this->Alamat_Lengkap->FldIsDetailKey) {
			$this->Alamat_Lengkap->setFormValue($objForm->GetValue("x_Alamat_Lengkap"));
		}
		if (!$this->Nama_yang_bisa_dihubungi->FldIsDetailKey) {
			$this->Nama_yang_bisa_dihubungi->setFormValue($objForm->GetValue("x_Nama_yang_bisa_dihubungi"));
		}
		if (!$this->No_Telp->FldIsDetailKey) {
			$this->No_Telp->setFormValue($objForm->GetValue("x_No_Telp"));
		}
		if (!$this->Hubungan->FldIsDetailKey) {
			$this->Hubungan->setFormValue($objForm->GetValue("x_Hubungan"));
		}
	}

	// Restore form values
	function RestoreFormValues() {
		global $objForm;
		$this->LoadOldRecord();
		$this->Nama->CurrentValue = $this->Nama->FormValue;
		$this->Alamat->CurrentValue = $this->Alamat->FormValue;
		$this->No_Ktp->CurrentValue = $this->No_Ktp->FormValue;
		$this->NPWP->CurrentValue = $this->NPWP->FormValue;
		$this->Telp->CurrentValue = $this->Telp->FormValue;
		$this->Kode->CurrentValue = $this->Kode->FormValue;
		$this->Area_Listing->CurrentValue = $this->Area_Listing->FormValue;
		$this->Alamat_Lengkap->CurrentValue = $this->Alamat_Lengkap->FormValue;
		$this->Nama_yang_bisa_dihubungi->CurrentValue = $this->Nama_yang_bisa_dihubungi->FormValue;
		$this->No_Telp->CurrentValue = $this->No_Telp->FormValue;
		$this->Hubungan->CurrentValue = $this->Hubungan->FormValue;
	}

	// Load row based on key values
	function LoadRow() {
		global $Security, $Language;
		$sFilter = $this->KeyFilter();

		// Call Row Selecting event
		$this->Row_Selecting($sFilter);

		// Load SQL based on filter
		$this->CurrentFilter = $sFilter;
		$sSql = $this->SQL();
		$conn = &$this->Connection();
		$res = FALSE;
		$rs = ew_LoadRecordset($sSql, $conn);
		if ($rs && !$rs->EOF) {
			$res = TRUE;
			$this->LoadRowValues($rs); // Load row values
			$rs->Close();
		}
		return $res;
	}

	// Load row values from recordset
	function LoadRowValues(&$rs) {
		if (!$rs || $rs->EOF) return;

		// Call Row Selected event
		$row = &$rs->fields;
		$this->Row_Selected($row);
		$this->No->setDbValue($rs->fields('No'));
		$this->Nama->setDbValue($rs->fields('Nama'));
		$this->Alamat->setDbValue($rs->fields('Alamat'));
		$this->No_Ktp->setDbValue($rs->fields('No_Ktp'));
		$this->NPWP->setDbValue($rs->fields('NPWP'));
		$this->Telp->setDbValue($rs->fields('Telp'));
		$this->Kode->setDbValue($rs->fields('Kode'));
		$this->Area_Listing->setDbValue($rs->fields('Area_Listing'));
		$this->Alamat_Lengkap->setDbValue($rs->fields('Alamat_Lengkap'));
		$this->Nama_yang_bisa_dihubungi->setDbValue($rs->fields('Nama_yang_bisa_dihubungi'));
		$this->No_Telp->setDbValue($rs->fields('No_Telp'));
		$this->Hubungan->setDbValue($rs->fields('Hubungan'));
	}

	// Load DbValue from recordset
	function LoadDbValues(&$rs) {
		if (!$rs || !is_array($rs) && $rs->EOF) return;
		$row = is_array($rs) ? $rs : $rs->fields;
		$this->No->DbValue = $row['No'];
		$this->Nama->DbValue = $row['Nama'];
		$this->Alamat->DbValue = $row['Alamat'];
		$this->No_Ktp->DbValue = $row['No_Ktp'];
		$this->NPWP->DbValue = $row['NPWP'];
		$this->Telp->DbValue = $row['Telp'];
		$this->Kode->DbValue = $row['Kode'];
		$this->Area_Listing->DbValue = $row['Area_Listing'];
		$this->Alamat_Lengkap->DbValue = $row['Alamat_Lengkap'];
		$this->Nama_yang_bisa_dihubungi->DbValue = $row['Nama_yang_bisa_dihubungi'];
		$this->No_Telp->DbValue = $row['No_Telp'];
		$this->Hubungan->DbValue = $row['Hubungan'];
	}

	// Load old record
	function LoadOldRecord() {

		// Load key values from Session
		$bValidKey = TRUE;
		if (strval($this->getKey("No")) <> "")
			$this->No->CurrentValue = $this->getKey("No"); // No
		else
			$bValidKey = FALSE;

		// Load old recordset
		if ($bValidKey) {
			$this->CurrentFilter = $this->KeyFilter();
			$sSql = $this->SQL();
			$conn = &$this->Connection();
			$this->OldRecordset = ew_LoadRecordset($sSql, $conn);
			$this->LoadRowValues($this->OldRecordset); // Load row values
		} else {
			$this->OldRecordset = NULL;
		}
		return $bValidKey;
	}

	// Render row values based on field settings
	function RenderRow() {
		global $Security, $Language, $gsLanguage;

		// Initialize URLs
		// Call Row_Rendering event

		$this->Row_Rendering();

		// Common render codes for all row types
		// No
		// Nama
		// Alamat
		// No_Ktp
		// NPWP
		// Telp
		// Kode
		// Area_Listing
		// Alamat_Lengkap
		// Nama_yang_bisa_dihubungi
		// No_Telp
		// Hubungan

		if ($this->RowType == EW_ROWTYPE_VIEW) { // View row

		// No
		$this->No->ViewValue = $this->No->CurrentValue;
		$this->No->ViewCustomAttributes = "";

		// Nama
		$this->Nama->ViewValue = $this->Nama->CurrentValue;
		$this->Nama->ViewCustomAttributes = "";

		// Alamat
		$this->Alamat->ViewValue = $this->Alamat->CurrentValue;
		$this->Alamat->ViewCustomAttributes = "";

		// No_Ktp
		$this->No_Ktp->ViewValue = $this->No_Ktp->CurrentValue;
		$this->No_Ktp->ViewCustomAttributes = "";

		// NPWP
		$this->NPWP->ViewValue = $this->NPWP->CurrentValue;
		$this->NPWP->ViewCustomAttributes = "";

		// Telp
		$this->Telp->ViewValue = $this->Telp->CurrentValue;
		$this->Telp->ViewCustomAttributes = "";

		// Kode
		$this->Kode->ViewValue = $this->Kode->CurrentValue;
		$this->Kode->ViewCustomAttributes = "";

		// Area_Listing
		$this->Area_Listing->ViewValue = $this->Area_Listing->CurrentValue;
		$this->Area_Listing->ViewCustomAttributes = "";

		// Alamat_Lengkap
		$this->Alamat_Lengkap->ViewValue = $this->Alamat_Lengkap->CurrentValue;
		$this->Alamat_Lengkap->ViewCustomAttributes = "";

		// Nama_yang_bisa_dihubungi
		$this->Nama_yang_bisa_dihubungi->ViewValue = $this->Nama_yang_bisa_dihubungi->CurrentValue;
		$this->Nama_yang_bisa_dihubungi->ViewCustomAttributes = "";

		// No_Telp
		$this->No_Telp->ViewValue = $this->No_Telp->CurrentValue;
		$this->No_Telp->ViewCustomAttributes = "";

		// Hubungan
		$this->Hubungan->ViewValue = $this->Hubungan->CurrentValue;
		$this->Hubungan->ViewCustomAttributes = "";

			// Nama
			$this->Nama->LinkCustomAttributes = "";
			$this->Nama->HrefValue = "";
			$this->Nama->TooltipValue = "";

			// Alamat
			$this->Alamat->LinkCustomAttributes = "";
			$this->Alamat->HrefValue = "";
			$this->Alamat->TooltipValue = "";

			// No_Ktp
			$this->No_Ktp->LinkCustomAttributes = "";
			$this->No_Ktp->HrefValue = "";
			$this->No_Ktp->TooltipValue = "";

			// NPWP
			$this->NPWP->LinkCustomAttributes = "";
			$this->NPWP->HrefValue = "";
			$this->NPWP->TooltipValue = "";

			// Telp
			$this->Telp->LinkCustomAttributes = "";
			$this->Telp->HrefValue = "";
			$this->Telp->TooltipValue = "";

			// Kode
			$this->Kode->LinkCustomAttributes = "";
			$this->Kode->HrefValue = "";
			$this->Kode->TooltipValue = "";

			// Area_Listing
			$this->Area_Listing->LinkCustomAttributes = "";
			$this->Area_Listing->HrefValue = "";
			$this->Area_Listing->TooltipValue = "";

			// Alamat_Lengkap
			$this->Alamat_Lengkap->LinkCustomAttributes = "";
			$this->Alamat_Lengkap->HrefValue = "";
			$this->Alamat_Lengkap->TooltipValue = "";

			// Nama_yang_bisa_dihubungi
			$this->Nama_yang_bisa_dihubungi->LinkCustomAttributes = "";
			$this->Nama_yang_bisa_dihubungi->HrefValue = "";
			$this->Nama_yang_bisa_dihubungi->TooltipValue = "";

			// No_Telp
			$this->No_Telp->LinkCustomAttributes = "";
			$this->No_Telp->HrefValue = "";
			$this->No_Telp->TooltipValue = "";

			// Hubungan
			$this->Hubungan->LinkCustomAttributes = "";
			$this->Hubungan->HrefValue = "";
			$this->Hubungan->TooltipValue = "";
		} elseif ($this->RowType == EW_ROWTYPE_ADD) { // Add row

			// Nama
			$this->Nama->EditAttrs["class"] = "form-control";
			$this->Nama->EditCustomAttributes = "";
			$this->Nama->EditValue = ew_HtmlEncode($this->Nama->CurrentValue);

			// Alamat
			$this->Alamat->EditAttrs["class"] = "form-control";
			$this->Alamat->EditCustomAttributes = "";
			$this->Alamat->EditValue = ew_HtmlEncode($this->Alamat->CurrentValue);

			// No_Ktp
			$this->No_Ktp->EditAttrs["class"] = "form-control";
			$this->No_Ktp->EditCustomAttributes = "";
			$this->No_Ktp->EditValue = ew_HtmlEncode($this->No_Ktp->CurrentValue);

			// NPWP
			$this->NPWP->EditAttrs["class"] = "form-control";
			$this->NPWP->EditCustomAttributes = "";
			$this->NPWP->EditValue = ew_HtmlEncode($this->NPWP->CurrentValue);

			// Telp
			$this->Telp->EditAttrs["class"] = "form-control";
			$this->Telp->EditCustomAttributes = "";
			$this->Telp->EditValue = ew_HtmlEncode($this->Telp->CurrentValue);

			// Kode
			$this->Kode->EditAttrs["class"] = "form-control";
			$this->Kode->EditCustomAttributes = "";
			$this->Kode->EditValue = ew_HtmlEncode($this->Kode->CurrentValue);

			// Area_Listing
			$this->Area_Listing->EditAttrs["class"] = "form-control";
			$this->Area_Listing->EditCustomAttributes = "";
			$this->Area_Listing->EditValue = ew_HtmlEncode($this->Area_Listing->CurrentValue);

			// Alamat_Lengkap
			$this->Alamat_Lengkap->EditAttrs["class"] = "form-control";
			$this->Alamat_Lengkap->EditCustomAttributes = "";
			$this->Alamat_Lengkap->EditValue = ew_HtmlEncode($this->Alamat_Lengkap->CurrentValue);

			// Nama_yang_bisa_dihubungi
			$this->Nama_yang_bisa_dihubungi->EditAttrs["class"] = "form-control";
			$this->Nama_yang_bisa_dihubungi->EditCustomAttributes = "";
			$this->Nama_yang_bisa_dihubungi->EditValue = ew_HtmlEncode($this->Nama_yang_bisa_dihubungi->CurrentValue);

			// No_Telp
			$this->No_Telp->EditAttrs["class"] = "form-control";
			$this->No_Telp->EditCustomAttributes = "";
			$this->No_Telp->EditValue = ew_HtmlEncode($this->No_Telp->CurrentValue);

			// Hubungan
			$this->Hubungan->EditAttrs["class"] = "form-control";
			$this->Hubungan->EditCustomAttributes = "";
			$this->Hubungan->EditValue = ew_HtmlEncode($this->Hubungan->CurrentValue);

			// Add refer script
			// Nama

			$this->Nama->LinkCustomAttributes = "";
			$this->Nama->HrefValue = "";

			// Alamat
			$this->Alamat->LinkCustomAttributes = "";
			$this->Alamat->HrefValue = "";

			// No_Ktp
			$this->No_Ktp->LinkCustomAttributes = "";
			$this->No_Ktp->HrefValue = "";

			// NPWP
			$this->NPWP->LinkCustomAttributes = "";
			$this->NPWP->HrefValue = "";

			// Telp
			$this->Telp->LinkCustomAttributes = "";
			$this->Telp->HrefValue = "";

			// Kode
			$this->Kode->LinkCustomAttributes = "";
			$this->Kode->HrefValue = "";

			// Area_Listing
			$this->Area_Listing->LinkCustomAttributes = "";
			$this->Area_Listing->HrefValue = "";

			// Alamat_Lengkap
			$this->Alamat_Lengkap->LinkCustomAttributes = "";
			$this->Alamat_Lengkap->HrefValue = "";

			// Nama_yang_bisa_dihubungi
			$this->Nama_yang_bisa_dihubungi->LinkCustomAttributes = "";
			$this->Nama_yang_bisa_dihubungi->HrefValue = "";

			// No_Telp
			$this->No_Telp->LinkCustomAttributes = "";
			$this->No_Telp->HrefValue = "";

			// Hubungan
			$this->Hubungan->LinkCustomAttributes = "";
			$this->Hubungan->HrefValue = "";
		}
		if ($this->RowType == EW_ROWTYPE_ADD ||
			$this->RowType == EW_ROWTYPE_EDIT ||
			$this->RowType == EW_ROWTYPE_SEARCH) { // Add / Edit / Search row
			$this->SetupFieldTitles();
		}

		// Call Row Rendered event
		if ($this->RowType <> EW_ROWTYPE_AGGREGATEINIT)
			$this->Row_Rendered();
	}

	// Validate form
	function ValidateForm() {
		global $Language, $gsFormError;

		// Initialize form error message
		$gsFormError = "";

		// Check if validation required
		if (!EW_SERVER_VALIDATE)
			return ($gsFormError == "");
		if (!$this->Nama->FldIsDetailKey && !is_null($this->Nama->FormValue) && $this->Nama->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->Nama->FldCaption(), $this->Nama->ReqErrMsg));
		}
		if (!$this->Alamat->FldIsDetailKey && !is_null($this->Alamat->FormValue) && $this->Alamat->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->Alamat->FldCaption(), $this->Alamat->ReqErrMsg));
		}
		if (!$this->No_Ktp->FldIsDetailKey && !is_null($this->No_Ktp->FormValue) && $this->No_Ktp->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->No_Ktp->FldCaption(), $this->No_Ktp->ReqErrMsg));
		}
		if (!$this->NPWP->FldIsDetailKey && !is_null($this->NPWP->FormValue) && $this->NPWP->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->NPWP->FldCaption(), $this->NPWP->ReqErrMsg));
		}
		if (!$this->Telp->FldIsDetailKey && !is_null($this->Telp->FormValue) && $this->Telp->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->Telp->FldCaption(), $this->Telp->ReqErrMsg));
		}
		if (!$this->Kode->FldIsDetailKey && !is_null($this->Kode->FormValue) && $this->Kode->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->Kode->FldCaption(), $this->Kode->ReqErrMsg));
		}
		if (!$this->Area_Listing->FldIsDetailKey && !is_null($this->Area_Listing->FormValue) && $this->Area_Listing->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->Area_Listing->FldCaption(), $this->Area_Listing->ReqErrMsg));
		}
		if (!$this->Alamat_Lengkap->FldIsDetailKey && !is_null($this->Alamat_Lengkap->FormValue) && $this->Alamat_Lengkap->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->Alamat_Lengkap->FldCaption(), $this->Alamat_Lengkap->ReqErrMsg));
		}
		if (!$this->Nama_yang_bisa_dihubungi->FldIsDetailKey && !is_null($this->Nama_yang_bisa_dihubungi->FormValue) && $this->Nama_yang_bisa_dihubungi->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->Nama_yang_bisa_dihubungi->FldCaption(), $this->Nama_yang_bisa_dihubungi->ReqErrMsg));
		}
		if (!$this->No_Telp->FldIsDetailKey && !is_null($this->No_Telp->FormValue) && $this->No_Telp->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->No_Telp->FldCaption(), $this->No_Telp->ReqErrMsg));
		}
		if (!$this->Hubungan->FldIsDetailKey && !is_null($this->Hubungan->FormValue) && $this->Hubungan->FormValue == "") {
			ew_AddMessage($gsFormError, str_replace("%s", $this->Hubungan->FldCaption(), $this->Hubungan->ReqErrMsg));
		}

		// Return validate result
		$ValidateForm = ($gsFormError == "");

		// Call Form_CustomValidate event
		$sFormCustomError = "";
		$ValidateForm = $ValidateForm && $this->Form_CustomValidate($sFormCustomError);
		if ($sFormCustomError <> "") {
			ew_AddMessage($gsFormError, $sFormCustomError);
		}
		return $ValidateForm;
	}

	// Add record
	function AddRow($rsold = NULL) {
		global $Language, $Security;
		if ($this->No_Ktp->CurrentValue <> "") { // Check field with unique index
			$sFilter = "(No_Ktp = '" . ew_AdjustSql($this->No_Ktp->CurrentValue, $this->DBID) . "')";
			$rsChk = $this->LoadRs($sFilter);
			if ($rsChk && !$rsChk->EOF) {
				$sIdxErrMsg = str_replace("%f", $this->No_Ktp->FldCaption(), $Language->Phrase("DupIndex"));
				$sIdxErrMsg = str_replace("%v", $this->No_Ktp->CurrentValue, $sIdxErrMsg);
				$this->setFailureMessage($sIdxErrMsg);
				$rsChk->Close();
				return FALSE;
			}
		}
		if ($this->NPWP->CurrentValue <> "") { // Check field with unique index
			$sFilter = "(NPWP = '" . ew_AdjustSql($this->NPWP->CurrentValue, $this->DBID) . "')";
			$rsChk = $this->LoadRs($sFilter);
			if ($rsChk && !$rsChk->EOF) {
				$sIdxErrMsg = str_replace("%f", $this->NPWP->FldCaption(), $Language->Phrase("DupIndex"));
				$sIdxErrMsg = str_replace("%v", $this->NPWP->CurrentValue, $sIdxErrMsg);
				$this->setFailureMessage($sIdxErrMsg);
				$rsChk->Close();
				return FALSE;
			}
		}
		if ($this->Telp->CurrentValue <> "") { // Check field with unique index
			$sFilter = "(Telp = '" . ew_AdjustSql($this->Telp->CurrentValue, $this->DBID) . "')";
			$rsChk = $this->LoadRs($sFilter);
			if ($rsChk && !$rsChk->EOF) {
				$sIdxErrMsg = str_replace("%f", $this->Telp->FldCaption(), $Language->Phrase("DupIndex"));
				$sIdxErrMsg = str_replace("%v", $this->Telp->CurrentValue, $sIdxErrMsg);
				$this->setFailureMessage($sIdxErrMsg);
				$rsChk->Close();
				return FALSE;
			}
		}
		$conn = &$this->Connection();

		// Load db values from rsold
		if ($rsold) {
			$this->LoadDbValues($rsold);
		}
		$rsnew = array();

		// Nama
		$this->Nama->SetDbValueDef($rsnew, $this->Nama->CurrentValue, "", FALSE);

		// Alamat
		$this->Alamat->SetDbValueDef($rsnew, $this->Alamat->CurrentValue, "", FALSE);

		// No_Ktp
		$this->No_Ktp->SetDbValueDef($rsnew, $this->No_Ktp->CurrentValue, "", FALSE);

		// NPWP
		$this->NPWP->SetDbValueDef($rsnew, $this->NPWP->CurrentValue, "", FALSE);

		// Telp
		$this->Telp->SetDbValueDef($rsnew, $this->Telp->CurrentValue, "", FALSE);

		// Kode
		$this->Kode->SetDbValueDef($rsnew, $this->Kode->CurrentValue, "", FALSE);

		// Area_Listing
		$this->Area_Listing->SetDbValueDef($rsnew, $this->Area_Listing->CurrentValue, "", FALSE);

		// Alamat_Lengkap
		$this->Alamat_Lengkap->SetDbValueDef($rsnew, $this->Alamat_Lengkap->CurrentValue, "", FALSE);

		// Nama_yang_bisa_dihubungi
		$this->Nama_yang_bisa_dihubungi->SetDbValueDef($rsnew, $this->Nama_yang_bisa_dihubungi->CurrentValue, "", FALSE);

		// No_Telp
		$this->No_Telp->SetDbValueDef($rsnew, $this->No_Telp->CurrentValue, "", FALSE);

		// Hubungan
		$this->Hubungan->SetDbValueDef($rsnew, $this->Hubungan->CurrentValue, "", FALSE);

		// Call Row Inserting event
		$rs = ($rsold == NULL) ? NULL : $rsold->fields;
		$bInsertRow = $this->Row_Inserting($rs, $rsnew);
		if ($bInsertRow) {
			$conn->raiseErrorFn = $GLOBALS["EW_ERROR_FN"];
			$AddRow = $this->Insert($rsnew);
			$conn->raiseErrorFn = '';
			if ($AddRow) {

				// Get insert id if necessary
				$this->No->setDbValue($conn->Insert_ID());
				$rsnew['No'] = $this->No->DbValue;
			}
		} else {
			if ($this->getSuccessMessage() <> "" || $this->getFailureMessage() <> "") {

				// Use the message, do nothing
			} elseif ($this->CancelMessage <> "") {
				$this->setFailureMessage($this->CancelMessage);
				$this->CancelMessage = "";
			} else {
				$this->setFailureMessage($Language->Phrase("InsertCancelled"));
			}
			$AddRow = FALSE;
		}
		if ($AddRow) {

			// Call Row Inserted event
			$rs = ($rsold == NULL) ? NULL : $rsold->fields;
			$this->Row_Inserted($rs, $rsnew);
		}
		return $AddRow;
	}

	// Set up Breadcrumb
	function SetupBreadcrumb() {
		global $Breadcrumb, $Language;
		$Breadcrumb = new cBreadcrumb();
		$url = substr(ew_CurrentUrl(), strrpos(ew_CurrentUrl(), "/")+1);
		$Breadcrumb->Add("list", $this->TableVar, $this->AddMasterUrl("data_marketinglist.php"), "", $this->TableVar, TRUE);
		$PageId = ($this->CurrentAction == "C") ? "Copy" : "Add";
		$Breadcrumb->Add("add", $PageId, $url);
	}

	// Setup lookup filters of a field
	function SetupLookupFilters($fld, $pageId = null) {
		global $gsLanguage;
		$pageId = $pageId ?: $this->PageID;
		switch ($fld->FldVar) {
		}
	}

	// Setup AutoSuggest filters of a field
	function SetupAutoSuggestFilters($fld, $pageId = null) {
		global $gsLanguage;
		$pageId = $pageId ?: $this->PageID;
		switch ($fld->FldVar) {
		}
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Page Redirecting event
	function Page_Redirecting(&$url) {

		// Example:
		//$url = "your URL";

	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$CustomError) {

		// Return error message in CustomError
		return TRUE;
	}
}
?>
<?php ew_Header(FALSE) ?>
<?php

// Create page object
if (!isset($data_marketing_add)) $data_marketing_add = new cdata_marketing_add();

// Page init
$data_marketing_add->Page_Init();

// Page main
$data_marketing_add->Page_Main();

// Global Page Rendering event (in userfn*.php)
Page_Rendering();

// Page Rendering event
$data_marketing_add->Page_Render();
?>
<?php include_once "header.php" ?>
<script type="text/javascript">

// Form object
var CurrentPageID = EW_PAGE_ID = "add";
var CurrentForm = fdata_marketingadd = new ew_Form("fdata_marketingadd", "add");

// Validate form
fdata_marketingadd.Validate = function() {
	if (!this.ValidateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.GetForm(), $fobj = $(fobj);
	if ($fobj.find("#a_confirm").val() == "F")
		return true;
	var elm, felm, uelm, addcnt = 0;
	var $k = $fobj.find("#" + this.FormKeyCountName); // Get key_count
	var rowcnt = ($k[0]) ? parseInt($k.val(), 10) : 1;
	var startcnt = (rowcnt == 0) ? 0 : 1; // Check rowcnt == 0 => Inline-Add
	var gridinsert = $fobj.find("#a_list").val() == "gridinsert";
	for (var i = startcnt; i <= rowcnt; i++) {
		var infix = ($k[0]) ? String(i) : "";
		$fobj.data("rowindex", infix);
			elm = this.GetElements("x" + infix + "_Nama");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Nama->FldCaption(), $data_marketing->Nama->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Alamat");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Alamat->FldCaption(), $data_marketing->Alamat->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_No_Ktp");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->No_Ktp->FldCaption(), $data_marketing->No_Ktp->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_NPWP");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->NPWP->FldCaption(), $data_marketing->NPWP->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Telp");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Telp->FldCaption(), $data_marketing->Telp->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Kode");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Kode->FldCaption(), $data_marketing->Kode->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Area_Listing");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Area_Listing->FldCaption(), $data_marketing->Area_Listing->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Alamat_Lengkap");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Alamat_Lengkap->FldCaption(), $data_marketing->Alamat_Lengkap->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Nama_yang_bisa_dihubungi");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Nama_yang_bisa_dihubungi->FldCaption(), $data_marketing->Nama_yang_bisa_dihubungi->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_No_Telp");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->No_Telp->FldCaption(), $data_marketing->No_Telp->ReqErrMsg)) ?>");
			elm = this.GetElements("x" + infix + "_Hubungan");
			if (elm && !ew_IsHidden(elm) && !ew_HasValue(elm))
				return this.OnError(elm, "<?php echo ew_JsEncode2(str_replace("%s", $data_marketing->Hubungan->FldCaption(), $data_marketing->Hubungan->ReqErrMsg)) ?>");

			// Fire Form_CustomValidate event
			if (!this.Form_CustomValidate(fobj))
				return false;
	}

	// Process detail forms
	var dfs = $fobj.find("input[name='detailpage']").get();
	for (var i = 0; i < dfs.length; i++) {
		var df = dfs[i], val = df.value;
		if (val && ewForms[val])
			if (!ewForms[val].Validate())
				return false;
	}
	return true;
}

// Form_CustomValidate event
fdata_marketingadd.Form_CustomValidate = 
 function(fobj) { // DO NOT CHANGE THIS LINE!

 	// Your custom validation code here, return false if invalid. 
 	return true;
 }

// Use JavaScript validation or not
<?php if (EW_CLIENT_VALIDATE) { ?>
fdata_marketingadd.ValidateRequired = true;
<?php } else { ?>
fdata_marketingadd.ValidateRequired = false; 
<?php } ?>

// Dynamic selection lists
// Form object for search

</script>
<script type="text/javascript">

// Write your client script here, no need to add script tags.
</script>
<?php if (!$data_marketing_add->IsModal) { ?>
<div class="ewToolbar">
<?php $Breadcrumb->Render(); ?>
<?php echo $Language->SelectionForm(); ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php $data_marketing_add->ShowPageHeader(); ?>
<?php
$data_marketing_add->ShowMessage();
?>
<form name="fdata_marketingadd" id="fdata_marketingadd" class="<?php echo $data_marketing_add->FormClassName ?>" action="<?php echo ew_CurrentPage() ?>" method="post">
<?php if ($data_marketing_add->CheckToken) { ?>
<input type="hidden" name="<?php echo EW_TOKEN_NAME ?>" value="<?php echo $data_marketing_add->Token ?>">
<?php } ?>
<input type="hidden" name="t" value="data_marketing">
<input type="hidden" name="a_add" id="a_add" value="A">
<?php if ($data_marketing_add->IsModal) { ?>
<input type="hidden" name="modal" value="1">
<?php } ?>
<?php if (!ew_IsMobile() && !$data_marketing_add->IsModal) { ?>
<div class="ewDesktop">
<?php } ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
<div>
<?php } else { ?>
<div>
<table id="tbl_data_marketingadd" class="table table-bordered table-striped ewDesktopTable">
<?php } ?>
<?php if ($data_marketing->Nama->Visible) { // Nama ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_Nama" class="form-group">
		<label id="elh_data_marketing_Nama" for="x_Nama" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->Nama->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->Nama->CellAttributes() ?>>
<span id="el_data_marketing_Nama">
<input type="text" data-table="data_marketing" data-field="x_Nama" name="x_Nama" id="x_Nama" size="60" maxlength="100" value="<?php echo $data_marketing->Nama->EditValue ?>"<?php echo $data_marketing->Nama->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Nama->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_Nama">
		<td><span id="elh_data_marketing_Nama"><?php echo $data_marketing->Nama->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->Nama->CellAttributes() ?>>
<span id="el_data_marketing_Nama">
<input type="text" data-table="data_marketing" data-field="x_Nama" name="x_Nama" id="x_Nama" size="60" maxlength="100" value="<?php echo $data_marketing->Nama->EditValue ?>"<?php echo $data_marketing->Nama->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Nama->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->Alamat->Visible) { // Alamat ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_Alamat" class="form-group">
		<label id="elh_data_marketing_Alamat" for="x_Alamat" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->Alamat->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->Alamat->CellAttributes() ?>>
<span id="el_data_marketing_Alamat">
<textarea data-table="data_marketing" data-field="x_Alamat" name="x_Alamat" id="x_Alamat" cols="35" rows="4"<?php echo $data_marketing->Alamat->EditAttributes() ?>><?php echo $data_marketing->Alamat->EditValue ?></textarea>
</span>
<?php echo $data_marketing->Alamat->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_Alamat">
		<td><span id="elh_data_marketing_Alamat"><?php echo $data_marketing->Alamat->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->Alamat->CellAttributes() ?>>
<span id="el_data_marketing_Alamat">
<textarea data-table="data_marketing" data-field="x_Alamat" name="x_Alamat" id="x_Alamat" cols="35" rows="4"<?php echo $data_marketing->Alamat->EditAttributes() ?>><?php echo $data_marketing->Alamat->EditValue ?></textarea>
</span>
<?php echo $data_marketing->Alamat->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->No_Ktp->Visible) { // No_Ktp ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_No_Ktp" class="form-group">
		<label id="elh_data_marketing_No_Ktp" for="x_No_Ktp" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->No_Ktp->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->No_Ktp->CellAttributes() ?>>
<span id="el_data_marketing_No_Ktp">
<input type="text" data-table="data_marketing" data-field="x_No_Ktp" name="x_No_Ktp" id="x_No_Ktp" size="30" maxlength="50" value="<?php echo $data_marketing->No_Ktp->EditValue ?>"<?php echo $data_marketing->No_Ktp->EditAttributes() ?>>
</span>
<?php echo $data_marketing->No_Ktp->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_No_Ktp">
		<td><span id="elh_data_marketing_No_Ktp"><?php echo $data_marketing->No_Ktp->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->No_Ktp->CellAttributes() ?>>
<span id="el_data_marketing_No_Ktp">
<input type="text" data-table="data_marketing" data-field="x_No_Ktp" name="x_No_Ktp" id="x_No_Ktp" size="30" maxlength="50" value="<?php echo $data_marketing->No_Ktp->EditValue ?>"<?php echo $data_marketing->No_Ktp->EditAttributes() ?>>
</span>
<?php echo $data_marketing->No_Ktp->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->NPWP->Visible) { // NPWP ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_NPWP" class="form-group">
		<label id="elh_data_marketing_NPWP" for="x_NPWP" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->NPWP->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->NPWP->CellAttributes() ?>>
<span id="el_data_marketing_NPWP">
<input type="text" data-table="data_marketing" data-field="x_NPWP" name="x_NPWP" id="x_NPWP" size="30" maxlength="50" value="<?php echo $data_marketing->NPWP->EditValue ?>"<?php echo $data_marketing->NPWP->EditAttributes() ?>>
</span>
<?php echo $data_marketing->NPWP->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_NPWP">
		<td><span id="elh_data_marketing_NPWP"><?php echo $data_marketing->NPWP->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->NPWP->CellAttributes() ?>>
<span id="el_data_marketing_NPWP">
<input type="text" data-table="data_marketing" data-field="x_NPWP" name="x_NPWP" id="x_NPWP" size="30" maxlength="50" value="<?php echo $data_marketing->NPWP->EditValue ?>"<?php echo $data_marketing->NPWP->EditAttributes() ?>>
</span>
<?php echo $data_marketing->NPWP->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->Telp->Visible) { // Telp ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_Telp" class="form-group">
		<label id="elh_data_marketing_Telp" for="x_Telp" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->Telp->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->Telp->CellAttributes() ?>>
<span id="el_data_marketing_Telp">
<input type="text" data-table="data_marketing" data-field="x_Telp" name="x_Telp" id="x_Telp" size="30" maxlength="30" value="<?php echo $data_marketing->Telp->EditValue ?>"<?php echo $data_marketing->Telp->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Telp->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_Telp">
		<td><span id="elh_data_marketing_Telp"><?php echo $data_marketing->Telp->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->Telp->CellAttributes() ?>>
<span id="el_data_marketing_Telp">
<input type="text" data-table="data_marketing" data-field="x_Telp" name="x_Telp" id="x_Telp" size="30" maxlength="30" value="<?php echo $data_marketing->Telp->EditValue ?>"<?php echo $data_marketing->Telp->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Telp->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->Kode->Visible) { // Kode ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_Kode" class="form-group">
		<label id="elh_data_marketing_Kode" for="x_Kode" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->Kode->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->Kode->CellAttributes() ?>>
<span id="el_data_marketing_Kode">
<input type="text" data-table="data_marketing" data-field="x_Kode" name="x_Kode" id="x_Kode" size="20" maxlength="30" value="<?php echo $data_marketing->Kode->EditValue ?>"<?php echo $data_marketing->Kode->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Kode->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_Kode">
		<td><span id="elh_data_marketing_Kode"><?php echo $data_marketing->Kode->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->Kode->CellAttributes() ?>>
<span id="el_data_marketing_Kode">
<input type="text" data-table="data_marketing" data-field="x_Kode" name="x_Kode" id="x_Kode" size="20" maxlength="30" value="<?php echo $data_marketing->Kode->EditValue ?>"<?php echo $data_marketing->Kode->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Kode->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->Area_Listing->Visible) { // Area_Listing ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_Area_Listing" class="form-group">
		<label id="elh_data_marketing_Area_Listing" for="x_Area_Listing" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->Area_Listing->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->Area_Listing->CellAttributes() ?>>
<span id="el_data_marketing_Area_Listing">
<input type="text" data-table="data_marketing" data-field="x_Area_Listing" name="x_Area_Listing" id="x_Area_Listing" size="60" maxlength="100" value="<?php echo $data_marketing->Area_Listing->EditValue ?>"<?php echo $data_marketing->Area_Listing->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Area_Listing->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_Area_Listing">
		<td><span id="elh_data_marketing_Area_Listing"><?php echo $data_marketing->Area_Listing->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->Area_Listing->CellAttributes() ?>>
<span id="el_data_marketing_Area_Listing">
<input type="text" data-table="data_marketing" data-field="x_Area_Listing" name="x_Area_Listing" id="x_Area_Listing" size="60" maxlength="100" value="<?php echo $data_marketing->Area_Listing->EditValue ?>"<?php echo $data_marketing->Area_Listing->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Area_Listing->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->Alamat_Lengkap->Visible) { // Alamat_Lengkap ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_Alamat_Lengkap" class="form-group">
		<label id="elh_data_marketing_Alamat_Lengkap" for="x_Alamat_Lengkap" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->Alamat_Lengkap->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->Alamat_Lengkap->CellAttributes() ?>>
<span id="el_data_marketing_Alamat_Lengkap">
<input type="text" data-table="data_marketing" data-field="x_Alamat_Lengkap" name="x_Alamat_Lengkap" id="x_Alamat_Lengkap" size="30" maxlength="100" value="<?php echo $data_marketing->Alamat_Lengkap->EditValue ?>"<?php echo $data_marketing->Alamat_Lengkap->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Alamat_Lengkap->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_Alamat_Lengkap">
		<td><span id="elh_data_marketing_Alamat_Lengkap"><?php echo $data_marketing->Alamat_Lengkap->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->Alamat_Lengkap->CellAttributes() ?>>
<span id="el_data_marketing_Alamat_Lengkap">
<input type="text" data-table="data_marketing" data-field="x_Alamat_Lengkap" name="x_Alamat_Lengkap" id="x_Alamat_Lengkap" size="30" maxlength="100" value="<?php echo $data_marketing->Alamat_Lengkap->EditValue ?>"<?php echo $data_marketing->Alamat_Lengkap->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Alamat_Lengkap->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->Nama_yang_bisa_dihubungi->Visible) { // Nama_yang_bisa_dihubungi ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_Nama_yang_bisa_dihubungi" class="form-group">
		<label id="elh_data_marketing_Nama_yang_bisa_dihubungi" for="x_Nama_yang_bisa_dihubungi" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->Nama_yang_bisa_dihubungi->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->Nama_yang_bisa_dihubungi->CellAttributes() ?>>
<span id="el_data_marketing_Nama_yang_bisa_dihubungi">
<input type="text" data-table="data_marketing" data-field="x_Nama_yang_bisa_dihubungi" name="x_Nama_yang_bisa_dihubungi" id="x_Nama_yang_bisa_dihubungi" size="30" maxlength="50" value="<?php echo $data_marketing->Nama_yang_bisa_dihubungi->EditValue ?>"<?php echo $data_marketing->Nama_yang_bisa_dihubungi->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Nama_yang_bisa_dihubungi->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_Nama_yang_bisa_dihubungi">
		<td><span id="elh_data_marketing_Nama_yang_bisa_dihubungi"><?php echo $data_marketing->Nama_yang_bisa_dihubungi->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->Nama_yang_bisa_dihubungi->CellAttributes() ?>>
<span id="el_data_marketing_Nama_yang_bisa_dihubungi">
<input type="text" data-table="data_marketing" data-field="x_Nama_yang_bisa_dihubungi" name="x_Nama_yang_bisa_dihubungi" id="x_Nama_yang_bisa_dihubungi" size="30" maxlength="50" value="<?php echo $data_marketing->Nama_yang_bisa_dihubungi->EditValue ?>"<?php echo $data_marketing->Nama_yang_bisa_dihubungi->EditAttributes() ?>>
</span>
<?php echo $data_marketing->Nama_yang_bisa_dihubungi->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->No_Telp->Visible) { // No_Telp ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_No_Telp" class="form-group">
		<label id="elh_data_marketing_No_Telp" for="x_No_Telp" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->No_Telp->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->No_Telp->CellAttributes() ?>>
<span id="el_data_marketing_No_Telp">
<input type="text" data-table="data_marketing" data-field="x_No_Telp" name="x_No_Telp" id="x_No_Telp" size="30" maxlength="20" value="<?php echo $data_marketing->No_Telp->EditValue ?>"<?php echo $data_marketing->No_Telp->EditAttributes() ?>>
</span>
<?php echo $data_marketing->No_Telp->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_No_Telp">
		<td><span id="elh_data_marketing_No_Telp"><?php echo $data_marketing->No_Telp->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->No_Telp->CellAttributes() ?>>
<span id="el_data_marketing_No_Telp">
<input type="text" data-table="data_marketing" data-field="x_No_Telp" name="x_No_Telp" id="x_No_Telp" size="30" maxlength="20" value="<?php echo $data_marketing->No_Telp->EditValue ?>"<?php echo $data_marketing->No_Telp->EditAttributes() ?>>
</span>
<?php echo $data_marketing->No_Telp->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if ($data_marketing->Hubungan->Visible) { // Hubungan ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
	<div id="r_Hubungan" class="form-group">
		<label id="elh_data_marketing_Hubungan" for="x_Hubungan" class="col-sm-2 control-label ewLabel"><?php echo $data_marketing->Hubungan->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></label>
		<div class="col-sm-10"><div<?php echo $data_marketing->Hubungan->CellAttributes() ?>>
<span id="el_data_marketing_Hubungan">
<textarea data-table="data_marketing" data-field="x_Hubungan" name="x_Hubungan" id="x_Hubungan" cols="35" rows="4"<?php echo $data_marketing->Hubungan->EditAttributes() ?>><?php echo $data_marketing->Hubungan->EditValue ?></textarea>
</span>
<?php echo $data_marketing->Hubungan->CustomMsg ?></div></div>
	</div>
<?php } else { ?>
	<tr id="r_Hubungan">
		<td><span id="elh_data_marketing_Hubungan"><?php echo $data_marketing->Hubungan->FldCaption() ?><?php echo $Language->Phrase("FieldRequiredIndicator") ?></span></td>
		<td<?php echo $data_marketing->Hubungan->CellAttributes() ?>>
<span id="el_data_marketing_Hubungan">
<textarea data-table="data_marketing" data-field="x_Hubungan" name="x_Hubungan" id="x_Hubungan" cols="35" rows="4"<?php echo $data_marketing->Hubungan->EditAttributes() ?>><?php echo $data_marketing->Hubungan->EditValue ?></textarea>
</span>
<?php echo $data_marketing->Hubungan->CustomMsg ?></td>
	</tr>
<?php } ?>
<?php } ?>
<?php if (ew_IsMobile() || $data_marketing_add->IsModal) { ?>
</div>
<?php } else { ?>
</table>
</div>
<?php } ?>
<?php if (!$data_marketing_add->IsModal) { ?>
<div class="ewDesktopButton">
<button class="btn btn-primary ewButton" name="btnAction" id="btnAction" type="submit"><?php echo $Language->Phrase("AddBtn") ?></button>
<button class="btn btn-default ewButton" name="btnCancel" id="btnCancel" type="button" data-href="<?php echo $data_marketing_add->getReturnUrl() ?>"><?php echo $Language->Phrase("CancelBtn") ?></button>
</div>
</div>
<?php } ?>
</form>
<script type="text/javascript">
fdata_marketingadd.Init();
</script>
<?php
$data_marketing_add->ShowPageFooter();
if (EW_DEBUG_ENABLED)
	echo ew_DebugMsg();
?>
<script type="text/javascript">

// Write your table-specific startup script here
// document.write("page loaded");

</script>
<?php include_once "footer.php" ?>
<?php
$data_marketing_add->Page_Terminate();
?>
