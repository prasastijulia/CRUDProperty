<?php

// Global variable for table object
$daily_report = NULL;

//
// Table class for daily_report
//
class cdaily_report extends cTable {
	var $Id;
	var $No;
	var $Tanggal;
	var $Aktifitas_Hari_Ini;
	var $Jam_Mulai;
	var $Jam_Akhir;
	var $Listing_Hari_Ini;
	var $Jenis_Property;
	var $Data_Pemilik_Property;

	//
	// Table class constructor
	//
	function __construct() {
		global $Language;

		// Language object
		if (!isset($Language)) $Language = new cLanguage();
		$this->TableVar = 'daily_report';
		$this->TableName = 'daily_report';
		$this->TableType = 'TABLE';

		// Update Table
		$this->UpdateTable = "`daily_report`";
		$this->DBID = 'DB';
		$this->ExportAll = TRUE;
		$this->ExportPageBreakCount = 0; // Page break per every n record (PDF only)
		$this->ExportPageOrientation = "portrait"; // Page orientation (PDF only)
		$this->ExportPageSize = "a4"; // Page size (PDF only)
		$this->ExportExcelPageOrientation = ""; // Page orientation (PHPExcel only)
		$this->ExportExcelPageSize = ""; // Page size (PHPExcel only)
		$this->DetailAdd = FALSE; // Allow detail add
		$this->DetailEdit = FALSE; // Allow detail edit
		$this->DetailView = FALSE; // Allow detail view
		$this->ShowMultipleDetails = FALSE; // Show multiple details
		$this->GridAddRowCount = 5;
		$this->AllowAddDeleteRow = ew_AllowAddDeleteRow(); // Allow add/delete row
		$this->UserIDAllowSecurity = 0; // User ID Allow
		$this->BasicSearch = new cBasicSearch($this->TableVar);

		// Id
		$this->Id = new cField('daily_report', 'daily_report', 'x_Id', 'Id', '`Id`', '`Id`', 3, -1, FALSE, '`Id`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->Id->Sortable = TRUE; // Allow sort
		$this->Id->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['Id'] = &$this->Id;

		// No
		$this->No = new cField('daily_report', 'daily_report', 'x_No', 'No', '`No`', '`No`', 3, -1, FALSE, '`No`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'NO');
		$this->No->Sortable = TRUE; // Allow sort
		$this->No->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['No'] = &$this->No;

		// Tanggal
		$this->Tanggal = new cField('daily_report', 'daily_report', 'x_Tanggal', 'Tanggal', '`Tanggal`', 'DATE_FORMAT(`Tanggal`, \'%Y/%m/%d\')', 133, 2, FALSE, '`Tanggal`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->Tanggal->Sortable = TRUE; // Allow sort
		$this->Tanggal->FldDefaultErrMsg = str_replace("%s", $GLOBALS["EW_DATE_FORMAT"], $Language->Phrase("IncorrectDate"));
		$this->fields['Tanggal'] = &$this->Tanggal;

		// Aktifitas_Hari_Ini
		$this->Aktifitas_Hari_Ini = new cField('daily_report', 'daily_report', 'x_Aktifitas_Hari_Ini', 'Aktifitas_Hari_Ini', '`Aktifitas_Hari_Ini`', '`Aktifitas_Hari_Ini`', 200, -1, FALSE, '`Aktifitas_Hari_Ini`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->Aktifitas_Hari_Ini->Sortable = TRUE; // Allow sort
		$this->fields['Aktifitas_Hari_Ini'] = &$this->Aktifitas_Hari_Ini;

		// Jam_Mulai
		$this->Jam_Mulai = new cField('daily_report', 'daily_report', 'x_Jam_Mulai', 'Jam_Mulai', '`Jam_Mulai`', '`Jam_Mulai`', 200, -1, FALSE, '`Jam_Mulai`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->Jam_Mulai->Sortable = TRUE; // Allow sort
		$this->fields['Jam_Mulai'] = &$this->Jam_Mulai;

		// Jam_Akhir
		$this->Jam_Akhir = new cField('daily_report', 'daily_report', 'x_Jam_Akhir', 'Jam_Akhir', '`Jam_Akhir`', '`Jam_Akhir`', 200, -1, FALSE, '`Jam_Akhir`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->Jam_Akhir->Sortable = TRUE; // Allow sort
		$this->fields['Jam_Akhir'] = &$this->Jam_Akhir;

		// Listing_Hari_Ini
		$this->Listing_Hari_Ini = new cField('daily_report', 'daily_report', 'x_Listing_Hari_Ini', 'Listing_Hari_Ini', '`Listing_Hari_Ini`', '`Listing_Hari_Ini`', 200, -1, FALSE, '`Listing_Hari_Ini`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXTAREA');
		$this->Listing_Hari_Ini->Sortable = TRUE; // Allow sort
		$this->fields['Listing_Hari_Ini'] = &$this->Listing_Hari_Ini;

		// Jenis_Property
		$this->Jenis_Property = new cField('daily_report', 'daily_report', 'x_Jenis_Property', 'Jenis_Property', '`Jenis_Property`', '`Jenis_Property`', 200, -1, FALSE, '`Jenis_Property`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'TEXT');
		$this->Jenis_Property->Sortable = TRUE; // Allow sort
		$this->fields['Jenis_Property'] = &$this->Jenis_Property;

		// Data_Pemilik_Property
		$this->Data_Pemilik_Property = new cField('daily_report', 'daily_report', 'x_Data_Pemilik_Property', 'Data_Pemilik_Property', '`Data_Pemilik_Property`', '`Data_Pemilik_Property`', 3, -1, FALSE, '`Data_Pemilik_Property`', FALSE, FALSE, FALSE, 'FORMATTED TEXT', 'SELECT');
		$this->Data_Pemilik_Property->Sortable = TRUE; // Allow sort
		$this->Data_Pemilik_Property->UsePleaseSelect = TRUE; // Use PleaseSelect by default
		$this->Data_Pemilik_Property->PleaseSelectText = $Language->Phrase("PleaseSelect"); // PleaseSelect text
		$this->Data_Pemilik_Property->FldDefaultErrMsg = $Language->Phrase("IncorrectInteger");
		$this->fields['Data_Pemilik_Property'] = &$this->Data_Pemilik_Property;
	}

	// Set Field Visibility
	function SetFieldVisibility($fldparm) {
		global $Security;
		return $this->$fldparm->Visible; // Returns original value
	}

	// Table level SQL
	var $_SqlFrom = "";

	function getSqlFrom() { // From
		return ($this->_SqlFrom <> "") ? $this->_SqlFrom : "`daily_report`";
	}

	function SqlFrom() { // For backward compatibility
		return $this->getSqlFrom();
	}

	function setSqlFrom($v) {
		$this->_SqlFrom = $v;
	}
	var $_SqlSelect = "";

	function getSqlSelect() { // Select
		return ($this->_SqlSelect <> "") ? $this->_SqlSelect : "SELECT * FROM " . $this->getSqlFrom();
	}

	function SqlSelect() { // For backward compatibility
		return $this->getSqlSelect();
	}

	function setSqlSelect($v) {
		$this->_SqlSelect = $v;
	}
	var $_SqlWhere = "";

	function getSqlWhere() { // Where
		$sWhere = ($this->_SqlWhere <> "") ? $this->_SqlWhere : "";
		$this->TableFilter = "";
		ew_AddFilter($sWhere, $this->TableFilter);
		return $sWhere;
	}

	function SqlWhere() { // For backward compatibility
		return $this->getSqlWhere();
	}

	function setSqlWhere($v) {
		$this->_SqlWhere = $v;
	}
	var $_SqlGroupBy = "";

	function getSqlGroupBy() { // Group By
		return ($this->_SqlGroupBy <> "") ? $this->_SqlGroupBy : "";
	}

	function SqlGroupBy() { // For backward compatibility
		return $this->getSqlGroupBy();
	}

	function setSqlGroupBy($v) {
		$this->_SqlGroupBy = $v;
	}
	var $_SqlHaving = "";

	function getSqlHaving() { // Having
		return ($this->_SqlHaving <> "") ? $this->_SqlHaving : "";
	}

	function SqlHaving() { // For backward compatibility
		return $this->getSqlHaving();
	}

	function setSqlHaving($v) {
		$this->_SqlHaving = $v;
	}
	var $_SqlOrderBy = "";

	function getSqlOrderBy() { // Order By
		return ($this->_SqlOrderBy <> "") ? $this->_SqlOrderBy : "";
	}

	function SqlOrderBy() { // For backward compatibility
		return $this->getSqlOrderBy();
	}

	function setSqlOrderBy($v) {
		$this->_SqlOrderBy = $v;
	}

	// Apply User ID filters
	function ApplyUserIDFilters($sFilter) {
		return $sFilter;
	}

	// Check if User ID security allows view all
	function UserIDAllow($id = "") {
		$allow = EW_USER_ID_ALLOW;
		switch ($id) {
			case "add":
			case "copy":
			case "gridadd":
			case "register":
			case "addopt":
				return (($allow & 1) == 1);
			case "edit":
			case "gridedit":
			case "update":
			case "changepwd":
			case "forgotpwd":
				return (($allow & 4) == 4);
			case "delete":
				return (($allow & 2) == 2);
			case "view":
				return (($allow & 32) == 32);
			case "search":
				return (($allow & 64) == 64);
			default:
				return (($allow & 8) == 8);
		}
	}

	// Get SQL
	function GetSQL($where, $orderby) {
		return ew_BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$where, $orderby);
	}

	// Table SQL
	function SQL() {
		$sFilter = $this->CurrentFilter;
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(),
			$this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(),
			$sFilter, $sSort);
	}

	// Table SQL with List page filter
	function SelectSQL() {
		$sFilter = $this->getSessionWhere();
		ew_AddFilter($sFilter, $this->CurrentFilter);
		$sFilter = $this->ApplyUserIDFilters($sFilter);
		$this->Recordset_Selecting($sFilter);
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql($this->getSqlSelect(), $this->getSqlWhere(), $this->getSqlGroupBy(),
			$this->getSqlHaving(), $this->getSqlOrderBy(), $sFilter, $sSort);
	}

	// Get ORDER BY clause
	function GetOrderBy() {
		$sSort = $this->getSessionOrderBy();
		return ew_BuildSelectSql("", "", "", "", $this->getSqlOrderBy(), "", $sSort);
	}

	// Try to get record count
	function TryGetRecordCount($sSql) {
		$cnt = -1;
		if (($this->TableType == 'TABLE' || $this->TableType == 'VIEW' || $this->TableType == 'LINKTABLE') && preg_match("/^SELECT \* FROM/i", $sSql)) {
			$sSql = "SELECT COUNT(*) FROM" . preg_replace('/^SELECT\s([\s\S]+)?\*\sFROM/i', "", $sSql);
			$sOrderBy = $this->GetOrderBy();
			if (substr($sSql, strlen($sOrderBy) * -1) == $sOrderBy)
				$sSql = substr($sSql, 0, strlen($sSql) - strlen($sOrderBy)); // Remove ORDER BY clause
		} else {
			$sSql = "SELECT COUNT(*) FROM (" . $sSql . ") EW_COUNT_TABLE";
		}
		$conn = &$this->Connection();
		if ($rs = $conn->Execute($sSql)) {
			if (!$rs->EOF && $rs->FieldCount() > 0) {
				$cnt = $rs->fields[0];
				$rs->Close();
			}
		}
		return intval($cnt);
	}

	// Get record count based on filter (for detail record count in master table pages)
	function LoadRecordCount($sFilter) {
		$origFilter = $this->CurrentFilter;
		$this->CurrentFilter = $sFilter;
		$this->Recordset_Selecting($this->CurrentFilter);

		//$sSql = $this->SQL();
		$sSql = $this->GetSQL($this->CurrentFilter, "");
		$cnt = $this->TryGetRecordCount($sSql);
		if ($cnt == -1) {
			if ($rs = $this->LoadRs($this->CurrentFilter)) {
				$cnt = $rs->RecordCount();
				$rs->Close();
			}
		}
		$this->CurrentFilter = $origFilter;
		return intval($cnt);
	}

	// Get record count (for current List page)
	function SelectRecordCount() {
		$sSql = $this->SelectSQL();
		$cnt = $this->TryGetRecordCount($sSql);
		if ($cnt == -1) {
			$conn = &$this->Connection();
			if ($rs = $conn->Execute($sSql)) {
				$cnt = $rs->RecordCount();
				$rs->Close();
			}
		}
		return intval($cnt);
	}

	// INSERT statement
	function InsertSQL(&$rs) {
		$names = "";
		$values = "";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->FldIsCustom)
				continue;
			$names .= $this->fields[$name]->FldExpression . ",";
			$values .= ew_QuotedValue($value, $this->fields[$name]->FldDataType, $this->DBID) . ",";
		}
		while (substr($names, -1) == ",")
			$names = substr($names, 0, -1);
		while (substr($values, -1) == ",")
			$values = substr($values, 0, -1);
		return "INSERT INTO " . $this->UpdateTable . " ($names) VALUES ($values)";
	}

	// Insert
	function Insert(&$rs) {
		$conn = &$this->Connection();
		return $conn->Execute($this->InsertSQL($rs));
	}

	// UPDATE statement
	function UpdateSQL(&$rs, $where = "", $curfilter = TRUE) {
		$sql = "UPDATE " . $this->UpdateTable . " SET ";
		foreach ($rs as $name => $value) {
			if (!isset($this->fields[$name]) || $this->fields[$name]->FldIsCustom)
				continue;
			$sql .= $this->fields[$name]->FldExpression . "=";
			$sql .= ew_QuotedValue($value, $this->fields[$name]->FldDataType, $this->DBID) . ",";
		}
		while (substr($sql, -1) == ",")
			$sql = substr($sql, 0, -1);
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		if (is_array($where))
			$where = $this->ArrayToFilter($where);
		ew_AddFilter($filter, $where);
		if ($filter <> "")	$sql .= " WHERE " . $filter;
		return $sql;
	}

	// Update
	function Update(&$rs, $where = "", $rsold = NULL, $curfilter = TRUE) {
		$conn = &$this->Connection();
		return $conn->Execute($this->UpdateSQL($rs, $where, $curfilter));
	}

	// DELETE statement
	function DeleteSQL(&$rs, $where = "", $curfilter = TRUE) {
		$sql = "DELETE FROM " . $this->UpdateTable . " WHERE ";
		if (is_array($where))
			$where = $this->ArrayToFilter($where);
		if ($rs) {
			if (array_key_exists('Id', $rs))
				ew_AddFilter($where, ew_QuotedName('Id', $this->DBID) . '=' . ew_QuotedValue($rs['Id'], $this->Id->FldDataType, $this->DBID));
		}
		$filter = ($curfilter) ? $this->CurrentFilter : "";
		ew_AddFilter($filter, $where);
		if ($filter <> "")
			$sql .= $filter;
		else
			$sql .= "0=1"; // Avoid delete
		return $sql;
	}

	// Delete
	function Delete(&$rs, $where = "", $curfilter = TRUE) {
		$conn = &$this->Connection();
		return $conn->Execute($this->DeleteSQL($rs, $where, $curfilter));
	}

	// Key filter WHERE clause
	function SqlKeyFilter() {
		return "`Id` = @Id@";
	}

	// Key filter
	function KeyFilter() {
		$sKeyFilter = $this->SqlKeyFilter();
		if (!is_numeric($this->Id->CurrentValue))
			$sKeyFilter = "0=1"; // Invalid key
		$sKeyFilter = str_replace("@Id@", ew_AdjustSql($this->Id->CurrentValue, $this->DBID), $sKeyFilter); // Replace key value
		return $sKeyFilter;
	}

	// Return page URL
	function getReturnUrl() {
		$name = EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL;

		// Get referer URL automatically
		if (ew_ServerVar("HTTP_REFERER") <> "" && ew_ReferPage() <> ew_CurrentPage() && ew_ReferPage() <> "login.php") // Referer not same page or login page
			$_SESSION[$name] = ew_ServerVar("HTTP_REFERER"); // Save to Session
		if (@$_SESSION[$name] <> "") {
			return $_SESSION[$name];
		} else {
			return "daily_reportlist.php";
		}
	}

	function setReturnUrl($v) {
		$_SESSION[EW_PROJECT_NAME . "_" . $this->TableVar . "_" . EW_TABLE_RETURN_URL] = $v;
	}

	// List URL
	function GetListUrl() {
		return "daily_reportlist.php";
	}

	// View URL
	function GetViewUrl($parm = "") {
		if ($parm <> "")
			$url = $this->KeyUrl("daily_reportview.php", $this->UrlParm($parm));
		else
			$url = $this->KeyUrl("daily_reportview.php", $this->UrlParm(EW_TABLE_SHOW_DETAIL . "="));
		return $this->AddMasterUrl($url);
	}

	// Add URL
	function GetAddUrl($parm = "") {
		if ($parm <> "")
			$url = "daily_reportadd.php?" . $this->UrlParm($parm);
		else
			$url = "daily_reportadd.php";
		return $this->AddMasterUrl($url);
	}

	// Edit URL
	function GetEditUrl($parm = "") {
		$url = $this->KeyUrl("daily_reportedit.php", $this->UrlParm($parm));
		return $this->AddMasterUrl($url);
	}

	// Inline edit URL
	function GetInlineEditUrl() {
		$url = $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=edit"));
		return $this->AddMasterUrl($url);
	}

	// Copy URL
	function GetCopyUrl($parm = "") {
		$url = $this->KeyUrl("daily_reportadd.php", $this->UrlParm($parm));
		return $this->AddMasterUrl($url);
	}

	// Inline copy URL
	function GetInlineCopyUrl() {
		$url = $this->KeyUrl(ew_CurrentPage(), $this->UrlParm("a=copy"));
		return $this->AddMasterUrl($url);
	}

	// Delete URL
	function GetDeleteUrl() {
		return $this->KeyUrl("daily_reportdelete.php", $this->UrlParm());
	}

	// Add master url
	function AddMasterUrl($url) {
		return $url;
	}

	function KeyToJson() {
		$json = "";
		$json .= "Id:" . ew_VarToJson($this->Id->CurrentValue, "number", "'");
		return "{" . $json . "}";
	}

	// Add key value to URL
	function KeyUrl($url, $parm = "") {
		$sUrl = $url . "?";
		if ($parm <> "") $sUrl .= $parm . "&";
		if (!is_null($this->Id->CurrentValue)) {
			$sUrl .= "Id=" . urlencode($this->Id->CurrentValue);
		} else {
			return "javascript:ew_Alert(ewLanguage.Phrase('InvalidRecord'));";
		}
		return $sUrl;
	}

	// Sort URL
	function SortUrl(&$fld) {
		return "";
	}

	// Get record keys from $_POST/$_GET/$_SESSION
	function GetRecordKeys() {
		global $EW_COMPOSITE_KEY_SEPARATOR;
		$arKeys = array();
		$arKey = array();
		if (isset($_POST["key_m"])) {
			$arKeys = ew_StripSlashes($_POST["key_m"]);
			$cnt = count($arKeys);
		} elseif (isset($_GET["key_m"])) {
			$arKeys = ew_StripSlashes($_GET["key_m"]);
			$cnt = count($arKeys);
		} elseif (!empty($_GET) || !empty($_POST)) {
			$isPost = ew_IsHttpPost();
			if ($isPost && isset($_POST["Id"]))
				$arKeys[] = ew_StripSlashes($_POST["Id"]);
			elseif (isset($_GET["Id"]))
				$arKeys[] = ew_StripSlashes($_GET["Id"]);
			else
				$arKeys = NULL; // Do not setup

			//return $arKeys; // Do not return yet, so the values will also be checked by the following code
		}

		// Check keys
		$ar = array();
		if (is_array($arKeys)) {
			foreach ($arKeys as $key) {
				if (!is_numeric($key))
					continue;
				$ar[] = $key;
			}
		}
		return $ar;
	}

	// Get key filter
	function GetKeyFilter() {
		$arKeys = $this->GetRecordKeys();
		$sKeyFilter = "";
		foreach ($arKeys as $key) {
			if ($sKeyFilter <> "") $sKeyFilter .= " OR ";
			$this->Id->CurrentValue = $key;
			$sKeyFilter .= "(" . $this->KeyFilter() . ")";
		}
		return $sKeyFilter;
	}

	// Load rows based on filter
	function &LoadRs($sFilter) {

		// Set up filter (SQL WHERE clause) and get return SQL
		//$this->CurrentFilter = $sFilter;
		//$sSql = $this->SQL();

		$sSql = $this->GetSQL($sFilter, "");
		$conn = &$this->Connection();
		$rs = $conn->Execute($sSql);
		return $rs;
	}

	// Load row values from recordset
	function LoadListRowValues(&$rs) {
		$this->Id->setDbValue($rs->fields('Id'));
		$this->No->setDbValue($rs->fields('No'));
		$this->Tanggal->setDbValue($rs->fields('Tanggal'));
		$this->Aktifitas_Hari_Ini->setDbValue($rs->fields('Aktifitas_Hari_Ini'));
		$this->Jam_Mulai->setDbValue($rs->fields('Jam_Mulai'));
		$this->Jam_Akhir->setDbValue($rs->fields('Jam_Akhir'));
		$this->Listing_Hari_Ini->setDbValue($rs->fields('Listing_Hari_Ini'));
		$this->Jenis_Property->setDbValue($rs->fields('Jenis_Property'));
		$this->Data_Pemilik_Property->setDbValue($rs->fields('Data_Pemilik_Property'));
	}

	// Render list row values
	function RenderListRow() {
		global $Security, $gsLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

   // Common render codes
		// Id
		// No
		// Tanggal
		// Aktifitas_Hari_Ini
		// Jam_Mulai
		// Jam_Akhir
		// Listing_Hari_Ini
		// Jenis_Property
		// Data_Pemilik_Property
		// Id

		$this->Id->ViewValue = $this->Id->CurrentValue;
		$this->Id->ViewCustomAttributes = "";

		// No
		$this->No->ViewValue = $this->No->CurrentValue;
		$this->No->CellCssStyle .= "text-align: center;";
		$this->No->ViewCustomAttributes = "";

		// Tanggal
		$this->Tanggal->ViewValue = $this->Tanggal->CurrentValue;
		$this->Tanggal->ViewValue = ew_FormatDateTime($this->Tanggal->ViewValue, 2);
		$this->Tanggal->CellCssStyle .= "text-align: center;";
		$this->Tanggal->ViewCustomAttributes = "";

		// Aktifitas_Hari_Ini
		$this->Aktifitas_Hari_Ini->ViewValue = $this->Aktifitas_Hari_Ini->CurrentValue;
		$this->Aktifitas_Hari_Ini->ViewCustomAttributes = "";

		// Jam_Mulai
		$this->Jam_Mulai->ViewValue = $this->Jam_Mulai->CurrentValue;
		$this->Jam_Mulai->CellCssStyle .= "text-align: center;";
		$this->Jam_Mulai->ViewCustomAttributes = "";

		// Jam_Akhir
		$this->Jam_Akhir->ViewValue = $this->Jam_Akhir->CurrentValue;
		$this->Jam_Akhir->CellCssStyle .= "text-align: center;";
		$this->Jam_Akhir->ViewCustomAttributes = "";

		// Listing_Hari_Ini
		$this->Listing_Hari_Ini->ViewValue = $this->Listing_Hari_Ini->CurrentValue;
		$this->Listing_Hari_Ini->ViewCustomAttributes = "";

		// Jenis_Property
		$this->Jenis_Property->ViewValue = $this->Jenis_Property->CurrentValue;
		$this->Jenis_Property->CellCssStyle .= "text-align: center;";
		$this->Jenis_Property->ViewCustomAttributes = "";

		// Data_Pemilik_Property
		if (strval($this->Data_Pemilik_Property->CurrentValue) <> "") {
			$sFilterWrk = "`Id`" . ew_SearchString("=", $this->Data_Pemilik_Property->CurrentValue, EW_DATATYPE_NUMBER, "");
		$sSqlWrk = "SELECT `Id`, `Pemilik` AS `DispFld`, '' AS `Disp2Fld`, '' AS `Disp3Fld`, '' AS `Disp4Fld` FROM `data_pemilik_properti`";
		$sWhereWrk = "";
		$this->Data_Pemilik_Property->LookupFilters = array("dx1" => "`Pemilik`");
		ew_AddFilter($sWhereWrk, $sFilterWrk);
		$this->Lookup_Selecting($this->Data_Pemilik_Property, $sWhereWrk); // Call Lookup selecting
		if ($sWhereWrk <> "") $sSqlWrk .= " WHERE " . $sWhereWrk;
			$rswrk = Conn()->Execute($sSqlWrk);
			if ($rswrk && !$rswrk->EOF) { // Lookup values found
				$arwrk = array();
				$arwrk[1] = $rswrk->fields('DispFld');
				$this->Data_Pemilik_Property->ViewValue = $this->Data_Pemilik_Property->DisplayValue($arwrk);
				$rswrk->Close();
			} else {
				$this->Data_Pemilik_Property->ViewValue = $this->Data_Pemilik_Property->CurrentValue;
			}
		} else {
			$this->Data_Pemilik_Property->ViewValue = NULL;
		}
		$this->Data_Pemilik_Property->CellCssStyle .= "text-align: left;";
		$this->Data_Pemilik_Property->ViewCustomAttributes = "";

		// Id
		$this->Id->LinkCustomAttributes = "";
		$this->Id->HrefValue = "";
		$this->Id->TooltipValue = "";

		// No
		$this->No->LinkCustomAttributes = "";
		$this->No->HrefValue = "";
		$this->No->TooltipValue = "";

		// Tanggal
		$this->Tanggal->LinkCustomAttributes = "";
		$this->Tanggal->HrefValue = "";
		$this->Tanggal->TooltipValue = "";

		// Aktifitas_Hari_Ini
		$this->Aktifitas_Hari_Ini->LinkCustomAttributes = "";
		$this->Aktifitas_Hari_Ini->HrefValue = "";
		$this->Aktifitas_Hari_Ini->TooltipValue = "";

		// Jam_Mulai
		$this->Jam_Mulai->LinkCustomAttributes = "";
		$this->Jam_Mulai->HrefValue = "";
		$this->Jam_Mulai->TooltipValue = "";

		// Jam_Akhir
		$this->Jam_Akhir->LinkCustomAttributes = "";
		$this->Jam_Akhir->HrefValue = "";
		$this->Jam_Akhir->TooltipValue = "";

		// Listing_Hari_Ini
		$this->Listing_Hari_Ini->LinkCustomAttributes = "";
		$this->Listing_Hari_Ini->HrefValue = "";
		$this->Listing_Hari_Ini->TooltipValue = "";

		// Jenis_Property
		$this->Jenis_Property->LinkCustomAttributes = "";
		$this->Jenis_Property->HrefValue = "";
		$this->Jenis_Property->TooltipValue = "";

		// Data_Pemilik_Property
		$this->Data_Pemilik_Property->LinkCustomAttributes = "";
		$this->Data_Pemilik_Property->HrefValue = "";
		$this->Data_Pemilik_Property->TooltipValue = "";

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Render edit row values
	function RenderEditRow() {
		global $Security, $gsLanguage, $Language;

		// Call Row Rendering event
		$this->Row_Rendering();

		// Id
		$this->Id->EditAttrs["class"] = "form-control";
		$this->Id->EditCustomAttributes = "";
		$this->Id->EditValue = $this->Id->CurrentValue;
		$this->Id->ViewCustomAttributes = "";

		// No
		$this->No->EditAttrs["class"] = "form-control";
		$this->No->EditCustomAttributes = "";
		$this->No->EditValue = $this->No->CurrentValue;

		// Tanggal
		$this->Tanggal->EditAttrs["class"] = "form-control";
		$this->Tanggal->EditCustomAttributes = "";
		$this->Tanggal->EditValue = ew_FormatDateTime($this->Tanggal->CurrentValue, 2);

		// Aktifitas_Hari_Ini
		$this->Aktifitas_Hari_Ini->EditAttrs["class"] = "form-control";
		$this->Aktifitas_Hari_Ini->EditCustomAttributes = "";
		$this->Aktifitas_Hari_Ini->EditValue = $this->Aktifitas_Hari_Ini->CurrentValue;

		// Jam_Mulai
		$this->Jam_Mulai->EditAttrs["class"] = "form-control";
		$this->Jam_Mulai->EditCustomAttributes = "";
		$this->Jam_Mulai->EditValue = $this->Jam_Mulai->CurrentValue;

		// Jam_Akhir
		$this->Jam_Akhir->EditAttrs["class"] = "form-control";
		$this->Jam_Akhir->EditCustomAttributes = "";
		$this->Jam_Akhir->EditValue = $this->Jam_Akhir->CurrentValue;

		// Listing_Hari_Ini
		$this->Listing_Hari_Ini->EditAttrs["class"] = "form-control";
		$this->Listing_Hari_Ini->EditCustomAttributes = "";
		$this->Listing_Hari_Ini->EditValue = $this->Listing_Hari_Ini->CurrentValue;

		// Jenis_Property
		$this->Jenis_Property->EditAttrs["class"] = "form-control";
		$this->Jenis_Property->EditCustomAttributes = "";
		$this->Jenis_Property->EditValue = $this->Jenis_Property->CurrentValue;

		// Data_Pemilik_Property
		$this->Data_Pemilik_Property->EditAttrs["class"] = "form-control";
		$this->Data_Pemilik_Property->EditCustomAttributes = "";

		// Call Row Rendered event
		$this->Row_Rendered();
	}

	// Aggregate list row values
	function AggregateListRowValues() {
	}

	// Aggregate list row (for rendering)
	function AggregateListRow() {

		// Call Row Rendered event
		$this->Row_Rendered();
	}
	var $ExportDoc;

	// Export data in HTML/CSV/Word/Excel/Email/PDF format
	function ExportDocument(&$Doc, &$Recordset, $StartRec, $StopRec, $ExportPageType = "") {
		if (!$Recordset || !$Doc)
			return;
		if (!$Doc->ExportCustom) {

			// Write header
			$Doc->ExportTableHeader();
			if ($Doc->Horizontal) { // Horizontal format, write header
				$Doc->BeginExportRow();
				if ($ExportPageType == "view") {
					if ($this->Id->Exportable) $Doc->ExportCaption($this->Id);
					if ($this->No->Exportable) $Doc->ExportCaption($this->No);
					if ($this->Tanggal->Exportable) $Doc->ExportCaption($this->Tanggal);
					if ($this->Aktifitas_Hari_Ini->Exportable) $Doc->ExportCaption($this->Aktifitas_Hari_Ini);
					if ($this->Jam_Mulai->Exportable) $Doc->ExportCaption($this->Jam_Mulai);
					if ($this->Jam_Akhir->Exportable) $Doc->ExportCaption($this->Jam_Akhir);
					if ($this->Listing_Hari_Ini->Exportable) $Doc->ExportCaption($this->Listing_Hari_Ini);
					if ($this->Jenis_Property->Exportable) $Doc->ExportCaption($this->Jenis_Property);
					if ($this->Data_Pemilik_Property->Exportable) $Doc->ExportCaption($this->Data_Pemilik_Property);
				} else {
					if ($this->Id->Exportable) $Doc->ExportCaption($this->Id);
					if ($this->No->Exportable) $Doc->ExportCaption($this->No);
					if ($this->Tanggal->Exportable) $Doc->ExportCaption($this->Tanggal);
					if ($this->Aktifitas_Hari_Ini->Exportable) $Doc->ExportCaption($this->Aktifitas_Hari_Ini);
					if ($this->Jam_Mulai->Exportable) $Doc->ExportCaption($this->Jam_Mulai);
					if ($this->Jam_Akhir->Exportable) $Doc->ExportCaption($this->Jam_Akhir);
					if ($this->Listing_Hari_Ini->Exportable) $Doc->ExportCaption($this->Listing_Hari_Ini);
					if ($this->Jenis_Property->Exportable) $Doc->ExportCaption($this->Jenis_Property);
					if ($this->Data_Pemilik_Property->Exportable) $Doc->ExportCaption($this->Data_Pemilik_Property);
				}
				$Doc->EndExportRow();
			}
		}

		// Move to first record
		$RecCnt = $StartRec - 1;
		if (!$Recordset->EOF) {
			$Recordset->MoveFirst();
			if ($StartRec > 1)
				$Recordset->Move($StartRec - 1);
		}
		while (!$Recordset->EOF && $RecCnt < $StopRec) {
			$RecCnt++;
			if (intval($RecCnt) >= intval($StartRec)) {
				$RowCnt = intval($RecCnt) - intval($StartRec) + 1;

				// Page break
				if ($this->ExportPageBreakCount > 0) {
					if ($RowCnt > 1 && ($RowCnt - 1) % $this->ExportPageBreakCount == 0)
						$Doc->ExportPageBreak();
				}
				$this->LoadListRowValues($Recordset);

				// Render row
				$this->RowType = EW_ROWTYPE_VIEW; // Render view
				$this->ResetAttrs();
				$this->RenderListRow();
				if (!$Doc->ExportCustom) {
					$Doc->BeginExportRow($RowCnt); // Allow CSS styles if enabled
					if ($ExportPageType == "view") {
						if ($this->Id->Exportable) $Doc->ExportField($this->Id);
						if ($this->No->Exportable) $Doc->ExportField($this->No);
						if ($this->Tanggal->Exportable) $Doc->ExportField($this->Tanggal);
						if ($this->Aktifitas_Hari_Ini->Exportable) $Doc->ExportField($this->Aktifitas_Hari_Ini);
						if ($this->Jam_Mulai->Exportable) $Doc->ExportField($this->Jam_Mulai);
						if ($this->Jam_Akhir->Exportable) $Doc->ExportField($this->Jam_Akhir);
						if ($this->Listing_Hari_Ini->Exportable) $Doc->ExportField($this->Listing_Hari_Ini);
						if ($this->Jenis_Property->Exportable) $Doc->ExportField($this->Jenis_Property);
						if ($this->Data_Pemilik_Property->Exportable) $Doc->ExportField($this->Data_Pemilik_Property);
					} else {
						if ($this->Id->Exportable) $Doc->ExportField($this->Id);
						if ($this->No->Exportable) $Doc->ExportField($this->No);
						if ($this->Tanggal->Exportable) $Doc->ExportField($this->Tanggal);
						if ($this->Aktifitas_Hari_Ini->Exportable) $Doc->ExportField($this->Aktifitas_Hari_Ini);
						if ($this->Jam_Mulai->Exportable) $Doc->ExportField($this->Jam_Mulai);
						if ($this->Jam_Akhir->Exportable) $Doc->ExportField($this->Jam_Akhir);
						if ($this->Listing_Hari_Ini->Exportable) $Doc->ExportField($this->Listing_Hari_Ini);
						if ($this->Jenis_Property->Exportable) $Doc->ExportField($this->Jenis_Property);
						if ($this->Data_Pemilik_Property->Exportable) $Doc->ExportField($this->Data_Pemilik_Property);
					}
					$Doc->EndExportRow();
				}
			}

			// Call Row Export server event
			if ($Doc->ExportCustom)
				$this->Row_Export($Recordset->fields);
			$Recordset->MoveNext();
		}
		if (!$Doc->ExportCustom) {
			$Doc->ExportTableFooter();
		}
	}

	// Get auto fill value
	function GetAutoFill($id, $val) {
		$rsarr = array();
		$rowcnt = 0;

		// Output
		if (is_array($rsarr) && $rowcnt > 0) {
			$fldcnt = count($rsarr[0]);
			for ($i = 0; $i < $rowcnt; $i++) {
				for ($j = 0; $j < $fldcnt; $j++) {
					$str = strval($rsarr[$i][$j]);
					$str = ew_ConvertToUtf8($str);
					if (isset($post["keepCRLF"])) {
						$str = str_replace(array("\r", "\n"), array("\\r", "\\n"), $str);
					} else {
						$str = str_replace(array("\r", "\n"), array(" ", " "), $str);
					}
					$rsarr[$i][$j] = $str;
				}
			}
			return ew_ArrayToJson($rsarr);
		} else {
			return FALSE;
		}
	}

	// Table level events
	// Recordset Selecting event
	function Recordset_Selecting(&$filter) {

		// Enter your code here	
	}

	// Recordset Selected event
	function Recordset_Selected(&$rs) {

		//echo "Recordset Selected";
	}

	// Recordset Search Validated event
	function Recordset_SearchValidated() {

		// Example:
		//$this->MyField1->AdvancedSearch->SearchValue = "your search criteria"; // Search value

	}

	// Recordset Searching event
	function Recordset_Searching(&$filter) {

		// Enter your code here	
	}

	// Row_Selecting event
	function Row_Selecting(&$filter) {

		// Enter your code here	
	}

	// Row Selected event
	function Row_Selected(&$rs) {

		//echo "Row Selected";
	}

	// Row Inserting event
	function Row_Inserting($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Inserted event
	function Row_Inserted($rsold, &$rsnew) {

		//echo "Row Inserted"
	}

	// Row Updating event
	function Row_Updating($rsold, &$rsnew) {

		// Enter your code here
		// To cancel, set return value to FALSE

		return TRUE;
	}

	// Row Updated event
	function Row_Updated($rsold, &$rsnew) {

		//echo "Row Updated";
	}

	// Row Update Conflict event
	function Row_UpdateConflict($rsold, &$rsnew) {

		// Enter your code here
		// To ignore conflict, set return value to FALSE

		return TRUE;
	}

	// Grid Inserting event
	function Grid_Inserting() {

		// Enter your code here
		// To reject grid insert, set return value to FALSE

		return TRUE;
	}

	// Grid Inserted event
	function Grid_Inserted($rsnew) {

		//echo "Grid Inserted";
	}

	// Grid Updating event
	function Grid_Updating($rsold) {

		// Enter your code here
		// To reject grid update, set return value to FALSE

		return TRUE;
	}

	// Grid Updated event
	function Grid_Updated($rsold, $rsnew) {

		//echo "Grid Updated";
	}

	// Row Deleting event
	function Row_Deleting(&$rs) {

		// Enter your code here
		// To cancel, set return value to False

		return TRUE;
	}

	// Row Deleted event
	function Row_Deleted(&$rs) {

		//echo "Row Deleted";
	}

	// Email Sending event
	function Email_Sending(&$Email, &$Args) {

		//var_dump($Email); var_dump($Args); exit();
		return TRUE;
	}

	// Lookup Selecting event
	function Lookup_Selecting($fld, &$filter) {

		//var_dump($fld->FldName, $fld->LookupFilters, $filter); // Uncomment to view the filter
		// Enter your code here

	}

	// Row Rendering event
	function Row_Rendering() {

		// Enter your code here	
	}

	// Row Rendered event
	function Row_Rendered() {

		// To view properties of field class, use:
		//var_dump($this-><FieldName>); 

	}

	// User ID Filtering event
	function UserID_Filtering(&$filter) {

		// Enter your code here
	}
}
?>
