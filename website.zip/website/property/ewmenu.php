<!-- Begin Main Menu -->
<?php $RootMenu = new cMenu(EW_MENUBAR_ID) ?>
<?php

// Generate all menu items
$RootMenu->IsRoot = TRUE;
$RootMenu->AddMenuItem(1, "mi_admin", $Language->MenuPhrase("1", "MenuText"), "adminlist.php", -1, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}admin'), FALSE, FALSE);
$RootMenu->AddMenuItem(2, "mi_daily_report", $Language->MenuPhrase("2", "MenuText"), "daily_reportlist.php", -1, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}daily_report'), FALSE, FALSE);
$RootMenu->AddMenuItem(3, "mi_data_costumer", $Language->MenuPhrase("3", "MenuText"), "data_costumerlist.php", -1, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}data_costumer'), FALSE, FALSE);
$RootMenu->AddMenuItem(5, "mi_data_marketing", $Language->MenuPhrase("5", "MenuText"), "data_marketinglist.php", -1, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}data_marketing'), FALSE, FALSE);
$RootMenu->AddMenuItem(6, "mi_data_pemilik_listing", $Language->MenuPhrase("6", "MenuText"), "data_pemilik_listinglist.php", -1, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}data_pemilik_listing'), FALSE, FALSE);
$RootMenu->AddMenuItem(7, "mi_data_pemilik_properti", $Language->MenuPhrase("7", "MenuText"), "data_pemilik_propertilist.php", -1, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}data_pemilik_properti'), FALSE, FALSE);
$RootMenu->AddMenuItem(9, "mi_property", $Language->MenuPhrase("9", "MenuText"), "propertylist.php", -1, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}property'), FALSE, FALSE);
$RootMenu->AddMenuItem(20, "mci_Laporan", $Language->MenuPhrase("20", "MenuText"), "", -1, "", TRUE, FALSE, TRUE);
$RootMenu->AddMenuItem(10, "mi_Costumer", $Language->MenuPhrase("10", "MenuText"), "Costumerreport.php", 20, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}Costumer'), FALSE, FALSE);
$RootMenu->AddMenuItem(23, "mi_Laporan_Harian", $Language->MenuPhrase("23", "MenuText"), "Laporan_Harianreport.php", 20, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}Laporan Harian'), FALSE, FALSE);
$RootMenu->AddMenuItem(24, "mi_Laporan_Data_Marketing", $Language->MenuPhrase("24", "MenuText"), "Laporan_Data_Marketingreport.php", 20, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}Laporan Data Marketing'), FALSE, FALSE);
$RootMenu->AddMenuItem(22, "mi_Laporan_Property", $Language->MenuPhrase("22", "MenuText"), "Laporan_Propertyreport.php", 20, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}Laporan Property'), FALSE, FALSE);
$RootMenu->AddMenuItem(21, "mi_Pemilik_Property", $Language->MenuPhrase("21", "MenuText"), "Pemilik_Propertyreport.php", 20, "", IsLoggedIn() || AllowListMenu('{1B30E8D9-D363-49E8-A880-2B04CACE607B}Pemilik Property'), FALSE, FALSE);
$RootMenu->AddMenuItem(-1, "mi_logout", $Language->Phrase("Logout"), "logout.php", -1, "", IsLoggedIn() && CurrentUserName() != ew_CurrentWindowsUser());
$RootMenu->AddMenuItem(-1, "mi_login", $Language->Phrase("Login"), "login.php", -1, "", !IsLoggedIn() && substr(@$_SERVER["URL"], -1 * strlen("login.php")) <> "login.php");
$RootMenu->Render();
?>
<!-- End Main Menu -->
