<?php

// Id
// Kode
// Marketing

?>
<?php if ($data_pemilik_listing->Visible) { ?>
<!-- <h4 class="ewMasterCaption"><?php echo $data_pemilik_listing->TableCaption() ?></h4> -->
<div id="t_data_pemilik_listing" class="<?php if (ew_IsResponsiveLayout()) echo "table-responsive "; ?>ewGrid">
<table id="tbl_data_pemilik_listingmaster" class="table ewTable">
<?php echo $data_pemilik_listing->TableCustomInnerHtml ?>
	<thead>
		<tr>
<?php if ($data_pemilik_listing->Id->Visible) { // Id ?>
			<th class="ewTableHeader"><?php echo $data_pemilik_listing->Id->FldCaption() ?></th>
<?php } ?>
<?php if ($data_pemilik_listing->Kode->Visible) { // Kode ?>
			<th class="ewTableHeader"><?php echo $data_pemilik_listing->Kode->FldCaption() ?></th>
<?php } ?>
<?php if ($data_pemilik_listing->Marketing->Visible) { // Marketing ?>
			<th class="ewTableHeader"><?php echo $data_pemilik_listing->Marketing->FldCaption() ?></th>
<?php } ?>
		</tr>
	</thead>
	<tbody>
		<tr>
<?php if ($data_pemilik_listing->Id->Visible) { // Id ?>
			<td<?php echo $data_pemilik_listing->Id->CellAttributes() ?>>
<span id="el_data_pemilik_listing_Id">
<span<?php echo $data_pemilik_listing->Id->ViewAttributes() ?>>
<?php echo $data_pemilik_listing->Id->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_pemilik_listing->Kode->Visible) { // Kode ?>
			<td<?php echo $data_pemilik_listing->Kode->CellAttributes() ?>>
<span id="el_data_pemilik_listing_Kode">
<span<?php echo $data_pemilik_listing->Kode->ViewAttributes() ?>>
<?php echo $data_pemilik_listing->Kode->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_pemilik_listing->Marketing->Visible) { // Marketing ?>
			<td<?php echo $data_pemilik_listing->Marketing->CellAttributes() ?>>
<span id="el_data_pemilik_listing_Marketing">
<span<?php echo $data_pemilik_listing->Marketing->ViewAttributes() ?>>
<?php echo $data_pemilik_listing->Marketing->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
		</tr>
	</tbody>
</table>
</div>
<?php } ?>
