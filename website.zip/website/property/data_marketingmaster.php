<?php

// No
// Nama
// Alamat
// No_Ktp
// NPWP
// Telp
// Kode
// Area_Listing
// Alamat_Lengkap
// Nama_yang_bisa_dihubungi
// No_Telp

?>
<?php if ($data_marketing->Visible) { ?>
<!-- <h4 class="ewMasterCaption"><?php echo $data_marketing->TableCaption() ?></h4> -->
<div id="t_data_marketing" class="<?php if (ew_IsResponsiveLayout()) echo "table-responsive "; ?>ewGrid">
<table id="tbl_data_marketingmaster" class="table ewTable">
<?php echo $data_marketing->TableCustomInnerHtml ?>
	<thead>
		<tr>
<?php if ($data_marketing->No->Visible) { // No ?>
			<th class="ewTableHeader"><?php echo $data_marketing->No->FldCaption() ?></th>
<?php } ?>
<?php if ($data_marketing->Nama->Visible) { // Nama ?>
			<th class="ewTableHeader"><?php echo $data_marketing->Nama->FldCaption() ?></th>
<?php } ?>
<?php if ($data_marketing->Alamat->Visible) { // Alamat ?>
			<th class="ewTableHeader"><?php echo $data_marketing->Alamat->FldCaption() ?></th>
<?php } ?>
<?php if ($data_marketing->No_Ktp->Visible) { // No_Ktp ?>
			<th class="ewTableHeader"><?php echo $data_marketing->No_Ktp->FldCaption() ?></th>
<?php } ?>
<?php if ($data_marketing->NPWP->Visible) { // NPWP ?>
			<th class="ewTableHeader"><?php echo $data_marketing->NPWP->FldCaption() ?></th>
<?php } ?>
<?php if ($data_marketing->Telp->Visible) { // Telp ?>
			<th class="ewTableHeader"><?php echo $data_marketing->Telp->FldCaption() ?></th>
<?php } ?>
<?php if ($data_marketing->Kode->Visible) { // Kode ?>
			<th class="ewTableHeader"><?php echo $data_marketing->Kode->FldCaption() ?></th>
<?php } ?>
<?php if ($data_marketing->Area_Listing->Visible) { // Area_Listing ?>
			<th class="ewTableHeader"><?php echo $data_marketing->Area_Listing->FldCaption() ?></th>
<?php } ?>
<?php if ($data_marketing->Alamat_Lengkap->Visible) { // Alamat_Lengkap ?>
			<th class="ewTableHeader"><?php echo $data_marketing->Alamat_Lengkap->FldCaption() ?></th>
<?php } ?>
<?php if ($data_marketing->Nama_yang_bisa_dihubungi->Visible) { // Nama_yang_bisa_dihubungi ?>
			<th class="ewTableHeader"><?php echo $data_marketing->Nama_yang_bisa_dihubungi->FldCaption() ?></th>
<?php } ?>
<?php if ($data_marketing->No_Telp->Visible) { // No_Telp ?>
			<th class="ewTableHeader"><?php echo $data_marketing->No_Telp->FldCaption() ?></th>
<?php } ?>
		</tr>
	</thead>
	<tbody>
		<tr>
<?php if ($data_marketing->No->Visible) { // No ?>
			<td<?php echo $data_marketing->No->CellAttributes() ?>>
<span id="el_data_marketing_No">
<span<?php echo $data_marketing->No->ViewAttributes() ?>>
<?php echo $data_marketing->No->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Nama->Visible) { // Nama ?>
			<td<?php echo $data_marketing->Nama->CellAttributes() ?>>
<span id="el_data_marketing_Nama">
<span<?php echo $data_marketing->Nama->ViewAttributes() ?>>
<?php echo $data_marketing->Nama->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Alamat->Visible) { // Alamat ?>
			<td<?php echo $data_marketing->Alamat->CellAttributes() ?>>
<span id="el_data_marketing_Alamat">
<span<?php echo $data_marketing->Alamat->ViewAttributes() ?>>
<?php echo $data_marketing->Alamat->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->No_Ktp->Visible) { // No_Ktp ?>
			<td<?php echo $data_marketing->No_Ktp->CellAttributes() ?>>
<span id="el_data_marketing_No_Ktp">
<span<?php echo $data_marketing->No_Ktp->ViewAttributes() ?>>
<?php echo $data_marketing->No_Ktp->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->NPWP->Visible) { // NPWP ?>
			<td<?php echo $data_marketing->NPWP->CellAttributes() ?>>
<span id="el_data_marketing_NPWP">
<span<?php echo $data_marketing->NPWP->ViewAttributes() ?>>
<?php echo $data_marketing->NPWP->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Telp->Visible) { // Telp ?>
			<td<?php echo $data_marketing->Telp->CellAttributes() ?>>
<span id="el_data_marketing_Telp">
<span<?php echo $data_marketing->Telp->ViewAttributes() ?>>
<?php echo $data_marketing->Telp->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Kode->Visible) { // Kode ?>
			<td<?php echo $data_marketing->Kode->CellAttributes() ?>>
<span id="el_data_marketing_Kode">
<span<?php echo $data_marketing->Kode->ViewAttributes() ?>>
<?php echo $data_marketing->Kode->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Area_Listing->Visible) { // Area_Listing ?>
			<td<?php echo $data_marketing->Area_Listing->CellAttributes() ?>>
<span id="el_data_marketing_Area_Listing">
<span<?php echo $data_marketing->Area_Listing->ViewAttributes() ?>>
<?php echo $data_marketing->Area_Listing->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Alamat_Lengkap->Visible) { // Alamat_Lengkap ?>
			<td<?php echo $data_marketing->Alamat_Lengkap->CellAttributes() ?>>
<span id="el_data_marketing_Alamat_Lengkap">
<span<?php echo $data_marketing->Alamat_Lengkap->ViewAttributes() ?>>
<?php echo $data_marketing->Alamat_Lengkap->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->Nama_yang_bisa_dihubungi->Visible) { // Nama_yang_bisa_dihubungi ?>
			<td<?php echo $data_marketing->Nama_yang_bisa_dihubungi->CellAttributes() ?>>
<span id="el_data_marketing_Nama_yang_bisa_dihubungi">
<span<?php echo $data_marketing->Nama_yang_bisa_dihubungi->ViewAttributes() ?>>
<?php echo $data_marketing->Nama_yang_bisa_dihubungi->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
<?php if ($data_marketing->No_Telp->Visible) { // No_Telp ?>
			<td<?php echo $data_marketing->No_Telp->CellAttributes() ?>>
<span id="el_data_marketing_No_Telp">
<span<?php echo $data_marketing->No_Telp->ViewAttributes() ?>>
<?php echo $data_marketing->No_Telp->ListViewValue() ?></span>
</span>
</td>
<?php } ?>
		</tr>
	</tbody>
</table>
</div>
<?php } ?>
